package ru.prevailcraft.prevail.core;

/** Игровая ошибка: сообщение показывается игроку как есть. */
public class PrevailException extends RuntimeException {
    public PrevailException(String message) {
        super(message, null, false, false);
    }
}

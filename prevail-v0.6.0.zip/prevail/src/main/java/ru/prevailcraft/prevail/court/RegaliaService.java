package ru.prevailcraft.prevail.court;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.compat.ItemData;
import ru.prevailcraft.prevail.core.Kingdom;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.law.WantedService;

/**
 * Регалии: выдаются при назначении, нужны для полномочий,
 * рассыпаются при снятии с поста, а кража регалии — королевское преступление.
 */
public final class RegaliaService {
    private RegaliaService() {}

    public static int gen(CourtOffice o) {
        return Prevail.data().kingdom.officeGen.getOrDefault(o.name(), 0);
    }

    public static ItemStack make(CourtOffice o, String holder) {
        ItemStack s = new ItemStack(o.regalia());
        ItemData.putString(s, "office", o.name());
        ItemData.putLong(s, "gen", gen(o));
        ItemData.putString(s, "holder", holder);
        ItemData.name(s, "§6" + o.regaliaName);
        ItemData.lore(s, "§7Регалия: " + o.title, "§7Владелец: §f" + Players.name(holder), "§8Без неё полномочия не действуют");
        return s;
    }

    public static void issue(CourtOffice o, String uuid) {
        ServerPlayer p = Players.online(uuid);
        if (p != null) {
            ItemStack s = make(o, uuid);
            if (!p.getInventory().add(s)) p.drop(s, false);
        } else {
            Prevail.data().kingdom.pendingRegalia.put(uuid, o.name());
        }
    }

    public static void revoke(CourtOffice o) {
        Kingdom k = Prevail.data().kingdom;
        k.officeGen.merge(o.name(), 1, Integer::sum);
        k.pendingRegalia.values().remove(o.name());
    }

    private static boolean valid(ItemStack s, CourtOffice o) {
        return s.is(o.regalia()) && ItemData.getLong(s, "gen") == gen(o) && o.name().equals(ItemData.getString(s, "office"));
    }

    public static boolean carries(ServerPlayer p, CourtOffice o) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) if (valid(inv.getItem(i), o)) return true;
        return false;
    }

    /** Каждые 5 секунд: старые регалии рассыпаются, похитители попадают в розыск. */
    public static void scan() {
        Legitimacy.decay();
        Kingdom k = Prevail.data().kingdom;
        for (ServerPlayer p : Prevail.server().getPlayerList().getPlayers()) {
            Inventory inv = p.getInventory();
            boolean stolen = false;
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                CourtOffice o = CourtOffice.byRegalia(s.getItem());
                if (o == null) continue;
                if (!valid(s, o)) {
                    inv.setItem(i, ItemStack.EMPTY);
                    p.sendSystemMessage(Component.literal("§7Регалия «" + o.regaliaName + "» рассыпалась в прах."));
                    continue;
                }
                if (!p.getUUID().toString().equals(k.offices.get(o.name()))) stolen = true;
            }
            PlayerProfile prof = Players.profile(p);
            if (stolen && !prof.regaliaThief) {
                prof.regaliaThief = true;
                WantedService.autoRoyal(prof.uuid, "похищение королевской регалии");
            } else if (!stolen) {
                prof.regaliaThief = false;
            }
        }
    }

    public static void onLogin(ServerPlayer p) {
        String office = Prevail.data().kingdom.pendingRegalia.remove(p.getUUID().toString());
        if (office != null) {
            CourtOffice o = CourtOffice.valueOf(office);
            if (p.getUUID().toString().equals(Prevail.data().kingdom.offices.get(office))) issue(o, p.getUUID().toString());
        }
    }
}

package ru.prevailcraft.prevail.law;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Pos;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.profession.Profession;
import ru.prevailcraft.prevail.profession.ProfessionService;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.SuspicionService;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Арест, тюрьмы, каторга, выкуп, побег.
 *  - Заключённый получает медлительность и усталость (раз в минуту — молоко даёт «окно»).
 *  - Каторга: каждый добытый камень у камеры сокращает срок на 15 секунд.
 *  - Раз в сутки при входе: ведро молока (70%) или отмычка (30%).
 *  - Отмычка: 25% шанс побега (+5% за ранг наёмника). Беглец — в королевском розыске с двойной наградой.
 *  - Дом может выкупить своего: /prison bail <ник>.
 *  - Наёмник 3+ ранга с шансом 25% вырывается из кандалов.
 */
public final class PrisonService {
    private PrisonService() {}

    public static boolean isImprisoned(ServerPlayer p) {
        return Prevail.data().prisoners.containsKey(p.getUUID().toString());
    }

    public static String arrest(ServerPlayer captor, ServerPlayer target) {
        PlayerProfile c = Players.profile(captor);
        PlayerProfile t = Players.profile(target);
        if (isImprisoned(target)) throw new PrevailException(t.name + " уже в заключении.");

        WantedEntry chosen = null;
        for (WantedEntry w : Prevail.data().wanted.values()) {
            if (!w.target.equals(t.uuid)) continue;
            boolean allowed = w.scope == WantedEntry.Scope.ROYAL || w.issuer.equals(c.houseId) || CourtService.has(c.uuid, CourtOffice.MARSHAL);
            if (allowed) {
                chosen = w;
                if (w.scope == WantedEntry.Scope.HOUSE) break;
            }
        }
        if (chosen == null) throw new PrevailException(t.name + " не в розыске, или у вас нет права на этот арест.");
        if (target.getHealth() / target.getMaxHealth() > PrevailConfig.ARREST_HEALTH_FRACTION.get()) {
            throw new PrevailException("Сначала ослабьте преступника (здоровье ≤ " + Math.round(PrevailConfig.ARREST_HEALTH_FRACTION.get() * 100) + "%).");
        }
        if (t.license == Profession.MERCENARY && ProfessionService.licenseRank(t) >= 3 && ThreadLocalRandom.current().nextDouble() < 0.25) {
            target.sendSystemMessage(Component.literal("§aВы вырвались из кандалов!"));
            throw new PrevailException(t.name + " — бывалый наёмник — вырвался из кандалов!");
        }

        Pos cell;
        String jailer;
        if (chosen.scope == WantedEntry.Scope.ROYAL || !chosen.issuer.equals(c.houseId)) {
            cell = CourtService.k().prison;
            jailer = "crown";
            if (cell == null) throw new PrevailException("Королевская тюрьма не назначена (/court prison).");
        } else {
            House h = Prevail.data().houses.get(chosen.issuer);
            cell = h == null ? null : h.prison;
            jailer = chosen.issuer;
            if (cell == null) throw new PrevailException("У Дома нет темницы (/house prison).");
        }
        Prevail.data().wanted.remove(chosen.key());
        if (chosen.scope == WantedEntry.Scope.HOUSE) SuspicionService.clear(chosen.issuer, t.uuid);
        imprison(target, cell, PrevailConfig.PRISON_MINUTES.get() * 60L, jailer, chosen.reason, chosen.bounty);
        Money.give(captor, chosen.bounty);
        Players.broadcast("§6⛓ " + c.name + " схватил " + t.name + ". Награда: " + Money.fmt(chosen.bounty));
        return null;
    }

    public static void imprison(ServerPlayer p, Pos cell, long seconds, String jailer, String reason, long bounty) {
        PrisonTerm term = new PrisonTerm();
        term.prisoner = p.getUUID().toString();
        term.cell = cell;
        term.remainingSeconds = seconds;
        term.jailer = jailer;
        term.reason = reason;
        term.bounty = bounty;
        Prevail.data().prisoners.put(term.prisoner, term);
        moveToCell(p, term);
        applyEffects(p, term);
        p.sendSystemMessage(Component.literal("§cВы в заключении на " + seconds / 60 + " мин. Каторга (добыча камня у камеры) сокращает срок."));
        Prevail.markDirty();
    }

    private static void moveToCell(ServerPlayer p, PrisonTerm t) {
        ServerLevel lvl = VersionCompat.level(Prevail.server(), t.cell.dim);
        if (lvl != null) VersionCompat.teleport(p, lvl, t.cell.x, t.cell.y, t.cell.z);
    }

    private static void applyEffects(ServerPlayer p, PrisonTerm t) {
        p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 20 * 75, 1));
        p.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, 20 * 75, 1));
        t.lastEffects = System.currentTimeMillis();
    }

    public static void release(String uuid, String why) {
        PrisonTerm t = Prevail.data().prisoners.remove(uuid);
        if (t == null) throw new PrevailException("Этот игрок не в заключении.");
        ServerPlayer p = Players.online(uuid);
        if (p != null) {
            p.removeEffect(MobEffects.SLOWNESS);
            p.removeEffect(MobEffects.MINING_FATIGUE);
        }
        Players.message(uuid, "§a🔓 Вы свободны: " + why);
        Prevail.markDirty();
    }

    /** Каторга: разрешена добыча камня у камеры, каждый блок — минус 15 секунд. */
    public static boolean hardLabour(ServerPlayer p, BlockState state, BlockPos pos) {
        PrisonTerm t = Prevail.data().prisoners.get(p.getUUID().toString());
        if (t == null || !state.is(BlockTags.BASE_STONE_OVERWORLD)) return false;
        int r = PrevailConfig.PRISON_RADIUS.get();
        if (!t.cell.dim.equals(VersionCompat.dimId(p.level()))) return false;
        if (pos.distToCenterSqr(t.cell.x, t.cell.y, t.cell.z) > (double) r * r) return false;
        t.remainingSeconds = Math.max(1, t.remainingSeconds - 15);
        p.sendSystemMessage(Component.literal("§7Каторга: осталось " + t.remainingSeconds / 60 + " мин. " + t.remainingSeconds % 60 + " сек."), true);
        return true;
    }

    public static String bail(ServerPlayer sp, String name) {
        PlayerProfile t = Players.byName(name);
        PrisonTerm term = Prevail.data().prisoners.get(t.uuid);
        if (term == null) throw new PrevailException(t.name + " не в заключении.");
        long cost = (term.remainingSeconds / 60 + 1) * PrevailConfig.BAIL_PER_MINUTE.get();
        if (!Money.take(sp, cost)) throw new PrevailException("Выкуп стоит " + Money.fmt(cost) + ".");
        if ("crown".equals(term.jailer)) CourtService.k().treasury += cost;
        else {
            House h = Prevail.data().houses.get(term.jailer);
            if (h != null) h.treasury += cost;
            else CourtService.k().treasury += cost;
        }
        release(t.uuid, "за вас внесён выкуп");
        Players.broadcast("§e" + sp.getName().getString() + " выкупил " + t.name + " за " + Money.fmt(cost) + ".");
        return null;
    }

    public static String pardon(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        if (!CourtService.has(p.uuid, CourtOffice.MARSHAL)) throw new PrevailException("Миловать могут король, десница и маршал.");
        PlayerProfile t = Players.byName(name);
        if (Prevail.data().prisoners.containsKey(t.uuid)) release(t.uuid, "королевское помилование");
        WantedService.clearAll(t.uuid);
        Players.broadcast("§a📜 Корона милует " + t.name + ".");
        return null;
    }

    /** ПКМ отмычкой в заключении. */
    public static void tryLockpick(ServerPlayer p, ItemStack pick) {
        PrisonTerm t = Prevail.data().prisoners.get(p.getUUID().toString());
        if (t == null) return;
        pick.shrink(1);
        PlayerProfile prof = Players.profile(p);
        double chance = 0.25 + (prof.license == Profession.MERCENARY ? 0.05 * ProfessionService.licenseRank(prof) : 0);
        if (ThreadLocalRandom.current().nextDouble() < chance) {
            Prevail.data().prisoners.remove(t.prisoner);
            p.removeEffect(MobEffects.SLOWNESS);
            p.removeEffect(MobEffects.MINING_FATIGUE);
            p.sendSystemMessage(Component.literal("§aЗамок поддался! Бегите — теперь вы беглец."));
            WantedService.autoRoyal(t.prisoner, "побег из заключения", Math.max(100, t.bounty * 2));
        } else {
            t.remainingSeconds += 120;
            p.sendSystemMessage(Component.literal("§cОтмычка сломалась. Стража заметила — +2 минуты к сроку."));
        }
        Prevail.markDirty();
    }

    public static String status(ServerPlayer sp) {
        PrisonTerm t = Prevail.data().prisoners.get(sp.getUUID().toString());
        if (t == null) return "Вы на свободе.";
        return "Осталось: " + t.remainingSeconds / 60 + " мин. " + t.remainingSeconds % 60 + " сек. Причина: " + t.reason
                + ". Выкуп: " + Money.fmt((t.remainingSeconds / 60 + 1) * PrevailConfig.BAIL_PER_MINUTE.get());
    }

    public static void tickSecond() {
        int radius = PrevailConfig.PRISON_RADIUS.get();
        long now = System.currentTimeMillis();
        List<String> done = new ArrayList<>();
        for (PrisonTerm t : Prevail.data().prisoners.values()) {
            ServerPlayer p = Players.online(t.prisoner);
            if (p == null) continue;
            if (--t.remainingSeconds <= 0) {
                done.add(t.prisoner);
                continue;
            }
            if (now - t.lastEffects > 60_000L) applyEffects(p, t);
            boolean sameDim = t.cell.dim.equals(VersionCompat.dimId(p.level()));
            if (!sameDim || p.distanceToSqr(t.cell.x, t.cell.y, t.cell.z) > (double) radius * radius) {
                moveToCell(p, t);
                p.sendSystemMessage(Component.literal("§cСтража вернула вас в камеру."));
            }
        }
        for (String id : done) release(id, "срок вышел");
    }

    public static void onLogin(ServerPlayer p) {
        PrisonTerm t = Prevail.data().prisoners.get(p.getUUID().toString());
        if (t == null) return;
        moveToCell(p, t);
        applyEffects(p, t);
        PlayerProfile prof = Players.profile(p);
        long day = System.currentTimeMillis() / 86_400_000L;
        if (prof.lastPrisonGiftDay != day) {
            prof.lastPrisonGiftDay = day;
            ItemStack gift = ThreadLocalRandom.current().nextDouble() < 0.7 ? new ItemStack(Items.MILK_BUCKET) : new ItemStack(ModItems.LOCKPICK.get());
            if (!p.getInventory().add(gift)) p.drop(gift, false);
            p.sendSystemMessage(Component.literal("§7Кто-то просунул вам сквозь решётку: " + gift.getHoverName().getString()));
        }
        p.sendSystemMessage(Component.literal("§cВы в заключении. " + status(p)));
    }
}

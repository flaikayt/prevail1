package ru.prevailcraft.prevail.core;

/** Феодальная лестница внутри Дома. */
public enum Rank {
    FREEMAN("Вольный"),
    SERF("Крепостной"),
    KNIGHT("Рыцарь"),
    LORD("Лорд");

    public final String title;

    Rank(String title) {
        this.title = title;
    }
}

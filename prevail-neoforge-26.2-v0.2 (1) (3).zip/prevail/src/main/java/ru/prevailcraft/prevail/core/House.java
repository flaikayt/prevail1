package ru.prevailcraft.prevail.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Дом. Живёт, пока горит Родовой очаг с Сердцем Дома. */
public final class House {
    public String id;
    public String name;
    public String lord;
    public String suzerain;
    public String pendingFealtyTo;

    public Set<String> members = new HashSet<>();
    /** Приглашённый uuid → кто пригласил (станет его сеньором). */
    public Map<String, String> invites = new HashMap<>();
    public Set<String> allies = new HashSet<>();

    public long treasury;
    public long debt;

    public Pos seat;
    public Pos prison;
    public long createdAt;

    /** Позиция очага (ключ блока) и вставлено ли Сердце. */
    public String hearth;
    public boolean heartPlaced;
    /** Категория содержания → накопленные очки. */
    public Map<String, Double> upkeep = new HashMap<>();
    public long hungryHours;
    public long lastUpkeepMillis;

    public House() {}

    public int hungerStage() {
        if (hungryHours >= 48) return 3;
        if (hungryHours >= 12) return 2;
        if (hungryHours >= 1) return 1;
        return 0;
    }
}

package ru.prevailcraft.prevail.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.compat.VersionCompat;

/**
 * ВСЕ вызовы отрисовки интерфейса собраны здесь.
 * В 26.x рисование идёт через GuiGraphicsExtractor (бывший GuiGraphics);
 * если при обновлении Minecraft что-то переименуют — правится только этот файл.
 */
public final class Ui {
    public static final int WOOD = 0xFFB08A55, WOOD_DARK = 0xFF6B4F2A, WOOD_LIGHT = 0xFFD2AE74;
    public static final int GREY = 0xFFC6C6C6, GREY_DARK = 0xFF555555, SLOT = 0xFF8B8B8B;
    public static final int TEXT = 0xFF404040, WHITE = 0xFFFFFFFF, GOLD = 0xFFFFD24A, GREEN = 0xFF55FF55, RED = 0xFFFF5555;

    private Ui() {}

    /** Открыть экран (в 26.2: Minecraft.gui.setScreen). null — закрыть. */
    public static void open(net.minecraft.client.gui.screens.Screen screen) {
        Minecraft.getInstance().gui.setScreen(screen);
    }

    /** Текущий открытый экран (в 26.2: Minecraft.gui.screen()). */
    public static net.minecraft.client.gui.screens.Screen current() {
        return Minecraft.getInstance().gui.screen();
    }

    /** Зажата ли клавиша (в 26.2: InputConstants.isKeyDown(Window, key)). */
    public static boolean keyDown(int glfwKey) {
        return com.mojang.blaze3d.platform.InputConstants.isKeyDown(Minecraft.getInstance().getWindow(), glfwKey);
    }

    /** Звук интерфейса (страница, клик, повышение уровня). */
    public static void sound(net.minecraft.sounds.SoundEvent ev, float pitch) {
        Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(ev, pitch));
    }

    public static Font font() {
        return Minecraft.getInstance().font;
    }

    public static void fill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color) {
        g.fill(x1, y1, x2, y2, color);
    }

    /** Панель как у ванильных окон: рамка + заливка. */
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int fillColor) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFFFFFFF);
        g.fill(x + 2, y + 2, x + w - 1, y + h - 1, 0xFF555555);
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, fillColor);
    }

    /** Ячейка под предмет 18×18. */
    public static void slot(GuiGraphicsExtractor g, int x, int y) {
        g.fill(x, y, x + 18, y + 18, 0xFF373737);
        g.fill(x + 1, y + 1, x + 18, y + 18, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 17, y + 17, SLOT);
    }

    public static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color, boolean shadow) {
        g.text(font(), s, x, y, color, shadow);
    }

    public static void centered(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        g.centeredText(font(), s, cx, y, color);
    }

    public static void item(GuiGraphicsExtractor g, ItemStack stack, int x, int y) {
        g.item(stack, x, y);
    }

    public static void item(GuiGraphicsExtractor g, String itemId, int x, int y) {
        g.item(new ItemStack(VersionCompat.item(itemId)), x, y);
    }

    /** Текст без тени, по центру. */
    public static void centeredFlat(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        g.text(font(), s, cx - font().width(s) / 2, y, color, false);
    }

    /** Мелкий текст (масштаб scale), по центру cx. */
    public static void small(GuiGraphicsExtractor g, String s, int cx, int y, int color, float scale) {
        g.pose().pushMatrix();
        g.pose().translate(cx, y);
        g.pose().scale(scale, scale);
        g.text(font(), s, -font().width(s) / 2, 0, color, false);
        g.pose().popMatrix();
    }

    /** Увеличенная иконка предмета. */
    public static void bigItem(GuiGraphicsExtractor g, String itemId, int x, int y, float scale) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.item(new ItemStack(VersionCompat.item(itemId)), 0, 0);
        g.pose().popMatrix();
    }

    /** Фигурка игрока, следящая за мышью (как в инвентаре). */
    public static void player(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int scale, int mouseX, int mouseY) {
        var p = Minecraft.getInstance().player;
        if (p == null) return;
        InventoryScreen.extractEntityInInventoryFollowsMouse(g, x1, y1, x2, y2, scale, 0.0625f, mouseX, mouseY, p);
    }

    /** 5 точек прогресса ранга (как в окне ремёсел). */
    public static void rankNodes(GuiGraphicsExtractor g, int x, int y, int rank, int step) {
        for (int i = 0; i < 5; i++) {
            int nx = x + i * step;
            if (i < 4) g.fill(nx + 6, y + 3, nx + step, y + 4, i + 1 < rank ? 0xFF3FBF3F : 0xFF8A8A8A);
            int c = i < rank ? 0xFF3FBF3F : 0xFF9A9A9A;
            g.fill(nx, y, nx + 7, y + 7, 0xFF1E1E1E);
            g.fill(nx + 1, y + 1, nx + 6, y + 6, c);
        }
    }

    public static String[] split(String s, char sep) {
        return s.isEmpty() ? new String[0] : s.split(java.util.regex.Pattern.quote(String.valueOf(sep)));
    }
}

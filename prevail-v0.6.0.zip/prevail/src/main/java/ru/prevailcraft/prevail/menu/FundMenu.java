package ru.prevailcraft.prevail.menu;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.registry.ModMenus;
import ru.prevailcraft.prevail.world.FundService;

/** Фонд: один слот «вклад» и кнопка «Внести» (id 0). Всё остальное — в данных от сервера (fund_info). */
public class FundMenu extends AbstractContainerMenu {
    public static final int SLOT_X = 152, SLOT_Y = 104;
    private final SimpleContainer input = new SimpleContainer(1);

    public FundMenu(int id, Inventory inv) {
        super(ModMenus.FUND.get(), id);
        addSlot(new Slot(input, 0, SLOT_X, SLOT_Y));
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 140 + r * 18));
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, 8 + c * 18, 198));
    }

    @Override
    public boolean clickMenuButton(Player p, int id) {
        if (id != 0 || !(p instanceof ServerPlayer sp)) return false;
        ItemStack st = input.getItem(0);
        if (st.isEmpty()) return false;
        try {
            FundService.contribute(sp, st);
            input.setChanged();
        } catch (PrevailException e) {
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal("§c" + e.getMessage()), true);
        }
        FundService.sendInfo(sp);
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot.hasItem()) {
            ItemStack st = slot.getItem();
            result = st.copy();
            if (index == 0) {
                if (!moveItemStackTo(st, 1, 37, true)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(st, 0, 1, false)) {
                return ItemStack.EMPTY;
            }
            if (st.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player p) {
        return true;
    }

    @Override
    public void removed(Player p) {
        super.removed(p);
        clearContainer(p, input);
    }
}

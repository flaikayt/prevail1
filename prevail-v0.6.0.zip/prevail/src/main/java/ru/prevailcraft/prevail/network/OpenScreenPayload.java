package ru.prevailcraft.prevail.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Сервер → клиент: открыть/обновить экран. data — строка «ключ=значение;…». */
public record OpenScreenPayload(String screen, String data) implements CustomPacketPayload {
    public static final Type<OpenScreenPayload> TYPE = new Type<>(Identifier.fromNamespaceAndPath("prevail", "open_screen"));
    public static final StreamCodec<ByteBuf, OpenScreenPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, OpenScreenPayload::screen,
            ByteBufCodecs.STRING_UTF8, OpenScreenPayload::data,
            OpenScreenPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}

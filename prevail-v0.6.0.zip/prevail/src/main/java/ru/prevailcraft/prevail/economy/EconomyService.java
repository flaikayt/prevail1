package ru.prevailcraft.prevail.economy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.Kingdom;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.court.Legitimacy;
import ru.prevailcraft.prevail.profession.Profession;
import ru.prevailcraft.prevail.profession.ProfessionService;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.TerritoryService;
import ru.prevailcraft.prevail.ui.ChestGui;
import ru.prevailcraft.prevail.ui.Icons;
import ru.prevailcraft.prevail.vassalage.HouseService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Деньги королевства: казна Домов, налог, чеканка (через скупщика), рынок, кошелёк.
 * Откуда берутся деньги: (1) скупщик чеканит медь, пока чеканка открыта;
 * (2) продажа на рынок; (3) заказы между игроками.
 */
public final class EconomyService {
    private EconomyService() {}

    // ---------- казна Дома ----------

    public static String deposit(ServerPlayer sp, long amount) {
        if (amount <= 0) throw new PrevailException("Сумма должна быть больше нуля.");
        House h = Players.requireHouse(Players.profile(sp));
        if (!Money.take(sp, amount)) throw new PrevailException("У вас нет столько денег.");
        h.treasury += amount;
        payDebt(h);
        return "В казну Дома внесено " + Money.fmt(amount) + ". Казна: " + Money.fmt(h.treasury);
    }

    public static String withdraw(ServerPlayer sp, long amount) {
        if (amount <= 0) throw new PrevailException("Сумма должна быть больше нуля.");
        House h = HouseService.requireLord(Players.profile(sp));
        if (h.treasury < amount) throw new PrevailException("В казне только " + Money.fmt(h.treasury) + ".");
        h.treasury -= amount;
        Money.give(sp, amount);
        return "Из казны выдано " + Money.fmt(amount) + ".";
    }

    private static void payDebt(House h) {
        if (h.debt <= 0 || h.treasury <= 0) return;
        long pay = Math.min(h.debt, h.treasury);
        h.treasury -= pay;
        h.debt -= pay;
        Prevail.data().kingdom.treasury += pay;
    }

    // ---------- налоги и чеканка ----------

    public static long taxPerChunk() {
        Kingdom k = Prevail.data().kingdom;
        return k.taxPerChunk >= 0 ? k.taxPerChunk : PrevailConfig.TAX_PER_CHUNK.get();
    }

    public static void collectTaxes() {
        Kingdom k = Prevail.data().kingdom;
        if (k.king == null) return; // нет короля — нет налога
        long rate = taxPerChunk();
        PlayerProfile king = Players.profile(k.king);
        for (House h : Prevail.data().houses.values()) {
            if (king != null && h.id.equals(king.houseId)) continue;
            long due = TerritoryService.chunkCount(h) * rate;
            if (due <= 0) continue;
            long paid = Math.min(due, h.treasury);
            h.treasury -= paid;
            k.treasury += paid;
            if (paid < due) {
                h.debt += due - paid;
                Players.message(h.lord, "§c💰 Казна не покрыла налог. Недоимка: " + Money.fmt(h.debt));
            }
        }
        Prevail.markDirty();
    }

    public static String setMinting(ServerPlayer sp, boolean open) {
        PlayerProfile p = Players.profile(sp);
        if (!CourtService.has(p.uuid, CourtOffice.TREASURER)) throw new PrevailException("Чеканкой управляют король, десница и казначей.");
        Legitimacy.require(Legitimacy.TAXES, "Управление чеканкой");
        Prevail.data().kingdom.mintingOpen = open;
        Players.broadcast(open ? "§e📜 Указ: скупщик снова чеканит медь." : "§e📜 Указ: чеканка остановлена — скупщик платит из королевской казны.");
        return null;
    }

    public static void tickSecond() {
        long now = System.currentTimeMillis();
        var d = Prevail.data();
        long interval = PrevailConfig.TAX_INTERVAL_MINUTES.get() * 60_000L;
        if (d.lastTaxMillis == 0) d.lastTaxMillis = now;
        if (now - d.lastTaxMillis >= interval) {
            d.lastTaxMillis = now;
            collectTaxes();
        }
        if (now - d.lastMarketDriftMillis >= 3_600_000L) {
            d.lastMarketDriftMillis = now;
            for (MarketEntry e : d.market.values()) e.stock = Math.max(0, e.stock - Math.max(1, e.stock / 50)); // порча/расход склада
        }
    }

    // ---------- скупщик ----------

    private static double merchantBonus(PlayerProfile p) {
        int lv = ru.prevailcraft.prevail.profession.AbilityService.level(p, ru.prevailcraft.prevail.profession.Ability.MERCHANT);
        return lv == 0 ? 1.0 : 1.05 + 0.05 * lv;
    }

    /** ПКМ по скупщику: окно с одним слотом (menu/BuyerMenu + client/screen/BuyerScreen). */
    public static void openBuyer(ServerPlayer sp) {
        sp.openMenu(new net.minecraft.world.SimpleMenuProvider(
                (id, inv, pl) -> new ru.prevailcraft.prevail.menu.BuyerMenu(id, inv),
                net.minecraft.network.chat.Component.literal("Скупщик")));
    }

    /** Сколько скупщик заплатит за весь стак (0 — не берёт). */
    public static long quote(ServerPlayer sp, ItemStack stack) {
        if (stack.isEmpty()) return 0;
        MarketEntry e = Prevail.data().market.get(VersionCompat.itemId(stack.getItem()));
        if (e == null) return 0;
        double bonus = merchantBonus(Players.profile(sp));
        long total = 0, stock = e.stock;
        for (int i = 0; i < stack.getCount(); i++) {
            total += e.buyerPrice(bonus);
            e.stock++;
        }
        e.stock = stock;
        return total;
    }

    /** Спрос на товар: 0 — очень низкий … 4 — очень высокий; -1 — не покупается. */
    public static int demand(ItemStack stack) {
        if (stack.isEmpty()) return -1;
        MarketEntry e = Prevail.data().market.get(VersionCompat.itemId(stack.getItem()));
        if (e == null) return -1;
        double r = (double) e.stock / Math.max(1, e.target);
        return r < 0.5 ? 4 : r < 1 ? 3 : r < 1.5 ? 2 : r < 2.5 ? 1 : 0;
    }

    /** Продать стак из слота скупщика. Возвращает выручку. */
    public static long sellStack(ServerPlayer sp, ItemStack stack) {
        String id = VersionCompat.itemId(stack.getItem());
        MarketEntry e = Prevail.data().market.get(id);
        if (e == null) throw new PrevailException("Скупщик не берёт этот товар.");
        PlayerProfile p = Players.profile(sp);
        int n = stack.getCount();
        long total = quote(sp, stack);
        Kingdom k = Prevail.data().kingdom;
        if (!k.mintingOpen) {
            if (k.treasury < total) throw new PrevailException("Чеканка закрыта, а в казне всего " + Money.fmt(k.treasury) + ".");
            k.treasury -= total;
        }
        e.stock += n;
        stack.shrink(n);
        Money.give(sp, total);
        ru.prevailcraft.prevail.profession.AbilityService.addXp(p, ru.prevailcraft.prevail.profession.Ability.MERCHANT, n);
        Prevail.markDirty();
        return total;
    }

    // ---------- рынок (client/screen/MarketScreen) ----------

    /** Отправить игроку товары рынка; open=true — открыть окно, false — обновить открытое. */
    public static void sendMarket(ServerPlayer sp, boolean open) {
        StringBuilder items = new StringBuilder();
        for (Map.Entry<String, MarketEntry> en : Prevail.data().market.entrySet()) {
            MarketEntry e = en.getValue();
            if (items.length() > 0) items.append('/');
            items.append(en.getKey()).append(',').append(e.marketPrice()).append(',').append(e.stock);
        }
        ru.prevailcraft.prevail.network.Network.openScreen(sp, open ? "market" : "market_update",
                "money=" + Money.count(sp) + ";items=" + items);
    }

    public static void buy(ServerPlayer sp, String id, int count) {
        MarketEntry e = Prevail.data().market.get(id);
        if (e == null) throw new PrevailException("Такого товара нет.");
        if (e.stock < count) throw new PrevailException("На складе только " + e.stock + " шт.");
        long saved = e.stock;
        long total = 0;
        for (int i = 0; i < count; i++) {
            total += e.marketPrice();
            e.stock--;
        }
        e.stock = saved;
        if (!Money.take(sp, total)) throw new PrevailException("Нужно " + Money.fmt(total) + ".");
        e.stock -= count;
        Prevail.data().kingdom.treasury += total;
        Money.giveStacks(sp, VersionCompat.item(id), count);
    }

    // ---------- кошелёк ----------

    /**
     * ПКМ кошельком: есть монеты в инвентаре — все уходят в кошелёк;
     * монет нет — кошелёк выдаёт стопку самых крупных монет, какие может.
     */
    public static void walletUse(ServerPlayer sp, ItemStack wallet) {
        long loose = Money.loose(sp);
        var msg = (java.util.function.Consumer<String>) t -> sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(t), true);
        if (loose > 0) {
            var inv = sp.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) if (Money.valueOf(inv.getItem(i)) > 0) inv.setItem(i, ItemStack.EMPTY);
            Money.setWalletBalance(wallet, Money.walletBalance(wallet) + loose);
            msg.accept("§aВ кошелёк: +" + Money.fmt(loose) + " §7(всего " + Money.fmt(Money.walletBalance(wallet)) + ")");
            return;
        }
        long bal = Money.walletBalance(wallet);
        for (long v : new long[]{Money.PLATINUM, Money.GOLD, Money.SILVER, Money.COPPER}) {
            if (bal < v) continue;
            long n = Math.min(64, bal / v);
            Money.setWalletBalance(wallet, bal - n * v);
            Money.giveStacks(sp, Money.coin(v), n);
            msg.accept("§eИз кошелька: " + n + " × " + Money.fmt(v) + " §7(осталось " + Money.fmt(Money.walletBalance(wallet)) + ")");
            return;
        }
        msg.accept("§7Кошелёк пуст.");
    }

    public static List<String> marketIds() {
        return new ArrayList<>(Prevail.data().market.keySet());
    }
}

package ru.prevailcraft.prevail.profession;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.compat.ItemData;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.world.Epoch;

import java.util.HashMap;
import java.util.Map;

/**
 * Сталь: грубая сталь (верстак) → раскалить в доменной печи → ковать на кузнечной наковальне.
 *  - Раскалённая заготовка остывает за 60 секунд (потом снова грубая сталь).
 *  - Держать её без щипцов во второй руке — ожог.
 *  - Положить на наковальню: ПКМ заготовкой. Удар: ПКМ молотом. Снять: Shift+ПКМ молотом.
 *  - Идеально — 6 ударов, пока металл горячий. Больше 8 — заготовка трескается.
 *  - Качество слитка зависит от ранга кузнеца, точности и жара.
 */
public final class ForgeService {
    public static final long COOL_MS = 60_000L;
    public static final int TARGET = 6, CRACK = 9;
    private static final Map<String, Long> LAST_BURN = new HashMap<>();

    private ForgeService() {}

    private static boolean tongs(ServerPlayer p) {
        return p.getOffhandItem().is(ModItems.TONGS.get());
    }

    private static void burnUnlessTongs(ServerPlayer p) {
        if (!tongs(p)) {
            VersionCompat.burn(p, 2f);
            p.sendSystemMessage(Component.literal("§cРаскалённый металл обжёг руку! Держите щипцы во второй руке."), true);
        }
    }

    public static void use(ServerPlayer sp, String key, BlockPos pos) {
        PlayerProfile prof = Players.profile(sp);
        ItemStack hand = sp.getMainHandItem();
        AnvilWork work = Prevail.data().anvils.get(key);

        if (hand.is(ModItems.HOT_STEEL.get())) {
            if (prof.profession != Profession.SMITH) throw new PrevailException("Ковать сталь умеет только кузнец.");
            Epoch.require(3, "Ковка стали");
            if (work != null) throw new PrevailException("На наковальне уже лежит заготовка.");
            burnUnlessTongs(sp);
            long heated = ItemData.getLong(hand, "heatedAt");
            AnvilWork w = new AnvilWork();
            w.heatedAt = heated == 0 ? System.currentTimeMillis() : heated;
            w.smith = prof.uuid;
            hand.shrink(1);
            Prevail.data().anvils.put(key, w);
            sp.sendSystemMessage(Component.literal("§6Заготовка на наковальне. Бейте молотом (ПКМ), ~" + TARGET + " ударов, пока горячо."), true);
            return;
        }
        if (!hand.is(ModItems.SMITH_HAMMER.get())) throw new PrevailException("Нужен кузнечный молот или раскалённая заготовка.");
        if (work == null) throw new PrevailException("Наковальня пуста.");
        if (!prof.uuid.equals(work.smith)) throw new PrevailException("Это чужая работа.");
        double heat = 1.0 - (double) (System.currentTimeMillis() - work.heatedAt) / COOL_MS;

        if (sp.isShiftKeyDown()) {
            finish(sp, key, work, heat, prof);
            return;
        }
        if (heat <= 0) throw new PrevailException("Металл остыл. Снимите заготовку (Shift+ПКМ молотом) и раскалите снова.");
        work.strikes++;
        sp.level().playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.6f, 1.1f + work.strikes * 0.05f);
        String heatBar = heat > 0.5 ? "§cраскалена" : heat > 0.2 ? "§6остывает" : "§7почти холодная";
        sp.sendSystemMessage(Component.literal("§eУдар " + work.strikes + " · заготовка " + heatBar), true);
        if (work.strikes >= CRACK) {
            Prevail.data().anvils.remove(key);
            sp.sendSystemMessage(Component.literal("§cПерекованная заготовка треснула и пропала."));
        }
    }

    private static void finish(ServerPlayer sp, String key, AnvilWork w, double heat, PlayerProfile prof) {
        Prevail.data().anvils.remove(key);
        if (w.strikes < TARGET - 2) {
            ItemStack back = new ItemStack(heat > 0 ? ModItems.HOT_STEEL.get() : ModItems.ROUGH_STEEL.get());
            if (heat > 0) {
                ItemData.putLong(back, "heatedAt", w.heatedAt);
                burnUnlessTongs(sp);
            }
            if (!sp.getInventory().add(back)) sp.drop(back, false);
            sp.sendSystemMessage(Component.literal("§7Заготовка снята недокованной."), true);
            return;
        }
        int rank = Math.max(1, ProfessionService.rank(prof));
        int idx = rank - 1 - Math.abs(w.strikes - TARGET) + (heat > 0.3 ? 0 : -1);
        Quality q = Quality.byIndex(Math.min(idx, rank >= 5 ? 4 : 3));
        ItemStack ingot = new ItemStack(ModItems.STEEL_INGOT.get());
        ItemData.putString(ingot, "quality", q.name());
        ItemData.lore(ingot, q.color + "Качество: " + q.title, "§8Ковал: " + prof.name);
        if (!sp.getInventory().add(ingot)) sp.drop(ingot, false);
        ProfessionService.addXp(prof, Profession.SMITH, 10 + 5L * q.ordinal());
        sp.sendSystemMessage(Component.literal(q.color + "Стальной слиток готов: " + q.title + "."));
    }

    /** Остывание заготовок в инвентаре и ожоги. */
    public static void tickSecond() {
        long now = System.currentTimeMillis();
        for (ServerPlayer p : Prevail.server().getPlayerList().getPlayers()) {
            Inventory inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (!s.is(ModItems.HOT_STEEL.get())) continue;
                long at = ItemData.getLong(s, "heatedAt");
                if (at == 0) {
                    ItemData.putLong(s, "heatedAt", now);
                    ItemData.lore(s, "§cРаскалена — остынет через минуту", "§8Берите щипцами!");
                } else if (now - at > COOL_MS) {
                    inv.setItem(i, new ItemStack(ModItems.ROUGH_STEEL.get(), s.getCount()));
                    p.sendSystemMessage(Component.literal("§7Заготовка остыла и снова стала грубой сталью."), true);
                }
            }
            if (p.getMainHandItem().is(ModItems.HOT_STEEL.get()) && !tongs(p)) {
                String id = p.getUUID().toString();
                if (now - LAST_BURN.getOrDefault(id, 0L) > 2000) {
                    LAST_BURN.put(id, now);
                    burnUnlessTongs(p);
                }
            }
        }
    }
}

package ru.prevailcraft.prevail.profession;

/**
 * Основные ремёсла (одно на игрока). Прокачка — 50 уровней и древо навыков (см. Perks).
 * Дополнительная прокачка — Умения (Ability), до двух на игрока.
 */
public enum Profession {
    NONE("Без ремесла", "—", "minecraft:barrier", ""),
    MINER("Рудокоп", "руды и камень", "minecraft:iron_pickaxe", "Гора не отдаёт сокровищ чужакам."),
    LUMBERJACK("Лесоруб", "древесина и уголь", "minecraft:iron_axe", "Где топор, там и тепло очага."),
    FARMER("Земледелец", "урожай, хлеб, овощи", "minecraft:wheat", "Сытый вассал — верный вассал."),
    HERDER("Скотовод", "скот, шерсть, мясо", "minecraft:lead", "Табун стоит дороже замка."),
    SMITH("Кузнец", "оружие, броня, инструменты", "minecraft:anvil", "Сталь помнит руку мастера."),
    CARPENTER("Плотник", "лодки и осадные машины", "minecraft:oak_boat", "Стены падают от дерева, а не от железа."),
    WEAVER("Ткач", "кожа, ткани, знамёна", "minecraft:loom", "Под знаменем идут в бой.");

    public final String title;
    public final String perk;
    public final String icon;
    public final String quote;

    Profession(String title, String perk, String icon, String quote) {
        this.title = title;
        this.perk = perk;
        this.icon = icon;
        this.quote = quote;
    }

    public static final Profession[] MAIN = {MINER, LUMBERJACK, FARMER, HERDER, SMITH, CARPENTER, WEAVER};
}

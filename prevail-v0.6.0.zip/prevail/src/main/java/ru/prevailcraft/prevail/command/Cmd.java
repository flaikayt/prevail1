package ru.prevailcraft.prevail.command;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;

import java.util.ArrayList;
import java.util.List;

/** Общая обвязка команд: ловит PrevailException и показывает его игроку. */
final class Cmd {
    private Cmd() {}

    @FunctionalInterface
    interface Action {
        String run(ServerPlayer player) throws CommandSyntaxException;
    }

    @FunctionalInterface
    interface SourceAction {
        String run(CommandSourceStack src) throws CommandSyntaxException;
    }

    /** Команда, которую выполняет игрок. */
    static int player(CommandContext<CommandSourceStack> ctx, Action a) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        return finish(ctx.getSource(), () -> a.run(p));
    }

    /** Команда, доступная и из консоли. */
    static int any(CommandContext<CommandSourceStack> ctx, SourceAction a) throws CommandSyntaxException {
        return finish(ctx.getSource(), () -> a.run(ctx.getSource()));
    }

    @FunctionalInterface
    private interface Body {
        String run() throws CommandSyntaxException;
    }

    private static int finish(CommandSourceStack src, Body body) throws CommandSyntaxException {
        try {
            String msg = body.run();
            if (msg != null) src.sendSuccess(() -> Component.literal(msg), false);
            Prevail.markDirty();
            return 1;
        } catch (PrevailException e) {
            src.sendFailure(Component.literal(e.getMessage()));
            return 0;
        }
    }

    static final SuggestionProvider<CommandSourceStack> HOUSES = (ctx, b) -> {
        List<String> ids = new ArrayList<>();
        if (Prevail.running()) for (House h : Prevail.data().houses.values()) ids.add(h.id);
        return SharedSuggestionProvider.suggest(ids, b);
    };

    static final SuggestionProvider<CommandSourceStack> KNOWN_PLAYERS = (ctx, b) -> {
        List<String> names = new ArrayList<>();
        if (Prevail.running()) for (PlayerProfile p : Prevail.data().players.values()) if (p.name != null) names.add(p.name);
        return SharedSuggestionProvider.suggest(names, b);
    };
}

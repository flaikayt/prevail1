package ru.prevailcraft.prevail.war;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Война между двумя Домами. */
public final class War {
    public enum State { DECLARED, ACTIVE }

    public String id;
    public String attacker;
    public String defender;
    public String reason;
    public State state = State.DECLARED;
    public long declaredAt;
    public long activeAt;

    /** Прогресс захвата/освобождения чанков: ключ чанка → секунды. */
    public Map<String, Integer> progress = new HashMap<>();
    /** Чанки, захваченные в этой войне (для возврата при мире). */
    public Set<String> captured = new HashSet<>();

    public boolean attackerWantsPeace;
    public boolean defenderWantsPeace;

    public War() {}

    public boolean involves(String houseId) {
        return houseId.equals(attacker) || houseId.equals(defender);
    }

    public String enemyOf(String houseId) {
        return houseId.equals(attacker) ? defender : attacker;
    }
}

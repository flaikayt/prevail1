package ru.prevailcraft.prevail.profession;

/**
 * Ремёсла. Основное выбирает сам игрок (одно), лицензионное — выдаёт канцлер.
 * У основных ремёсел по две ветки (выбираются на ранге «Подмастерье»).
 */
public enum Profession {
    NONE("Без ремесла", false, "—"),

    MINER("Рудокоп", false, "руды и камень"),
    LUMBERJACK("Лесоруб", false, "древесина и уголь"),
    FARMER("Земледелец", false, "урожай, хлеб, мёд"),
    HERDER("Скотовод", false, "скот, шерсть, мясо, кони"),
    SMITH("Кузнец", false, "сталь, оружие, броня, инструменты"),
    CARPENTER("Плотник", false, "лодки, корабли, осадные машины"),
    WEAVER("Ткач", false, "ткани, одежда, знамёна Домов"),

    HEALER("Лекарь-алхимик", true, "варка зелий (только по лицензии)"),
    MERCENARY("Наёмник", true, "вырывается при аресте, ловчее в побегах"),
    HUNTSMAN("Егерь", true, "двойной лут с чудовищ"),
    FISHER("Рыбак", true, "двойной улов и редкие находки"),
    MERCHANT("Торговец", true, "лучшие цены у скупщика"),
    SORCERER("Чародей", true, "доступ к магии Iron's Spells");

    public final String title;
    public final boolean licensed;
    public final String perk;

    Profession(String title, boolean licensed, String perk) {
        this.title = title;
        this.licensed = licensed;
        this.perk = perk;
    }
}

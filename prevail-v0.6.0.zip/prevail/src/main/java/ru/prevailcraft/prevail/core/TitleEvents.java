package ru.prevailcraft.prevail.core;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.territory.CapitalService;

import java.util.HashMap;
import java.util.Map;

/**
 * Власть видно:
 *  - титулы и цвет Дома в чате и в списке игроков (Tab): «♛ Король», «Лорд», «Сир», должность при дворе;
 *  - герольд: когда король, лорд или сановник входит в столицу, все в столице слышат объявление.
 */
public final class TitleEvents {
    private static final Map<String, Boolean> IN_CAPITAL = new HashMap<>();

    public static String title(PlayerProfile p) {
        if (CourtService.isKing(p.uuid)) return "♛ Король";
        for (CourtOffice o : CourtOffice.values()) {
            if (p.uuid.equals(CourtService.k().offices.get(o.name()))) return o.title;
        }
        return switch (p.rank) {
            case LORD -> "Лорд";
            case KNIGHT -> "Сир";
            case SERF -> "";
            default -> "";
        };
    }

    public static Component decorate(ServerPlayer sp, Component name) {
        PlayerProfile p = Players.profile(sp);
        House h = Players.house(p);
        String color = h == null ? "§f" : HouseColors.CHAT[HouseColors.clamp(h.color)];
        String t = title(p);
        MutableComponent out = Component.literal(t.isEmpty() ? "" : "§6" + t + " ");
        out.append(Component.literal(color).append(name));
        if (h != null) out.append(Component.literal(" §8[" + color + h.name + "§8]"));
        return out;
    }

    @SubscribeEvent
    public void onName(PlayerEvent.NameFormat e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        e.setDisplayname(decorate(sp, e.getUsername()));
    }

    @SubscribeEvent
    public void onTab(PlayerEvent.TabListNameFormat e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        e.setDisplayName(decorate(sp, sp.getName()));
    }

    /** Раз в 30 секунд: обновить имена (титулы могли измениться). */
    public static void refreshNames() {
        for (ServerPlayer sp : Prevail.server().getPlayerList().getPlayers()) {
            sp.refreshDisplayName();
            sp.refreshTabListName();
        }
    }

    /** Раз в секунду: герольд объявляет знатных гостей столицы. */
    public static void herald() {
        if (!CapitalService.exists()) return;
        for (ServerPlayer sp : Prevail.server().getPlayerList().getPlayers()) {
            String id = sp.getUUID().toString();
            boolean in = CapitalService.inCapital(sp.level(), sp.blockPosition());
            Boolean was = IN_CAPITAL.put(id, in);
            if (was == null || was || !in) continue;
            PlayerProfile p = Players.profile(sp);
            String t = title(p);
            if (t.isEmpty() || t.equals("Сир")) continue;
            String msg = "§6🎺 Герольд: в столицу прибыл" + (t.startsWith("♛") ? "о Его Величество " : " ") + t.replace("♛ Король", "король") + " " + p.name + "!";
            for (ServerPlayer o : Prevail.server().getPlayerList().getPlayers()) {
                if (o != sp && CapitalService.inCapital(o.level(), o.blockPosition())) o.sendSystemMessage(Component.literal(msg));
            }
        }
    }
}

package ru.prevailcraft.prevail.lock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Pos;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.menu.KeyringMenu;
import ru.prevailcraft.prevail.menu.SafeMenu;
import ru.prevailcraft.prevail.network.Network;
import ru.prevailcraft.prevail.profession.Ability;
import ru.prevailcraft.prevail.profession.AbilityService;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.SuspicionService;
import ru.prevailcraft.prevail.territory.TerritoryService;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ключи, замки, сейфы и взлом.
 *  - Ключ = медный ключ, переименованный на наковальне так, чтобы в имени был «#код» (3–8 цифр).
 *  - Запереть сундук/бочку/дверь/люк: Shift+ПКМ ключом. Отпереть замок насовсем: Shift+ПКМ тем же ключом (только кто запер).
 *  - Сейф: код задаёт владелец в окне сейфа; открыть может владелец или тот, у кого есть ключ с этим кодом.
 *  - Взлом: ПКМ по запертому отмычкой → мини-игра. Успех — замок поддаётся на 15 секунд.
 */
public final class LockService {
    private static final Pattern CODE = Pattern.compile("#(\\d{3,8})");
    public static final long BYPASS_MS = 15_000L;

    private record Session(String key, String kind, double spot, double tol, long started) {}

    private static final Map<String, Session> SESSIONS = new HashMap<>();
    private static final Map<String, Long> BYPASS = new HashMap<>();

    private LockService() {}

    // ---------- ключи ----------

    /** Код ключа из его имени (#1234), или null. */
    public static String keyCode(ItemStack s) {
        if (!s.is(ModItems.KEY.get())) return null;
        Component name = s.get(DataComponents.CUSTOM_NAME);
        if (name == null) return null;
        Matcher m = CODE.matcher(name.getString());
        return m.find() ? m.group(1) : null;
    }

    public static NonNullList<ItemStack> ringContents(ItemStack ring) {
        NonNullList<ItemStack> list = NonNullList.withSize(KeyringMenu.SIZE, ItemStack.EMPTY);
        ItemContainerContents c = ring.get(DataComponents.CONTAINER);
        if (c != null) c.copyInto(list);
        return list;
    }

    /** Есть ли у игрока ключ с кодом — в инвентаре или на связке. */
    public static boolean hasKey(ServerPlayer sp, String code) {
        if (code == null || code.isEmpty()) return false;
        Inventory inv = sp.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (code.equals(keyCode(s))) return true;
            if (s.is(ModItems.KEYRING.get())) {
                for (ItemStack k : ringContents(s)) if (code.equals(keyCode(k))) return true;
            }
        }
        return false;
    }

    // ---------- замки на сундуках и дверях ----------

    public static boolean lockable(BlockState st) {
        return st.getBlock() instanceof ChestBlock || st.getBlock() instanceof BarrelBlock
                || st.getBlock() instanceof DoorBlock || st.getBlock() instanceof TrapDoorBlock;
    }

    /** Нижняя половина двери — один замок на всю дверь. */
    public static BlockPos normalize(BlockState st, BlockPos pos) {
        if (st.getBlock() instanceof DoorBlock && st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER) return pos.below();
        return pos;
    }

    public static String lockKey(Level level, BlockState st, BlockPos pos) {
        return Pos.blockKey(level, normalize(st, pos));
    }

    public static LockInfo lockAt(Level level, BlockState st, BlockPos pos) {
        return Prevail.data().locks.get(lockKey(level, st, pos));
    }

    /** Shift+ПКМ ключом: запереть или снять свой замок. */
    public static void toggleLock(ServerPlayer sp, Level level, BlockState st, BlockPos pos, String code) {
        String key = lockKey(level, st, pos);
        LockInfo cur = Prevail.data().locks.get(key);
        String me = sp.getUUID().toString();
        if (cur != null) {
            if (!cur.code.equals(code) || !cur.owner.equals(me)) throw new PrevailException("Снять замок может только тот, кто запер, своим ключом.");
            Prevail.data().locks.remove(key);
            partner(level, st, pos, null, me);
            sp.sendSystemMessage(Component.literal("§7Замок снят."), true);
            return;
        }
        PlayerProfile p = Players.profile(sp);
        House land = TerritoryService.houseAt(level, pos.getX() >> 4, pos.getZ() >> 4);
        if (land != null && !land.id.equals(p.houseId)) throw new PrevailException("Нельзя вешать замки на чужой земле.");
        LockInfo li = new LockInfo(code, me);
        Prevail.data().locks.put(key, li);
        partner(level, st, pos, li, me);
        sp.sendSystemMessage(Component.literal("§aЗаперто на ключ #" + code + "."), true);
    }

    /** Вторая половина двойного сундука запирается тем же замком. */
    private static void partner(Level level, BlockState st, BlockPos pos, LockInfo li, String me) {
        if (!(st.getBlock() instanceof ChestBlock) || st.getValue(ChestBlock.TYPE) == ChestType.SINGLE) return;
        BlockPos other = pos.relative(ChestBlock.getConnectedDirection(st));
        String k = Pos.blockKey(level, other);
        if (li == null) Prevail.data().locks.remove(k);
        else Prevail.data().locks.put(k, li);
    }

    public static boolean bypassed(ServerPlayer sp, String key) {
        Long until = BYPASS.get(sp.getUUID() + "|" + key);
        return until != null && until > System.currentTimeMillis();
    }

    // ---------- сейф ----------

    public static void useSafe(ServerPlayer sp, Level level, BlockPos pos) {
        if (!(level.getBlockEntity(pos) instanceof SafeBlockEntity be)) return;
        String key = Pos.blockKey(level, pos);
        if (be.owner.isEmpty()) be.owner = sp.getUUID().toString();
        if (be.isOwner(sp) || hasKey(sp, be.code) || bypassed(sp, key)) {
            openSafe(sp, be);
            return;
        }
        if (sp.getMainHandItem().is(ModItems.LOCKPICK.get())) {
            startPick(sp, key, "safe", pos);
            return;
        }
        throw new PrevailException(be.code.isEmpty() ? "Сейф заперт. Ключа к нему ещё нет." : "Сейф заперт. Нужен ключ или отмычка.");
    }

    public static void openSafe(ServerPlayer sp, SafeBlockEntity be) {
        sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new SafeMenu(id, inv, be), Component.literal("Сейф")));
        sendSafeInfo(sp, be);
    }

    public static void sendSafeInfo(ServerPlayer sp, SafeBlockEntity be) {
        boolean owner = be.isOwner(sp);
        Network.openScreen(sp, "safe_info", "owner=" + (owner ? 1 : 0) + ";code=" + (owner ? be.code : (be.code.isEmpty() ? "" : "****"))
                + ";ind=" + (be.indestructible ? 1 : 0));
    }

    public static void setSafeCode(ServerPlayer sp, String code) {
        if (!(sp.containerMenu instanceof SafeMenu m) || m.safe() == null) throw new PrevailException("Сейф не открыт.");
        SafeBlockEntity be = m.safe();
        if (!be.isOwner(sp)) throw new PrevailException("Код задаёт только владелец.");
        if (!code.matches("\\d{3,8}")) throw new PrevailException("Код — от 3 до 8 цифр.");
        be.code = code;
        be.setChanged();
        sp.sendSystemMessage(Component.literal("§aКод сейфа: " + code + ". Переименуйте медный ключ на наковальне в «Ключ #" + code + "»."));
        sendSafeInfo(sp, be);
    }

    // ---------- взлом ----------

    public static void startPick(ServerPlayer sp, String key, String kind, BlockPos pos) {
        PlayerProfile p = Players.profile(sp);
        int burg = AbilityService.level(p, Ability.BURGLAR);
        double tol = (kind.equals("safe") ? 5 : kind.equals("door") ? 12 : 9) + 2 * burg;
        double spot = 10 + ThreadLocalRandom.current().nextDouble() * 160;
        SESSIONS.put(sp.getUUID().toString(), new Session(key, kind, spot, tol, System.currentTimeMillis()));
        int picks = 0;
        for (int i = 0; i < sp.getInventory().getContainerSize(); i++) {
            ItemStack s = sp.getInventory().getItem(i);
            if (s.is(ModItems.LOCKPICK.get())) picks += s.getCount();
        }
        Network.openScreen(sp, "lockpick", "kind=" + kind + ";spot=" + spot + ";tol=" + tol + ";stress=" + (6 - burg) + ";picks=" + picks);
    }

    public static void pickSuccess(ServerPlayer sp) {
        Session s = SESSIONS.remove(sp.getUUID().toString());
        if (s == null || System.currentTimeMillis() - s.started < 1200) return;
        Pos pos = Pos.fromBlockKey(s.key);
        if (!pos.near(sp, 6)) return;
        BYPASS.put(sp.getUUID() + "|" + s.key, System.currentTimeMillis() + BYPASS_MS);
        PlayerProfile p = Players.profile(sp);
        AbilityService.addXp(p, Ability.BURGLAR, s.kind.equals("safe") ? 40 : 20);
        BlockPos bp = new BlockPos((int) Math.floor(pos.x), (int) Math.floor(pos.y) - 1, (int) Math.floor(pos.z));
        SuspicionService.onAction(sp, bp, 10, "взламывает замок");
        sp.sendSystemMessage(Component.literal("§aЗамок поддался! У вас 15 секунд."), true);
        if (s.kind.equals("safe") && sp.level().getBlockEntity(bp) instanceof SafeBlockEntity be) openSafe(sp, be);
    }

    public static void pickBreak(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        if (AbilityService.level(p, Ability.BURGLAR) >= 3 && ThreadLocalRandom.current().nextBoolean()) {
            sp.sendSystemMessage(Component.literal("§eОтмычка выдержала."), true);
            return;
        }
        Inventory inv = sp.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(ModItems.LOCKPICK.get())) {
                s.shrink(1);
                sp.sendSystemMessage(Component.literal("§cОтмычка сломалась."), true);
                return;
            }
        }
    }

    // ---------- связка ключей ----------

    public static void openKeyring(ServerPlayer sp) {
        sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new KeyringMenu(id, inv), Component.literal("Связка ключей")));
    }
}

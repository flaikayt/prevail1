package ru.prevailcraft.prevail.profession;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.event.brewing.PlayerBrewedPotionEvent;
import net.neoforged.neoforge.event.entity.living.BabyEntitySpawnEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.player.ItemFishedEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockDropsEvent;
import ru.prevailcraft.prevail.compat.IronsCompat;
import ru.prevailcraft.prevail.compat.ItemData;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Профессии работают на сервере через дропы и результаты крафта — клиенту ничего синхронизировать не нужно.
 *  - Руда: не-рудокоп с шансом 50% получает пустую породу; рудокоп чужой ветки — всегда.
 *  - Брёвна, урожай, скот: без ремесла 50% добычи пропадает; специалист — шанс удвоения (4% за ранг, ветка ×2).
 *  - Оружие/броня/инструменты: качество и клеймо мастера; без кузнеца — «Грубое».
 *  - Варочная стойка — только лекарь; блоки Iron's Spells — только чародей.
 */
public final class ProfessionEvents {

    private static boolean chance(double p) {
        return ThreadLocalRandom.current().nextDouble() < p;
    }

    private static void duplicate(List<ItemEntity> drops) {
        List<ItemEntity> extra = new ArrayList<>();
        for (ItemEntity ie : drops) extra.add(new ItemEntity(ie.level(), ie.getX(), ie.getY(), ie.getZ(), ie.getItem().copy()));
        drops.addAll(extra);
    }

    private static void wasteRock(BlockDropsEvent e) {
        e.getDrops().clear();
        var pos = e.getPos();
        e.getDrops().add(new ItemEntity(e.getLevel(), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.GRAVEL)));
    }

    @SubscribeEvent
    public void onDrops(BlockDropsEvent e) {
        if (!Prevail.running() || !(e.getBreaker() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        BlockState st = e.getState();
        int rank = ProfessionService.rank(prof);

        if (st.is(Tags.Blocks.ORES)) {
            if (prof.profession != Profession.MINER) {
                if (chance(0.5)) {
                    wasteRock(e);
                    p.sendSystemMessage(Component.literal("§7Неумело — руда раскрошилась в пустую породу. Нужен рудокоп."), true);
                }
                return;
            }
            if (!ProfessionService.branchOk(prof, Branch.VEIN)) {
                wasteRock(e);
                p.sendSystemMessage(Component.literal("§7Камнелом не умеет брать руду — только пустую породу."), true);
                return;
            }
            ProfessionService.addXp(prof, Profession.MINER, 3);
            if (chance(rank * 0.04 * (prof.branch == Branch.VEIN ? 2 : 1))) duplicate(e.getDrops());
            return;
        }
        if (st.is(BlockTags.BASE_STONE_OVERWORLD) || st.is(Blocks.CLAY) || st.is(Blocks.COBBLED_DEEPSLATE)) {
            if (prof.profession == Profession.MINER) {
                if (chance(0.2)) ProfessionService.addXp(prof, Profession.MINER, 1);
                if (prof.branch == Branch.STONE && chance(rank * 0.08)) duplicate(e.getDrops());
            }
            return;
        }
        if (st.is(BlockTags.LOGS)) {
            if (prof.profession != Profession.LUMBERJACK) {
                if (chance(0.5)) e.getDrops().clear();
                return;
            }
            ProfessionService.addXp(prof, Profession.LUMBERJACK, 1);
            if (chance(rank * 0.04 * (prof.branch == Branch.FORESTER ? 2 : 1))) duplicate(e.getDrops());
            return;
        }
        if (st.getBlock() instanceof CropBlock crop && crop.isMaxAge(st)) {
            if (prof.profession != Profession.FARMER) {
                if (chance(0.5)) e.getDrops().clear();
                return;
            }
            ProfessionService.addXp(prof, Profession.FARMER, 1);
            boolean grain = st.is(Blocks.WHEAT);
            boolean branchBonus = (grain && prof.branch == Branch.GRAIN) || (!grain && prof.branch == Branch.GARDENER);
            if (chance(rank * 0.04 * (branchBonus ? 2 : 1))) duplicate(e.getDrops());
        }
    }

    @SubscribeEvent
    public void onMobDrops(LivingDropsEvent e) {
        if (!Prevail.running() || !(e.getSource().getEntity() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        if (e.getEntity() instanceof Animal) {
            if (prof.profession != Profession.HERDER) {
                if (chance(0.5)) e.getDrops().clear();
                return;
            }
            ProfessionService.addXp(prof, Profession.HERDER, 2);
            double c = ProfessionService.rank(prof) * 0.04 * (prof.branch == Branch.SHEPHERD ? 2 : 1);
            if (chance(c)) {
                List<ItemEntity> copy = new ArrayList<>(e.getDrops());
                int n = copy.size();
                duplicate(copy);
                e.getDrops().addAll(copy.subList(n, copy.size()));
            }
        } else if (e.getEntity() instanceof Enemy && prof.license == Profession.HUNTSMAN) {
            ProfessionService.addLicenseXp(prof, Profession.HUNTSMAN, 3);
            if (chance(0.15 + ProfessionService.licenseRank(prof) * 0.07)) {
                List<ItemEntity> copy = new ArrayList<>(e.getDrops());
                int n = copy.size();
                duplicate(copy);
                e.getDrops().addAll(copy.subList(n, copy.size()));
            }
        }
    }

    @SubscribeEvent
    public void onBreed(BabyEntitySpawnEvent e) {
        if (!Prevail.running() || !(e.getCausedByPlayer() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        ProfessionService.addXp(prof, Profession.HERDER, prof.branch == Branch.HORSEMASTER ? 8 : 4);
    }

    @SubscribeEvent
    public void onFish(ItemFishedEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        if (prof.license != Profession.FISHER) return;
        ProfessionService.addLicenseXp(prof, Profession.FISHER, 3);
        if (chance(0.15 + ProfessionService.licenseRank(prof) * 0.07)) {
            for (ItemStack s : e.getDrops()) {
                ItemStack c = s.copy();
                if (!p.getInventory().add(c)) p.drop(c, false);
            }
            p.sendSystemMessage(Component.literal("§bДвойной улов!"), true);
        }
    }

    @SubscribeEvent
    public void onBrew(PlayerBrewedPotionEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        ProfessionService.addLicenseXp(Players.profile(p), Profession.HEALER, 2);
    }

    /** Лицензионные блоки: варочная стойка и магия Iron's. */
    @SubscribeEvent
    public void onUseBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        BlockState st = e.getLevel().getBlockState(e.getPos());
        PlayerProfile prof = Players.profile(p);
        if (st.is(Blocks.BREWING_STAND) && prof.license != Profession.HEALER) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cВарить зелья может только лекарь-алхимик с лицензией."), true);
        } else if (IronsCompat.loaded() && IronsCompat.MODID.equals(VersionCompat.blockNamespace(st.getBlock()))
                && prof.license != Profession.SORCERER) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cМагией владеют только чародеи с лицензией."), true);
        }
    }

    @SubscribeEvent
    public void onUseItem(PlayerInteractEvent.RightClickItem e) {
        if (!Prevail.running() || e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (!IronsCompat.loaded() || !IronsCompat.MODID.equals(VersionCompat.itemNamespace(e.getItemStack().getItem()))) return;
        if (Players.profile(p).license != Profession.SORCERER) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cСвитки и книги заклинаний подчиняются только чародеям."), true);
        }
    }

    @SubscribeEvent
    public void onCraft(PlayerEvent.ItemCraftedEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getCrafting();
        PlayerProfile prof = Players.profile(p);

        boolean weapon = s.is(ItemTags.SWORDS) || s.is(Items.BOW) || s.is(Items.CROSSBOW) || s.is(Items.MACE);
        boolean armor = s.is(ItemTags.HEAD_ARMOR) || s.is(ItemTags.CHEST_ARMOR) || s.is(ItemTags.LEG_ARMOR) || s.is(ItemTags.FOOT_ARMOR);
        boolean tool = s.is(ItemTags.PICKAXES) || s.is(ItemTags.AXES) || s.is(ItemTags.SHOVELS) || s.is(ItemTags.HOES);

        if ((weapon || armor || tool) && s.isDamageableItem()) {
            boolean leather = s.is(Items.LEATHER_HELMET) || s.is(Items.LEATHER_CHESTPLATE) || s.is(Items.LEATHER_LEGGINGS) || s.is(Items.LEATHER_BOOTS);
            Quality q;
            if (leather && prof.profession == Profession.WEAVER) {
                q = ProfessionService.branchOk(prof, Branch.TAILOR) ? Quality.roll(ProfessionService.rank(prof)) : Quality.ROUGH;
                ProfessionService.addXp(prof, Profession.WEAVER, 4);
            } else if (prof.profession == Profession.SMITH) {
                boolean ok = tool || (weapon && ProfessionService.branchOk(prof, Branch.WEAPONSMITH))
                        || (armor && ProfessionService.branchOk(prof, Branch.ARMORER));
                q = ok ? Quality.roll(ProfessionService.rank(prof)) : Quality.ROUGH;
                ProfessionService.addXp(prof, Profession.SMITH, ok ? 6 : 1);
            } else {
                q = Quality.ROUGH;
            }
            stamp(s, q, prof);
            if (q == Quality.ROUGH) p.sendSystemMessage(Component.literal("§7Без мастера вещь вышла грубой (½ прочности)."), true);
            return;
        }
        if (s.is(ItemTags.BOATS)) ProfessionService.addXp(prof, Profession.CARPENTER, prof.branch == Branch.SHIPWRIGHT ? 8 : 4);
        else if (s.is(ItemTags.BANNERS)) ProfessionService.addXp(prof, Profession.WEAVER, prof.branch == Branch.BANNERMAKER ? 6 : 3);
        else if (s.is(Items.BREAD) || s.is(Items.CAKE)) ProfessionService.addXp(prof, Profession.FARMER, s.getCount());
    }

    /** Качество + клеймо мастера. */
    public static void stamp(ItemStack s, Quality q, PlayerProfile maker) {
        ItemData.setMaxDamage(s, (int) Math.round(s.getMaxDamage() * q.durability));
        House h = Players.house(maker);
        ItemData.putString(s, "quality", q.name());
        ItemData.lore(s, q.color + "Качество: " + q.title,
                "§8Работа: " + maker.name + (h != null ? " (Дом " + h.name + ")" : ""));
    }

    @SubscribeEvent
    public void onSmelt(PlayerEvent.ItemSmeltedEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        ItemStack s = e.getSmelting();
        if (s.is(Items.CHARCOAL)) {
            ProfessionService.addXp(prof, Profession.LUMBERJACK, s.getCount());
            if (prof.branch == Branch.COLLIER && chance(ProfessionService.rank(prof) * 0.1)) {
                ItemStack bonus = new ItemStack(Items.CHARCOAL, s.getCount());
                if (!p.getInventory().add(bonus)) p.drop(bonus, false);
            }
        }
    }
}

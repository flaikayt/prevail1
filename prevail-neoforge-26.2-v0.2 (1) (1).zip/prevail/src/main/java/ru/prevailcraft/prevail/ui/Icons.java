package ru.prevailcraft.prevail.ui;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import ru.prevailcraft.prevail.compat.ItemData;

/** Иконки для GUI. */
public final class Icons {
    private Icons() {}

    public static ItemStack of(Item item, String name, String... lore) {
        ItemStack s = new ItemStack(item);
        ItemData.name(s, name);
        if (lore.length > 0) ItemData.lore(s, lore);
        return s;
    }

    public static ItemStack of(Item item, int count, String name, String... lore) {
        ItemStack s = of(item, name, lore);
        s.setCount(Math.max(1, Math.min(99, count)));
        return s;
    }

    public static ItemStack pane() {
        return of(Items.GLASS_PANE, " ");
    }

    /** Заполнить пустые слоты рамкой. */
    public static void frame(ChestGui gui) {
        for (int i = 0; i < gui.size(); i++) if (gui.icons[i] == null || gui.icons[i].isEmpty()) gui.set(i, pane(), null);
    }

    public static String bar(double frac) {
        int n = (int) Math.round(Math.max(0, Math.min(1, frac)) * 10);
        return "§a" + "█".repeat(n) + "§8" + "█".repeat(10 - n);
    }
}

package ru.prevailcraft.prevail.menu;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.lock.LockService;
import ru.prevailcraft.prevail.lock.SafeBlockEntity;
import ru.prevailcraft.prevail.registry.ModMenus;

/** Окно сейфа: 3×3 ячейки. Кнопка 1 — переключить «нерушимый» (только владелец). */
public class SafeMenu extends AbstractContainerMenu {
    private final Container box;
    private final SafeBlockEntity safe;

    public SafeMenu(int id, Inventory inv) {
        this(id, inv, null);
    }

    public SafeMenu(int id, Inventory inv, SafeBlockEntity safe) {
        super(ModMenus.SAFE.get(), id);
        this.safe = safe;
        this.box = safe != null ? safe : new SimpleContainer(SafeBlockEntity.SIZE);
        for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) addSlot(new Slot(box, c + r * 3, 62 + c * 18, 17 + r * 18));
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 84 + r * 18));
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, 8 + c * 18, 142));
    }

    public SafeBlockEntity safe() {
        return safe;
    }

    @Override
    public boolean clickMenuButton(Player p, int id) {
        if (id == 1 && safe != null && p instanceof ServerPlayer sp && safe.isOwner(sp)) {
            safe.indestructible = !safe.indestructible;
            safe.setChanged();
            LockService.sendSafeInfo(sp, safe);
            return true;
        }
        return false;
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot.hasItem()) {
            ItemStack st = slot.getItem();
            result = st.copy();
            if (index < 9) {
                if (!moveItemStackTo(st, 9, 45, true)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(st, 0, 9, false)) {
                return ItemStack.EMPTY;
            }
            if (st.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player p) {
        return safe == null || safe.stillValid(p);
    }
}

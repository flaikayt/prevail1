package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import ru.prevailcraft.prevail.client.PrevailClient;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.menu.SafeMenu;

import java.util.HashMap;
import java.util.Map;

/** Окно сейфа: 3×3, поле «Код» (видит владелец), галочка «Нерушимый». */
public class SafeScreen extends AbstractContainerScreen<SafeMenu> {
    /** Последние данные от сервера (safe_info). */
    public static Map<String, String> INFO = new HashMap<>();
    private EditBox code;

    public SafeScreen(SafeMenu menu, Inventory inv, Component title) {
        super(menu, inv, title, 176, 166);
        this.inventoryLabelY = this.imageHeight - 94;
    }

    private boolean owner() {
        return "1".equals(INFO.get("owner"));
    }

    @Override
    protected void init() {
        super.init();
        code = new EditBox(font, leftPos + imageWidth - 64, topPos - 20, 60, 14, Component.literal("Код"));
        code.setMaxLength(8);
        code.setValue(INFO.getOrDefault("code", ""));
        code.setEditable(owner());
        addRenderableWidget(code);
        if (owner()) {
            addRenderableWidget(Button.builder(Component.literal("Задать"), b -> PrevailClient.send("safe_code", code.getValue().trim()))
                    .bounds(leftPos + imageWidth - 64, topPos - 4 + imageHeight + 8, 60, 16).build());
            addRenderableWidget(Button.builder(Component.literal("Нерушимый"), b -> {
                if (minecraft.gameMode != null) minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 1);
            }).bounds(leftPos, topPos + imageHeight + 4, 90, 16).build());
        }
    }

    /** Вызывается, когда пришёл новый safe_info. */
    public void refresh() {
        if (code != null && !code.isFocused()) code.setValue(INFO.getOrDefault("code", ""));
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(g, mouseX, mouseY, partialTick);
        int x = leftPos, y = topPos;
        Ui.panel(g, x, y, imageWidth, imageHeight, 0xFF4A4A50);
        Ui.fill(g, x + 58, y + 13, x + 118, y + 73, 0xFF2A2A2E);
        for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) Ui.slot(g, x + 61 + c * 18, y + 16 + r * 18);
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 83 + r * 18);
        for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 141);
        Ui.text(g, "Код", x + imageWidth - 88, y - 17, Ui.WHITE, true);
        boolean ind = "1".equals(INFO.get("ind"));
        int cx = owner() ? x + 94 : x;
        Ui.fill(g, cx, y + imageHeight + 8, cx + 8, y + imageHeight + 16, 0xFF1A1A1A);
        if (ind) Ui.fill(g, cx + 2, y + imageHeight + 10, cx + 6, y + imageHeight + 14, 0xFF55FF55);
        Ui.text(g, "Нерушимый", cx + 12, y + imageHeight + 8, Ui.WHITE, true);
    }

    @Override
    protected void extractLabels(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        g.text(font, title, titleLabelX, titleLabelY, 0xFFE0E0E0, false);
        g.text(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, 0xFFE0E0E0, false);
        if (!owner()) Ui.text(g, "Ключ: «#код»", 122, 20, 0xFFAAAAAA, false);
    }
}

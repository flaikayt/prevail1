package ru.prevailcraft.prevail.law;

import ru.prevailcraft.prevail.core.Pos;

/** Заключение. Срок идёт только онлайн; каторга сокращает его. */
public final class PrisonTerm {
    public String prisoner;
    public Pos cell;
    public long remainingSeconds;
    /** id Дома-тюремщика или "crown". */
    public String jailer;
    public String reason;
    /** Награда, за которую поймали (при побеге — удваивается). */
    public long bounty;
    public long lastEffects;

    public PrisonTerm() {}
}

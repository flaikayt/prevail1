package ru.prevailcraft.prevail.profession;

/**
 * Умения — дополнительная прокачка без канцлера. Игрок берёт до 2 умений,
 * у каждого 3 уровня; опыт идёт от соответствующих действий.
 */
public enum Ability {
    HEALER("Лекарь-алхимик", "minecraft:brewing_stand", "варка зелий",
            new String[]{"Может варить зелья", "20% шанс лишнего зелья", "35% шанс лишнего зелья"}),
    MERCENARY("Наёмник", "minecraft:iron_sword", "бой и побеги",
            new String[]{"15% вырваться из кандалов", "25% вырваться, +10% побег", "35% вырваться, +20% побег"}),
    HUNTSMAN("Егерь", "minecraft:bow", "трофеи с чудовищ",
            new String[]{"15% двойной трофей", "25% двойной трофей", "35% двойной трофей"}),
    FISHER("Рыбак", "minecraft:fishing_rod", "двойной улов",
            new String[]{"15% двойной улов", "25% двойной улов", "35% двойной улов"}),
    MERCHANT("Торговец", "minecraft:emerald", "цены у скупщика",
            new String[]{"Скупщик платит +10%", "Скупщик платит +15%", "Скупщик платит +20%"}),
    SORCERER("Чародей", "minecraft:enchanted_book", "магия (с эпохи «Магия»)",
            new String[]{"Доступ к магии Iron's Spells", "Исток: +30% силы заклинаний", "Исток: +40% силы заклинаний"}),
    BURGLAR("Взломщик", "minecraft:tripwire_hook", "отмычки и замки",
            new String[]{"+10% к взлому отмычкой", "+20% к взлому отмычкой", "+30%, отмычка ломается реже"}),
    COOK("Повар", "minecraft:bread", "сытная еда",
            new String[]{"Еда даёт +1 сытости", "Еда даёт +2 сытости", "Еда даёт +3 сытости"}),
    RUNNER("Скороход", "minecraft:leather_boots", "скорость бега",
            new String[]{"+5% к скорости", "+10% к скорости", "+15% к скорости"}),
    ARMORED("Латник", "minecraft:iron_chestplate", "стойкость в бою",
            new String[]{"+1 к броне", "+2 к броне", "+3 к броне"});

    public static final int MAX_ABILITIES = 2;
    public static final long[] XP = {0, 300, 1000};

    public final String title;
    public final String icon;
    public final String perk;
    public final String[] levels;

    Ability(String title, String icon, String perk, String[] levels) {
        this.title = title;
        this.icon = icon;
        this.perk = perk;
        this.levels = levels;
    }

    public static int levelFor(long xp) {
        return xp >= XP[2] ? 3 : xp >= XP[1] ? 2 : 1;
    }
}

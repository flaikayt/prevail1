package ru.prevailcraft.prevail.compat;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;

import java.util.ArrayList;
import java.util.List;

/**
 * Данные внутри предметов (кошелёк, регалии, температура стали, клеймо мастера).
 * Используется компонент minecraft:custom_data — он не требует регистрации своих типов.
 * Под 26.2: CompoundTag#getXxxOr(key, default) (появились в 1.21.5).
 */
public final class ItemData {
    private ItemData() {}

    public static long getLong(ItemStack s, String key) {
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        return cd == null ? 0L : cd.copyTag().getLongOr(key, 0L);
    }

    public static void putLong(ItemStack s, String key, long v) {
        CustomData.update(DataComponents.CUSTOM_DATA, s, t -> t.putLong(key, v));
    }

    public static String getString(ItemStack s, String key) {
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        return cd == null ? "" : cd.copyTag().getStringOr(key, "");
    }

    public static void putString(ItemStack s, String key, String v) {
        CustomData.update(DataComponents.CUSTOM_DATA, s, t -> t.putString(key, v));
    }

    public static void name(ItemStack s, String name) {
        s.set(DataComponents.CUSTOM_NAME, Component.literal(name));
    }

    public static void lore(ItemStack s, String... lines) {
        List<Component> list = new ArrayList<>();
        for (String l : lines) list.add(Component.literal(l));
        s.set(DataComponents.LORE, new ItemLore(list));
    }

    public static void setMaxDamage(ItemStack s, int max) {
        s.set(DataComponents.MAX_DAMAGE, Math.max(1, max));
    }
}

package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.client.PrevailClient;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.economy.Money;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Королевский рынок: сетка товаров, выбор количества (1/16/64), клик — купить. */
public class MarketScreen extends Screen {
    private static final int W = 200, H = 178, COLS = 9;

    private record Good(String id, long price, long stock) {}

    private final List<Good> goods = new ArrayList<>();
    private final List<Button> goodButtons = new ArrayList<>();
    private long money;
    private int qty = 1;
    private int left, top;

    public MarketScreen(Map<String, String> d) {
        super(Component.literal("Королевский рынок"));
        read(d);
    }

    private void read(Map<String, String> d) {
        goods.clear();
        money = Long.parseLong(d.getOrDefault("money", "0"));
        for (String g : Ui.split(d.getOrDefault("items", ""), '/')) {
            String[] f = g.split(",");
            if (f.length == 3) goods.add(new Good(f[0], Long.parseLong(f[1]), Long.parseLong(f[2])));
        }
    }

    public void update(Map<String, String> d) {
        read(d);
        rebuildWidgets();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        goodButtons.clear();
        for (int i = 0; i < goods.size(); i++) {
            Good gd = goods.get(i);
            Button b = Button.builder(Component.empty(), btn -> PrevailClient.send("market_buy", gd.id() + "|" + qty))
                    .bounds(left + 10 + (i % COLS) * 20, top + 26 + (i / COLS) * 20, 20, 20).build();
            b.active = gd.stock() > 0;
            goodButtons.add(b);
            addRenderableWidget(b);
        }
        int x = left + 10;
        for (int q : new int[]{1, 16, 64}) {
            addRenderableWidget(Button.builder(Component.literal("×" + q), btn -> qty = q).bounds(x, top + H - 30, 34, 20).build());
            x += 38;
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        Ui.panel(g, left, top, W, H, Ui.WOOD);
        Ui.fill(g, left + 6, top + 22, left + W - 6, top + H - 70, Ui.WOOD_DARK);
        Ui.text(g, "Королевский рынок", left + 10, top + 8, 0xFF2A1A08, false);
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        Good hovered = null;
        for (int i = 0; i < goodButtons.size(); i++) {
            Button b = goodButtons.get(i);
            Good gd = goods.get(i);
            Ui.item(g, gd.id(), b.getX() + 2, b.getY() + 2);
            if (gd.stock() <= 0) Ui.fill(g, b.getX() + 2, b.getY() + 2, b.getX() + 18, b.getY() + 18, 0x99000000);
            if (b.isHovered()) hovered = gd;
        }
        // выбранное количество
        Ui.outline(g, left + 10 + (qty == 1 ? 0 : qty == 16 ? 38 : 76) - 1, top + H - 31, 36, 22, Ui.GOLD);

        int iy = top + H - 64;
        if (hovered != null) {
            String name = new ItemStack(VersionCompat.item(hovered.id())).getHoverName().getString();
            Ui.text(g, name, left + 10, iy, Ui.WHITE, true);
            Ui.text(g, "Цена: " + Money.fmt(hovered.price()) + " · на складе: " + hovered.stock(), left + 10, iy + 11, Ui.GOLD, true);
            Ui.text(g, "Купить ×" + qty + ": " + Money.fmt(hovered.price() * qty), left + 10, iy + 22, Ui.WHITE, true);
        } else {
            Ui.text(g, "Наведите на товар. Товар появляется,", left + 10, iy, 0xFF2A1A08, false);
            Ui.text(g, "когда его сдают скупщику.", left + 10, iy + 11, 0xFF2A1A08, false);
        }
        Ui.item(g, "prevail:copper_coin", left + W - 82, top + H - 28);
        Ui.text(g, Money.fmt(money), left + W - 64, top + H - 24, 0xFF2A1A08, false);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import ru.prevailcraft.prevail.client.PrevailClient;
import ru.prevailcraft.prevail.client.Ui;

import java.util.Map;

/**
 * Мини-игра взлома: мышь — угол отмычки (верхняя полуокружность), Shift — зафиксировать угол,
 * Space — давить (поворачивать цилиндр). Чем ближе угол к «точке», тем дальше поворачивается замок.
 * Давить в упор нельзя — растёт износ (красная полоса), на 100% отмычка ломается.
 */
public class LockpickScreen extends Screen {
    private final String kind;
    private final double spot, tol, stressRate;
    private final int picks;
    private double angle = 90, rot = 0, stress = 0;
    private boolean fixed, shiftWas, done;
    private int lastMx, lastMy;

    public LockpickScreen(Map<String, String> d) {
        super(Component.literal("Взлом"));
        kind = d.getOrDefault("kind", "chest");
        spot = Double.parseDouble(d.getOrDefault("spot", "90"));
        tol = Double.parseDouble(d.getOrDefault("tol", "8"));
        stressRate = Double.parseDouble(d.getOrDefault("stress", "6"));
        picks = Integer.parseInt(d.getOrDefault("picks", "1"));
    }

    private int cx() {
        return width / 2;
    }

    private int cy() {
        return height / 2 - 10;
    }

    @Override
    public void tick() {
        if (done) return;
        boolean shift = Ui.keyDown(GLFW.GLFW_KEY_LEFT_SHIFT);
        if (shift && !shiftWas) fixed = !fixed;
        shiftWas = shift;
        if (!fixed) {
            double a = Math.toDegrees(Math.atan2(cy() - lastMy, lastMx - cx()));
            angle = Math.max(0, Math.min(180, a));
        }
        double off = Math.max(0, Math.abs(angle - spot) - tol);
        double allowed = 90 * Math.max(0, 1 - off / (tol * 4));
        if (Ui.keyDown(GLFW.GLFW_KEY_SPACE)) {
            if (rot < allowed) rot = Math.min(allowed, rot + 6);
            else stress += stressRate;
        } else {
            rot = Math.max(0, rot - 10);
            stress = Math.max(0, stress - 1);
        }
        if (rot >= 89.5) {
            done = true;
            PrevailClient.send("pick_success", "");
            onClose();
        } else if (stress >= 100) {
            done = true;
            PrevailClient.send("pick_break", "");
            onClose();
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        lastMx = mouseX;
        lastMy = mouseY;
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        int cx = cx(), cy = cy(), R = 42;
        // корпус замка
        for (int dy = -R - 4; dy <= R + 4; dy++) {
            int half = (int) Math.sqrt(Math.max(0, (R + 4) * (R + 4) - dy * dy));
            Ui.fill(g, cx - half, cy + dy, cx + half, cy + dy + 1, 0xFF6B4A2E);
        }
        for (int dy = -R; dy <= R; dy++) {
            int half = (int) Math.sqrt(Math.max(0, R * R - dy * dy));
            Ui.fill(g, cx - half, cy + dy, cx + half, cy + dy + 1, "safe".equals(kind) ? 0xFF8A9098 : 0xFFD08A5A);
        }
        for (int i = 0; i < 12; i++) {
            double a = Math.toRadians(i * 30);
            int px = cx + (int) (Math.cos(a) * (R - 5)), py = cy + (int) (Math.sin(a) * (R - 5));
            Ui.fill(g, px - 1, py - 1, px + 1, py + 1, 0xFF3A2614);
        }
        // замочная скважина поворачивается с цилиндром
        double kr = Math.toRadians(90 + rot);
        for (int t = -2; t <= 9; t++) {
            int px = cx + (int) Math.round(Math.cos(kr) * t), py = cy + (int) Math.round(Math.sin(kr) * t);
            Ui.fill(g, px - 2, py - 2, px + 2, py + 2, 0xFF101010);
        }
        Ui.fill(g, cx - 4, cy - 4, cx + 4, cy + 4, 0xFF101010);
        // натяжитель снизу
        Ui.fill(g, cx - 3, cy + 4, cx + 3, cy + R + 50, 0xFFB8C4D0);
        Ui.fill(g, cx - 6, cy + R + 40, cx + 6, cy + R + 56, 0xFF8A96A8);
        // отмычка
        double pa = Math.toRadians(angle);
        for (int t = 0; t < 110; t++) {
            int px = cx + (int) Math.round(Math.cos(pa) * t), py = cy - (int) Math.round(Math.sin(pa) * t);
            Ui.fill(g, px, py, px + 2, py + 2, fixed ? 0xFFFFE080 : 0xFFF0F0F0);
        }
        // износ
        int bw = 200, bx = cx - bw / 2, by = cy + R + 66;
        Ui.fill(g, bx, by, bx + bw, by + 4, 0xFF333333);
        Ui.fill(g, bx, by, bx + (int) (bw * Math.min(1, stress / 100)), by + 4, 0xFFCC2222);
        Ui.centeredFlat(g, "Мышь — угол, Shift — зафиксировать, Space — давить", cx, by + 10, 0xFFDDDDDD);
        Ui.centeredFlat(g, "Отмычек: " + picks, cx, by + 22, 0xFF999999);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

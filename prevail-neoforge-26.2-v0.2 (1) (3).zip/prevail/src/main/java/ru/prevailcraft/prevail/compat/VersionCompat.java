package ru.prevailcraft.prevail.compat;

import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import ru.prevailcraft.prevail.config.PrevailConfig;

import java.util.Optional;
import java.util.Set;

/**
 * ВСЕ места, где API Minecraft заметно менялось между версиями.
 * Если после обновления MC/NeoForge проект не собирается — начни с этого файла
 * и с ItemData.java.
 *
 * Под 26.2 (Mojang-имена): ResourceLocation → Identifier,
 * ResourceKey#location() → identifier(), ClickEvent — record-классы,
 * Entity#hurt → hurtServer(level, source, amount).
 */
public final class VersionCompat {
    private VersionCompat() {}

    public static String dimId(Level level) {
        return level.dimension().identifier().toString();
    }

    public static ServerLevel level(MinecraftServer server, String dimId) {
        return server.getLevel(ResourceKey.create(Registries.DIMENSION, Identifier.parse(dimId)));
    }

    public static String itemId(Item item) {
        return BuiltInRegistries.ITEM.getKey(item).toString();
    }

    public static Item item(String id) {
        return BuiltInRegistries.ITEM.getValue(Identifier.parse(id));
    }

    public static String blockNamespace(Block block) {
        return BuiltInRegistries.BLOCK.getKey(block).getNamespace();
    }

    public static String itemNamespace(Item item) {
        return BuiltInRegistries.ITEM.getKey(item).getNamespace();
    }

    public static void teleport(ServerPlayer p, ServerLevel level, double x, double y, double z) {
        p.teleportTo(level, x, y, z, Set.of(), p.getYRot(), p.getXRot(), true);
    }

    /** Ожог/урон без источника-сущности. */
    public static void burn(ServerPlayer p, float amount) {
        p.hurtServer((ServerLevel) p.level(), p.damageSources().hotFloor(), amount);
    }

    public static MutableComponent clickable(String text, String command) {
        return Component.literal("[" + text + "]").withStyle(s -> s
                .withColor(ChatFormatting.GREEN)
                .withUnderlined(true)
                .withClickEvent(new ClickEvent.RunCommand(command)));
    }

    // ---------- атрибуты (для мягкой интеграции с Iron's Spells) ----------

    public static Optional<Holder<Attribute>> attribute(String id) {
        return BuiltInRegistries.ATTRIBUTE.get(Identifier.parse(id)).map(h -> (Holder<Attribute>) h);
    }

    public static void addTempModifier(ServerPlayer p, Holder<Attribute> attr, String modId, double amount) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        inst.addOrUpdateTransientModifier(new AttributeModifier(
                Identifier.fromNamespaceAndPath("prevail", modId), amount, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
    }

    public static void removeModifier(ServerPlayer p, Holder<Attribute> attr, String modId) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst != null) inst.removeModifier(Identifier.fromNamespaceAndPath("prevail", modId));
    }

    // ---------- права ----------

    public static boolean isAdmin(CommandSourceStack src) {
        ServerPlayer p = src.getPlayer();
        return p == null || isAdmin(p);
    }

    public static boolean isAdmin(ServerPlayer p) {
        var admins = PrevailConfig.ADMINS.get();
        return admins.contains(p.getName().getString()) || admins.contains(p.getUUID().toString());
    }
}

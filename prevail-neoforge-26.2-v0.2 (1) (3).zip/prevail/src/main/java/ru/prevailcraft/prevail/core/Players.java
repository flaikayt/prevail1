package ru.prevailcraft.prevail.core;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import ru.prevailcraft.prevail.compat.VersionCompat;

import java.util.UUID;

/** Поиск профилей и Домов, сообщения. */
public final class Players {
    private Players() {}

    public static PlayerProfile profile(ServerPlayer p) {
        String id = p.getUUID().toString();
        PlayerProfile prof = Prevail.data().players.computeIfAbsent(id, k -> new PlayerProfile(k, p.getName().getString()));
        prof.name = p.getName().getString();
        return prof;
    }

    public static PlayerProfile profile(String uuid) {
        return uuid == null ? null : Prevail.data().players.get(uuid);
    }

    public static PlayerProfile byName(String name) {
        for (PlayerProfile p : Prevail.data().players.values()) {
            if (p.name != null && p.name.equalsIgnoreCase(name)) return p;
        }
        throw new PrevailException("Игрок «" + name + "» ещё не заходил на сервер.");
    }

    public static String name(String uuid) {
        PlayerProfile p = profile(uuid);
        return p == null ? "?" : p.name;
    }

    public static House house(PlayerProfile p) {
        return p == null || p.houseId == null ? null : Prevail.data().houses.get(p.houseId);
    }

    public static House requireHouse(PlayerProfile p) {
        House h = house(p);
        if (h == null) throw new PrevailException("Вы не состоите ни в одном Доме.");
        return h;
    }

    public static House houseByName(String name) {
        for (House h : Prevail.data().houses.values()) {
            if (h.id.equalsIgnoreCase(name) || h.name.equalsIgnoreCase(name)) return h;
        }
        throw new PrevailException("Дом «" + name + "» не найден.");
    }

    public static ServerPlayer online(String uuid) {
        if (uuid == null || Prevail.server() == null) return null;
        return Prevail.server().getPlayerList().getPlayer(UUID.fromString(uuid));
    }

    public static void message(String uuid, String text) {
        ServerPlayer p = online(uuid);
        if (p != null) p.sendSystemMessage(Component.literal(text));
    }

    /** Сообщение с кликабельной кнопкой, выполняющей команду. */
    public static void button(String uuid, String text, String buttonText, String command) {
        ServerPlayer p = online(uuid);
        if (p != null) p.sendSystemMessage(Component.literal(text + " ").append(VersionCompat.clickable(buttonText, command)));
    }

    public static void messageOfficials(House h, String text) {
        for (String m : h.members) {
            PlayerProfile pr = profile(m);
            if (pr != null && (pr.rank == Rank.LORD || pr.rank == Rank.KNIGHT)) message(m, text);
        }
    }

    public static void messageHouse(House h, String text) {
        for (String m : h.members) message(m, text);
    }

    public static void broadcast(String text) {
        Prevail.server().getPlayerList().broadcastSystemMessage(Component.literal(text), false);
    }
}

package ru.prevailcraft.prevail.economy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.registry.ModItems;

/**
 * Монеты власти — политическая валюта (не покупаются за деньги).
 * Добываются: ежедневно у Стола стратега (за себя и за активных вассалов) и из Истока.
 * Тратятся: война, посвящение в рыцари, принятие вассального Дома, королевская охота,
 * подкуп голосов, пожертвование легитимности короны.
 */
public final class PowerCoins {
    private PowerCoins() {}

    public static int count(ServerPlayer p) {
        Inventory inv = p.getInventory();
        int n = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(ModItems.POWER_COIN.get())) n += s.getCount();
        }
        return n;
    }

    /** Списать или бросить исключение с понятным текстом. */
    public static void spend(ServerPlayer p, int amount, String what) {
        if (amount <= 0) return;
        if (count(p) < amount) throw new PrevailException(what + " требует " + amount + " монет власти (у вас " + count(p) + ").");
        Inventory inv = p.getInventory();
        int left = amount;
        for (int i = 0; i < inv.getContainerSize() && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (!s.is(ModItems.POWER_COIN.get())) continue;
            int k = Math.min(left, s.getCount());
            s.shrink(k);
            left -= k;
        }
    }

    public static void give(ServerPlayer p, int amount) {
        Money.giveStacks(p, ModItems.POWER_COIN.get(), amount);
    }
}

package ru.prevailcraft.prevail.territory;

/** Участок столицы (один чанк), который канцлер сдаёт в аренду. */
public final class Plot {
    public long rentPerDay;
    public String tenant;
    public long paidUntil;

    public Plot() {}

    public boolean rentedBy(String uuid) {
        return uuid != null && uuid.equals(tenant) && paidUntil > System.currentTimeMillis();
    }

    public boolean free() {
        return tenant == null || paidUntil <= System.currentTimeMillis();
    }
}

package ru.prevailcraft.prevail.vassalage;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.compat.ItemData;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Pos;
import ru.prevailcraft.prevail.core.Rank;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.economy.PowerCoins;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.TerritoryService;
import ru.prevailcraft.prevail.war.WarService;
import ru.prevailcraft.prevail.world.Epoch;
import ru.prevailcraft.prevail.world.FundService;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Вассалитет.
 *  - Дом основывают у Фонда (свободное место + первый взнос) → лорд получает Сердце Дома и Грамоту.
 *  - Принять крепостного: ПКМ Грамотой по вольному, который присел и склонил голову.
 *  - Посвятить в рыцари: ПКМ мечом по своему коленопреклонённому крепостному.
 *  - Каждые 5 человек в Доме дают одно место рыцаря (+1 в эпоху «Рыцарство»).
 *  - Лимит прямых крепостных: лорд 8 + эпоха, рыцарь 5 + эпоха/2 — растёт вместе с миром.
 */
public final class HouseService {
    private HouseService() {}

    // ---------- проверки и лимиты ----------

    public static House requireLord(PlayerProfile p) {
        House h = Players.requireHouse(p);
        if (!p.uuid.equals(h.lord)) throw new PrevailException("Это может только лорд Дома.");
        return h;
    }

    public static House requireOfficial(PlayerProfile p) {
        House h = Players.requireHouse(p);
        if (p.rank != Rank.LORD && p.rank != Rank.KNIGHT) throw new PrevailException("Это могут только лорд и рыцари.");
        return h;
    }

    private static PlayerProfile requireMember(House h, String name) {
        PlayerProfile t = Players.byName(name);
        if (!h.id.equals(t.houseId)) throw new PrevailException(t.name + " не состоит в вашем Доме.");
        return t;
    }

    public static int serfLimit(PlayerProfile p) {
        int e = Epoch.current();
        return p.rank == Rank.LORD ? 8 + e : 5 + e / 2;
    }

    public static int directSerfs(String uuid) {
        int n = 0;
        for (PlayerProfile o : Prevail.data().players.values()) if (uuid.equals(o.liege) && o.rank == Rank.SERF) n++;
        return n;
    }

    public static int knightSlots(House h) {
        return h.members.size() / 5 + (Epoch.current() >= 6 ? 1 : 0);
    }

    public static int knights(House h) {
        int n = 0;
        for (String m : h.members) {
            PlayerProfile o = Players.profile(m);
            if (o != null && o.rank == Rank.KNIGHT) n++;
        }
        return n;
    }

    public static ItemStack makeHeart(House h) {
        ItemStack s = new ItemStack(ModItems.HOUSE_HEART.get());
        ItemData.putString(s, "house", h.id);
        ItemData.name(s, "§cСердце Дома " + h.name);
        ItemData.lore(s, "§7Вложите в Родовой очаг на земле Дома.", "§8Без Сердца Дом угасает.");
        return s;
    }

    public static ItemStack makeCharter(House h) {
        ItemStack s = new ItemStack(ModItems.HOUSE_CHARTER.get());
        ItemData.putString(s, "house", h.id);
        ItemData.name(s, "§eГрамота Дома " + h.name);
        ItemData.lore(s, "§7ПКМ по присевшему вольному,", "§7склонившему голову, — принять в Дом.");
        return s;
    }

    // ---------- Дом ----------

    public static String create(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        if (p.houseId != null) throw new PrevailException("Сначала покиньте свой Дом.");
        Pos fund = FundService.fundPos();
        if (fund == null || !fund.near(sp, 8)) throw new PrevailException("Дом основывают у Фонда в столице.");
        if (Prevail.data().houses.size() >= FundService.houseSlots()) throw new PrevailException("Свободных мест у Фонда нет — двигайте эпоху вперёд.");
        if (!name.matches("[\\p{L}0-9_]{3,24}")) throw new PrevailException("Название: 3–24 буквы, цифры или _.");
        String id = name.toLowerCase(Locale.ROOT);
        if (Prevail.data().houses.containsKey(id)) throw new PrevailException("Дом с таким названием уже есть.");
        long fee = PrevailConfig.HOUSE_FEE.get();
        if (!Money.take(sp, fee)) throw new PrevailException("Первый взнос — " + Money.fmt(fee) + ".");
        Prevail.data().kingdom.treasury += fee;

        House h = new House();
        h.id = id;
        h.name = name;
        h.lord = p.uuid;
        h.members.add(p.uuid);
        h.createdAt = System.currentTimeMillis();
        h.lastUpkeepMillis = System.currentTimeMillis();
        h.upkeep.put("fuel", 24.0);
        h.upkeep.put("food", 60.0);
        Prevail.data().houses.put(id, h);
        p.houseId = id;
        p.rank = Rank.LORD;
        p.liege = null;
        for (ItemStack s : new ItemStack[]{makeHeart(h), makeCharter(h)}) if (!sp.getInventory().add(s)) sp.drop(s, false);
        Players.broadcast("§6👑 Основан Дом " + name + ". Лорд — " + p.name + ".");
        return "Вложите Сердце в Родовой очаг на своей земле в течение 12 часов, иначе Дом начнёт голодать.";
    }

    /** Ритуал: Грамотой по присевшему вольному. */
    public static void inviteByRitual(ServerPlayer sp, ServerPlayer target) {
        PlayerProfile p = Players.profile(sp);
        House h = requireOfficial(p);
        PlayerProfile t = Players.profile(target);
        if (t.houseId != null) throw new PrevailException(t.name + " уже служит Дому.");
        if (!target.isCrouching() || target.getXRot() < 40) throw new PrevailException(t.name + " должен присесть и склонить голову.");
        if (directSerfs(p.uuid) >= serfLimit(p)) throw new PrevailException("У вас уже предельное число крепостных (" + serfLimit(p) + ").");
        h.invites.put(t.uuid, p.uuid);
        Players.button(t.uuid, "§e" + p.name + " из Дома " + h.name + " принимает вашу присягу.", "Присягнуть", "/house accept " + h.id);
        sp.sendSystemMessage(net.minecraft.network.chat.Component.literal("§7Ждём присяги " + t.name + "…"));
    }

    public static String accept(ServerPlayer sp, String houseName) {
        PlayerProfile p = Players.profile(sp);
        if (p.houseId != null) throw new PrevailException("Вы уже состоите в Доме.");
        House h = Players.houseByName(houseName);
        String inviter = h.invites.remove(p.uuid);
        if (inviter == null) throw new PrevailException("Дом " + h.name + " не принимал вашу присягу.");
        PlayerProfile lg = Players.profile(inviter);
        if (lg == null || !h.id.equals(lg.houseId)) inviter = h.lord;
        h.members.add(p.uuid);
        p.houseId = h.id;
        p.rank = Rank.SERF;
        p.liege = inviter;
        Players.messageHouse(h, "§a" + p.name + " присягнул Дому " + h.name + ". Сеньор — " + Players.name(inviter) + ".");
        return null;
    }

    /** Ритуал: лорд касается мечом коленопреклонённого крепостного. */
    public static void knightByRitual(ServerPlayer sp, ServerPlayer target) {
        PlayerProfile p = Players.profile(sp);
        House h = requireLord(p);
        PlayerProfile t = Players.profile(target);
        if (!h.id.equals(t.houseId) || t.rank != Rank.SERF) throw new PrevailException("Посвятить можно только своего крепостного.");
        if (!target.isCrouching()) throw new PrevailException(t.name + " должен преклонить колено (присесть).");
        if (knights(h) >= knightSlots(h)) throw new PrevailException("Мест для рыцарей: " + knightSlots(h) + " (по одному на каждые 5 членов Дома).");
        PowerCoins.spend(sp, PrevailConfig.PC_KNIGHT.get(), "Посвящение в рыцари");
        t.rank = Rank.KNIGHT;
        t.liege = h.lord;
        Players.broadcast("§6⚔ Лорд " + p.name + " посвятил " + t.name + " в рыцари Дома " + h.name + "! Новый домен может быть заложен.");
    }

    public static String leave(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        House h = Players.requireHouse(p);
        if (p.uuid.equals(h.lord)) throw new PrevailException("Лорд не может уйти: передайте власть или распустите Дом.");
        removeMember(h, p);
        Players.messageHouse(h, "§7" + p.name + " покинул Дом.");
        return "Вы покинули Дом " + h.name + ".";
    }

    public static String kick(ServerPlayer sp, String name) {
        House h = requireLord(Players.profile(sp));
        PlayerProfile t = requireMember(h, name);
        if (t.uuid.equals(h.lord)) throw new PrevailException("Нельзя изгнать самого себя.");
        removeMember(h, t);
        Players.message(t.uuid, "§cВы изгнаны из Дома " + h.name + ".");
        return t.name + " изгнан.";
    }

    private static void removeMember(House h, PlayerProfile t) {
        h.members.remove(t.uuid);
        for (String m : h.members) {
            PlayerProfile o = Players.profile(m);
            if (o != null && t.uuid.equals(o.liege)) o.liege = h.lord;
        }
        t.houseId = null;
        t.rank = Rank.FREEMAN;
        t.liege = null;
    }

    public static String demote(ServerPlayer sp, String name) {
        House h = requireLord(Players.profile(sp));
        PlayerProfile t = requireMember(h, name);
        if (t.rank != Rank.KNIGHT) throw new PrevailException(t.name + " не рыцарь.");
        t.rank = Rank.SERF;
        for (String m : h.members) {
            PlayerProfile o = Players.profile(m);
            if (o != null && t.uuid.equals(o.liege)) o.liege = h.lord;
        }
        t.liege = h.lord;
        return t.name + " лишён рыцарского звания.";
    }

    public static String assign(ServerPlayer sp, String serfName, String knightName) {
        House h = requireLord(Players.profile(sp));
        PlayerProfile serf = requireMember(h, serfName);
        PlayerProfile knight = requireMember(h, knightName);
        if (serf.rank != Rank.SERF) throw new PrevailException(serf.name + " не крепостной.");
        if (knight.rank != Rank.KNIGHT && knight.rank != Rank.LORD) throw new PrevailException(knight.name + " не рыцарь.");
        if (directSerfs(knight.uuid) >= serfLimit(knight)) throw new PrevailException("У " + knight.name + " предельное число крепостных.");
        serf.liege = knight.uuid;
        Players.message(serf.uuid, "§eВаш сеньор теперь — сир " + knight.name + ".");
        return serf.name + " служит рыцарю " + knight.name + ".";
    }

    public static String transfer(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        House h = requireLord(p);
        PlayerProfile t = requireMember(h, name);
        if (t.uuid.equals(p.uuid)) throw new PrevailException("Вы и так лорд.");
        h.lord = t.uuid;
        t.rank = Rank.LORD;
        t.liege = null;
        p.rank = Rank.KNIGHT;
        for (String m : h.members) {
            PlayerProfile o = Players.profile(m);
            if (o != null && p.uuid.equals(o.liege) && !o.uuid.equals(t.uuid)) o.liege = t.uuid;
        }
        p.liege = t.uuid;
        Prevail.data().kingdom.supporters.remove(p.uuid);
        Players.messageHouse(h, "§6👑 Новый лорд Дома " + h.name + " — " + t.name + ".");
        return null;
    }

    public static String disband(ServerPlayer sp) {
        House h = requireLord(Players.profile(sp));
        if (WarService.anyWar(h.id)) throw new PrevailException("Нельзя распустить Дом во время войны.");
        destroy(h);
        Players.broadcast("§7Дом " + h.name + " распущен.");
        return null;
    }

    /** Полное удаление Дома (роспуск или угасший очаг). */
    public static void destroy(House h) {
        for (String m : h.members) {
            PlayerProfile o = Players.profile(m);
            if (o != null) {
                o.houseId = null;
                o.rank = Rank.FREEMAN;
                o.liege = null;
            }
        }
        for (House other : Prevail.data().houses.values()) {
            if (h.id.equals(other.suzerain)) other.suzerain = null;
            if (h.id.equals(other.pendingFealtyTo)) other.pendingFealtyTo = null;
            other.allies.remove(h.id);
        }
        Prevail.data().kingdom.supporters.remove(h.lord);
        Prevail.data().wars.values().removeIf(w -> w.involves(h.id));
        Prevail.data().occupiedChunks.values().removeIf(h.id::equals);
        Prevail.data().suspicion.remove(h.id);
        Prevail.data().houses.remove(h.id);
        Prevail.markDirty();
    }

    public static String setSeat(ServerPlayer sp) {
        House h = requireLord(Players.profile(sp));
        h.seat = Pos.of(sp);
        return "Родовое гнездо: " + h.seat.pretty() + ". Его захват в осаде — поражение в войне.";
    }

    public static String setPrison(ServerPlayer sp) {
        House h = requireLord(Players.profile(sp));
        h.prison = Pos.of(sp);
        return "Темница Дома: " + h.prison.pretty();
    }

    // ---------- клятвы между Домами ----------

    public static String offerFealty(ServerPlayer sp, String targetHouse) {
        House h = requireLord(Players.profile(sp));
        House t = Players.houseByName(targetHouse);
        if (t.id.equals(h.id)) throw new PrevailException("Нельзя присягнуть самому себе.");
        if (h.suzerain != null) throw new PrevailException("Вы уже связаны клятвой.");
        if (TerritoryService.top(t).id.equals(h.id)) throw new PrevailException("Этот Дом сам ваш вассал.");
        h.pendingFealtyTo = t.id;
        Players.button(t.lord, "§eДом " + h.name + " желает принести вам вассальную клятву.", "Принять", "/house fealty accept " + h.id);
        return "Предложение клятвы отправлено Дому " + t.name + ".";
    }

    public static String acceptFealty(ServerPlayer sp, String vassalHouse) {
        House h = requireLord(Players.profile(sp));
        House v = Players.houseByName(vassalHouse);
        if (!h.id.equals(v.pendingFealtyTo)) throw new PrevailException("Дом " + v.name + " не предлагал вам клятву.");
        PowerCoins.spend(sp, PrevailConfig.PC_FEALTY.get(), "Принятие вассального Дома");
        v.pendingFealtyTo = null;
        v.suzerain = h.id;
        Players.broadcast("§6🛡 Дом " + v.name + " принёс вассальную клятву Дому " + h.name + ".");
        return null;
    }

    public static String renounce(ServerPlayer sp) {
        House h = requireLord(Players.profile(sp));
        if (h.suzerain == null) throw new PrevailException("Вы никому не присягали.");
        House s = Prevail.data().houses.get(h.suzerain);
        if (s != null && WarService.anyWar(s.id)) throw new PrevailException("Нельзя предать сюзерена, пока он воюет.");
        h.suzerain = null;
        Players.broadcast("§c⚡ Дом " + h.name + " отрёкся от клятвы Дому " + (s == null ? "?" : s.name) + "!");
        return null;
    }

    public static String releaseVassal(ServerPlayer sp, String vassalHouse) {
        House h = requireLord(Players.profile(sp));
        House v = Players.houseByName(vassalHouse);
        if (!h.id.equals(v.suzerain)) throw new PrevailException("Это не ваш вассал.");
        v.suzerain = null;
        Players.message(v.lord, "§eДом " + h.name + " освободил вас от клятвы.");
        return "Дом " + v.name + " освобождён.";
    }

    public static String ally(ServerPlayer sp, String other, boolean add) {
        House h = requireLord(Players.profile(sp));
        House o = Players.houseByName(other);
        if (o.id.equals(h.id)) throw new PrevailException("Это ваш же Дом.");
        if (add) {
            h.allies.add(o.id);
            boolean mutual = o.allies.contains(h.id);
            if (mutual) Players.message(o.lord, "§aДом " + h.name + " заключил с вами союз.");
            else Players.button(o.lord, "§eДом " + h.name + " предлагает союз.", "Принять", "/house ally " + h.id);
            return mutual ? "Союз с Домом " + o.name + " заключён." : "Предложение союза отправлено.";
        }
        h.allies.remove(o.id);
        o.allies.remove(h.id);
        Players.message(o.lord, "§cДом " + h.name + " разорвал союз.");
        return "Союз разорван.";
    }

    // ---------- информация ----------

    public static String info(House h) {
        StringBuilder sb = new StringBuilder();
        sb.append("§6═══ Дом ").append(h.name).append(" ═══\n");
        sb.append("§eЛорд: §f").append(Players.name(h.lord)).append('\n');
        if (h.suzerain != null) {
            House s = Prevail.data().houses.get(h.suzerain);
            sb.append("§eСюзерен: §f").append(s == null ? "?" : s.name).append('\n');
        }
        List<String> vassals = new ArrayList<>();
        for (House o : Prevail.data().houses.values()) if (h.id.equals(o.suzerain)) vassals.add(o.name);
        if (!vassals.isEmpty()) sb.append("§eВассалы (Великий Дом): §f").append(String.join(", ", vassals)).append('\n');
        List<String> knights = new ArrayList<>();
        List<String> serfs = new ArrayList<>();
        for (String m : h.members) {
            PlayerProfile o = Players.profile(m);
            if (o == null) continue;
            if (o.rank == Rank.KNIGHT) knights.add(o.name);
            else if (o.rank == Rank.SERF) serfs.add(o.name + (o.liege != null && !o.liege.equals(h.lord) ? " (→" + Players.name(o.liege) + ")" : ""));
        }
        sb.append("§eРыцари (").append(knights.size()).append("/").append(knightSlots(h)).append("): §f").append(knights.isEmpty() ? "—" : String.join(", ", knights)).append('\n');
        sb.append("§eКрепостные: §f").append(serfs.isEmpty() ? "—" : String.join(", ", serfs)).append('\n');
        sb.append("§eДомены: §f").append(TerritoryService.domainCount(h)).append(", земли: ").append(TerritoryService.chunkCount(h)).append(" чанков\n");
        sb.append("§eОчаг: §f").append(h.heartPlaced ? "горит" : "§cхолоден").append(h.hungerStage() > 0 ? " §c(голод " + h.hungerStage() + ")" : "").append('\n');
        sb.append("§eКазна: §f").append(Money.fmt(h.treasury));
        if (h.debt > 0) sb.append(" §c(недоимка ").append(Money.fmt(h.debt)).append(")");
        return sb.toString();
    }

    public static String list() {
        if (Prevail.data().houses.isEmpty()) return "Домов пока нет. Основать: /house create <название> у Фонда.";
        StringBuilder sb = new StringBuilder("§6Дома королевства (" + Prevail.data().houses.size() + "/" + FundService.houseSlots() + "):");
        for (House h : Prevail.data().houses.values()) {
            sb.append("\n§f• ").append(h.name).append(" §7— лорд ").append(Players.name(h.lord)).append(", ").append(h.members.size()).append(" чел.");
            if (h.suzerain != null) {
                House s = Prevail.data().houses.get(h.suzerain);
                sb.append(", вассал ").append(s == null ? "?" : s.name);
            }
        }
        return sb.toString();
    }
}

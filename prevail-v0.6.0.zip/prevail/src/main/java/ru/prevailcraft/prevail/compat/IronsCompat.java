package ru.prevailcraft.prevail.compat;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.fml.ModList;
import ru.prevailcraft.prevail.PrevailMod;

/**
 * Мягкая интеграция с Iron's Spells 'n Spellbooks.
 * Мод НЕ компилируется против Iron's: всё делается по ID из реестров,
 * поэтому Prevail работает и без него, а с ним — включает связку автоматически.
 *
 * Связка:
 *  - блоки Iron's (стол начертания, кузня свитков и т.п.) может использовать только Чародей;
 *  - выпитый Исток усиливает силу заклинаний и ману на 10 минут.
 *
 * На момент написания Iron's вышел только для 1.21.1; ID атрибутов взяты из этой версии.
 */
public final class IronsCompat {
    public static final String MODID = "irons_spellbooks";
    private static Boolean loaded;

    private IronsCompat() {}

    public static boolean loaded() {
        if (loaded == null) {
            loaded = ModList.get().isLoaded(MODID);
            if (loaded) PrevailMod.LOG.info("Prevail: найден Iron's Spells 'n Spellbooks — связка включена");
        }
        return loaded;
    }

    public static void essenceBuff(ServerPlayer p, boolean on) {
        if (!loaded()) return;
        VersionCompat.attribute(MODID + ":spell_power").ifPresent(a -> {
            if (on) VersionCompat.addTempModifier(p, a, "essence_spell_power", 0.20);
            else VersionCompat.removeModifier(p, a, "essence_spell_power");
        });
        VersionCompat.attribute(MODID + ":max_mana").ifPresent(a -> {
            if (on) VersionCompat.addTempModifier(p, a, "essence_mana", 0.25);
            else VersionCompat.removeModifier(p, a, "essence_mana");
        });
    }
}

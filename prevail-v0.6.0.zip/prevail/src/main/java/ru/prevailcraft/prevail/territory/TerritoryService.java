package ru.prevailcraft.prevail.territory;

import net.minecraft.world.level.Level;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.ChunkKey;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Prevail;

import java.util.Map;
import java.util.UUID;

/** Кому принадлежит земля. Учитывает оккупацию после осад. */
public final class TerritoryService {
    private TerritoryService() {}

    /** Фактический хозяин чанка (оккупант, если чанк захвачен). */
    public static House houseAt(Level level, int cx, int cz) {
        String occ = Prevail.data().occupiedChunks.get(ChunkKey.of(VersionCompat.dimId(level), cx, cz));
        if (occ != null) {
            House h = Prevail.data().houses.get(occ);
            if (h != null) return h;
        }
        return baseHouseAt(level, cx, cz);
    }

    /** Законный хозяин чанка по клейму OPAC, без учёта оккупации. */
    public static House baseHouseAt(Level level, int cx, int cz) {
        UUID owner = OpacBridge.claimOwner(Prevail.server(), level, cx, cz);
        if (owner == null) return null;
        PlayerProfile p = Prevail.data().players.get(owner.toString());
        if (p == null || p.houseId == null) return null;
        return Prevail.data().houses.get(p.houseId);
    }

    /** Число чанков Дома: клеймы всех членов + оккупированные. */
    public static int chunkCount(House h) {
        int n = 0;
        for (String m : h.members) n += OpacBridge.claimCount(Prevail.server(), UUID.fromString(m));
        for (Map.Entry<String, String> e : Prevail.data().occupiedChunks.entrySet()) {
            if (h.id.equals(e.getValue())) n++;
        }
        return n;
    }

    /** Домены: домен лорда + домен каждого рыцаря, у которого есть хоть один клейм. */
    public static int domainCount(House h) {
        int n = 1;
        for (String m : h.members) {
            PlayerProfile p = Prevail.data().players.get(m);
            if (p != null && p.rank == ru.prevailcraft.prevail.core.Rank.KNIGHT
                    && OpacBridge.claimCount(Prevail.server(), UUID.fromString(m)) > 0) n++;
        }
        return n;
    }

    /** Верховный сюзерен в цепочке клятв. */
    public static House top(House h) {
        House cur = h;
        for (int guard = 0; guard < 32 && cur.suzerain != null; guard++) {
            House next = Prevail.data().houses.get(cur.suzerain);
            if (next == null) break;
            cur = next;
        }
        return cur;
    }

    /** Свои, союзники и Дома одной вассальной пирамиды не вызывают подозрений. */
    public static boolean friendly(String houseA, String houseB) {
        if (houseA == null || houseB == null) return false;
        if (houseA.equals(houseB)) return true;
        House a = Prevail.data().houses.get(houseA);
        House b = Prevail.data().houses.get(houseB);
        if (a == null || b == null) return false;
        if (a.allies.contains(b.id) && b.allies.contains(a.id)) return true; // союз только взаимный
        return top(a).id.equals(top(b).id);
    }
}

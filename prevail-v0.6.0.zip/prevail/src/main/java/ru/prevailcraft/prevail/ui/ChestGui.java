package ru.prevailcraft.prevail.ui;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.ItemStack;

import java.util.function.Consumer;

/**
 * GUI в виде окна сундука, полностью серверный: клиенту не нужен никакой код,
 * он рисует обычное окно сундука, а клики перехватывает GuiMenu.
 * Позже любой экран можно заменить на красивый клиентский, не трогая логику.
 *
 * Использование:
 *   new ChestGui(3, "Рынок", gui -> { gui.set(0, icon, (p, right, shift) -> ...); }).open(player);
 * builder вызывается заново после каждого клика — экран всегда актуален.
 */
public final class ChestGui {
    @FunctionalInterface
    public interface Click {
        void on(ServerPlayer p, boolean right, boolean shift);
    }

    /** Shift-клик по предмету в своём инвентаре: вернуть true, если предмет принят (стек уже уменьшен). */
    @FunctionalInterface
    public interface Deposit {
        boolean on(ServerPlayer p, ItemStack stack);
    }

    final int rows;
    final Component title;
    final ItemStack[] icons;
    final Click[] clicks;
    private final Consumer<ChestGui> builder;
    Deposit deposit;

    public ChestGui(int rows, String title, Consumer<ChestGui> builder) {
        this.rows = Math.max(1, Math.min(6, rows));
        this.title = Component.literal(title);
        this.icons = new ItemStack[this.rows * 9];
        this.clicks = new Click[this.rows * 9];
        this.builder = builder;
        rebuild();
    }

    public ChestGui set(int slot, ItemStack icon, Click click) {
        if (slot < 0 || slot >= icons.length) return this;
        icons[slot] = icon;
        clicks[slot] = click;
        return this;
    }

    public ChestGui onDeposit(Deposit d) {
        this.deposit = d;
        return this;
    }

    public int size() {
        return icons.length;
    }

    void rebuild() {
        for (int i = 0; i < icons.length; i++) {
            icons[i] = ItemStack.EMPTY;
            clicks[i] = null;
        }
        builder.accept(this);
    }

    ItemStack icon(int i) {
        return icons[i] == null ? ItemStack.EMPTY : icons[i];
    }

    void click(ServerPlayer p, int slot, boolean right, boolean shift) {
        Click c = clicks[slot];
        if (c != null) c.on(p, right, shift);
    }

    public void open(ServerPlayer p) {
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new GuiMenu(id, inv, this), title));
    }
}

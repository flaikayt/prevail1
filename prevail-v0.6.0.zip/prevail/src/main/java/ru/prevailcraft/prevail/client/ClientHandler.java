package ru.prevailcraft.prevail.client;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import ru.prevailcraft.prevail.client.screen.HouseFoundScreen;
import ru.prevailcraft.prevail.client.screen.FundScreen;
import ru.prevailcraft.prevail.client.screen.LockpickScreen;
import ru.prevailcraft.prevail.client.screen.MarketScreen;
import ru.prevailcraft.prevail.client.screen.SafeScreen;
import ru.prevailcraft.prevail.client.screen.SkillScreen;
import ru.prevailcraft.prevail.network.OpenScreenPayload;

import java.util.HashMap;
import java.util.Map;

/** Приём пакета «открыть экран» от сервера. */
public final class ClientHandler {
    private ClientHandler() {}

    /** "a=1;b=2" → {a:1, b:2}. */
    public static Map<String, String> parse(String data) {
        Map<String, String> m = new HashMap<>();
        for (String part : data.split(";")) {
            int i = part.indexOf('=');
            if (i > 0) m.put(part.substring(0, i), part.substring(i + 1));
        }
        return m;
    }

    public static void onOpenScreen(OpenScreenPayload msg, IPayloadContext ctx) {
        Map<String, String> d = parse(msg.data());
        switch (msg.screen()) {
            case "house_found" -> Ui.open(new HouseFoundScreen(d));
            case "professions" -> {
                if (Ui.current() instanceof SkillScreen ss) ss.update(d);
                else Ui.open(new SkillScreen(d));
            }
            case "market" -> Ui.open(new MarketScreen(d));
            case "fund_info" -> FundScreen.INFO = d;
            case "safe_info" -> {
                SafeScreen.INFO = d;
                if (Ui.current() instanceof SafeScreen s) s.refresh();
            }
            case "lockpick" -> Ui.open(new LockpickScreen(d));
            case "market_update" -> {
                if (Ui.current() instanceof MarketScreen ms) ms.update(d);
            }
            default -> { }
        }
    }
}

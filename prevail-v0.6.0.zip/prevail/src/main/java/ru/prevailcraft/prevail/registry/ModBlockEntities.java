package ru.prevailcraft.prevail.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.prevailcraft.prevail.PrevailMod;
import ru.prevailcraft.prevail.lock.SafeBlockEntity;

import java.util.Set;

/** BlockEntity мода: сейф хранит предметы, код ключа, владельца и флаг «нерушимый». */
public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> TYPES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, PrevailMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafeBlockEntity>> SAFE =
            TYPES.register("safe", () -> new BlockEntityType<>(SafeBlockEntity::new, Set.of(ModBlocks.SAFE.get())));

    private ModBlockEntities() {}

    public static void register(IEventBus modBus) {
        TYPES.register(modBus);
    }
}

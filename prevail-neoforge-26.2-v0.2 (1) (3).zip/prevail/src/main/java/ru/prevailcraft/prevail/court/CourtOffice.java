package ru.prevailcraft.prevail.court;

import net.minecraft.world.item.Item;
import ru.prevailcraft.prevail.core.Rank;
import ru.prevailcraft.prevail.registry.ModItems;

import java.util.function.Supplier;

/**
 * Пять должностей при дворе. Каждую король отмечает регалией:
 * полномочия действуют, только пока регалия у владельца в инвентаре.
 */
public enum CourtOffice {
    HAND("Десница", "Печать десницы", Rank.LORD, "почти все королевские права", () -> ModItems.REGALIA_HAND.get()),
    MARSHAL("Маршал", "Жезл маршала", Rank.KNIGHT, "стража, тюрьмы, розыск, помилование, охота", () -> ModItems.REGALIA_MARSHAL.get()),
    TREASURER("Казначей", "Ключ казначея", null, "казна, налоги, чеканка", () -> ModItems.REGALIA_TREASURER.get()),
    CHANCELLOR("Канцлер", "Перо канцлера", null, "аренда столицы, лицензии, платежи", () -> ModItems.REGALIA_CHANCELLOR.get()),
    ARCHITECT("Архитектор", "Циркуль архитектора", null, "облик столицы, бригады строителей", () -> ModItems.REGALIA_ARCHITECT.get());

    public final String title;
    public final String regaliaName;
    /** Минимальный титул: null — не нужен; KNIGHT — рыцарь или лорд; LORD — только лорд. */
    public final Rank minRank;
    public final String duty;
    private final Supplier<Item> regalia;

    CourtOffice(String title, String regaliaName, Rank minRank, String duty, Supplier<Item> regalia) {
        this.title = title;
        this.regaliaName = regaliaName;
        this.minRank = minRank;
        this.duty = duty;
        this.regalia = regalia;
    }

    public Item regalia() {
        return regalia.get();
    }

    public boolean rankOk(Rank r) {
        if (minRank == null) return true;
        if (minRank == Rank.LORD) return r == Rank.LORD;
        return r == Rank.LORD || r == Rank.KNIGHT;
    }

    public static CourtOffice byRegalia(Item item) {
        for (CourtOffice o : values()) if (o.regalia() == item) return o;
        return null;
    }
}

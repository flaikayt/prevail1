package ru.prevailcraft.prevail.menu;

import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import ru.prevailcraft.prevail.lock.LockService;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.registry.ModMenus;

/** Связка ключей: 8 ключей по кругу. Хранится в самом предмете (компонент container). */
public class KeyringMenu extends AbstractContainerMenu {
    public static final int SIZE = 8;
    public static final int CX = 80, CY = 44, R = 30;

    private final SimpleContainer box = new SimpleContainer(SIZE);
    private final Player player;

    public KeyringMenu(int id, Inventory inv) {
        super(ModMenus.KEYRING.get(), id);
        this.player = inv.player;
        ItemStack ring = player.getMainHandItem();
        if (ring.is(ModItems.KEYRING.get())) {
            NonNullList<ItemStack> list = LockService.ringContents(ring);
            for (int i = 0; i < SIZE; i++) box.setItem(i, list.get(i));
        }
        for (int i = 0; i < SIZE; i++) {
            double a = Math.toRadians(-90 + i * 45);
            int x = CX + (int) Math.round(Math.cos(a) * R) - 8;
            int y = CY + (int) Math.round(Math.sin(a) * R) - 8;
            addSlot(new Slot(box, i, x, y) {
                @Override
                public boolean mayPlace(ItemStack s) {
                    return s.is(ModItems.KEY.get());
                }
            });
        }
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 92 + r * 18));
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, 8 + c * 18, 150));
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot.hasItem()) {
            ItemStack st = slot.getItem();
            result = st.copy();
            if (index < SIZE) {
                if (!moveItemStackTo(st, SIZE, SIZE + 36, true)) return ItemStack.EMPTY;
            } else if (!st.is(ModItems.KEY.get()) || !moveItemStackTo(st, 0, SIZE, false)) {
                return ItemStack.EMPTY;
            }
            if (st.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player p) {
        return p.getMainHandItem().is(ModItems.KEYRING.get());
    }

    @Override
    public void removed(Player p) {
        super.removed(p);
        ItemStack ring = p.getMainHandItem();
        java.util.List<ItemStack> list = new java.util.ArrayList<>();
        for (int i = 0; i < SIZE; i++) list.add(box.getItem(i).copy());
        if (ring.is(ModItems.KEYRING.get())) {
            ring.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(list));
        } else {
            for (ItemStack s : list) if (!s.isEmpty() && !p.getInventory().add(s)) p.drop(s, false);
        }
    }
}

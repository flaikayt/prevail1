package ru.prevailcraft.prevail.profession;

import net.minecraft.server.level.ServerPlayer;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.world.Epoch;

import java.util.Locale;

/**
 * Ранги: Ученик → Подмастерье → Мастер → Старший мастер → Гроссмейстер.
 * Без выбранной ветки выше Подмастерья не подняться.
 * Гроссмейстеров каждой профессии — ограниченное число (конфиг), и только с эпохи «Гильдии».
 */
public final class ProfessionService {
    public static final long[] XP = {0, 100, 400, 1200, 3000};
    public static final String[] RANKS = {"Ученик", "Подмастерье", "Мастер", "Старший мастер", "Гроссмейстер"};

    private ProfessionService() {}

    private static int rawRank(long xp) {
        int r = 1;
        for (int i = 0; i < XP.length; i++) if (xp >= XP[i]) r = i + 1;
        return r;
    }

    public static int rank(PlayerProfile p) {
        if (p.profession == Profession.NONE) return 0;
        int r = rawRank(p.professionXp);
        if (p.branch == null) r = Math.min(r, 2);
        if (r == 5 && !p.grandmaster) r = 4;
        return r;
    }

    public static int licenseRank(PlayerProfile p) {
        return p.license == null ? 0 : rawRank(p.licenseXp);
    }

    public static boolean is(PlayerProfile p, Profession prof) {
        return p.profession == prof || p.license == prof;
    }

    /** Ветка подходит: ветка не выбрана (новичок) или совпадает. */
    public static boolean branchOk(PlayerProfile p, Branch b) {
        return p.profession == b.profession && (p.branch == null || p.branch == b);
    }

    public static void addXp(PlayerProfile p, Profession prof, long xp) {
        if (xp <= 0) return;
        if (p.profession == prof) {
            int before = rank(p);
            p.professionXp += xp;
            tryGrandmaster(p);
            int after = rank(p);
            if (after > before) Players.message(p.uuid, "§a⬆ " + prof.title + ": " + RANKS[after - 1] + "!");
            if (after == 2 && p.branch == null && before < 2) {
                Players.message(p.uuid, "§eВыберите ветку ремесла: /prof branch <ветка> — без неё выше не подняться.");
            }
            Prevail.markDirty();
        }
        addLicenseXp(p, prof, xp);
    }

    public static void addLicenseXp(PlayerProfile p, Profession prof, long xp) {
        if (p.license != prof || xp <= 0) return;
        int before = licenseRank(p);
        p.licenseXp += xp;
        if (licenseRank(p) > before) Players.message(p.uuid, "§a⬆ " + prof.title + ": " + RANKS[licenseRank(p) - 1] + "!");
        Prevail.markDirty();
    }

    private static void tryGrandmaster(PlayerProfile p) {
        if (p.grandmaster || p.branch == null || rawRank(p.professionXp) < 5 || Epoch.current() < 4) return;
        int taken = 0;
        for (PlayerProfile o : Prevail.data().players.values()) if (o.grandmaster && o.profession == p.profession) taken++;
        if (taken >= PrevailConfig.GRANDMASTER_SLOTS.get()) {
            Players.message(p.uuid, "§7Все места гроссмейстеров ремесла «" + p.profession.title + "» заняты.");
            return;
        }
        p.grandmaster = true;
        Players.broadcast("§6✦ " + p.name + " стал гроссмейстером ремесла «" + p.profession.title + "»!");
    }

    public static Profession parse(String s) {
        for (Profession pr : Profession.values()) {
            if (pr == Profession.NONE) continue;
            if (pr.name().equalsIgnoreCase(s) || pr.title.toLowerCase(Locale.ROOT).equals(s.toLowerCase(Locale.ROOT))) return pr;
        }
        throw new PrevailException("Нет такой профессии. /prof list");
    }

    public static String choose(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        Profession pr = parse(name);
        if (pr.licensed) throw new PrevailException(pr.title + " выдаётся по лицензии канцлера.");
        if (pr == p.profession) throw new PrevailException("Это уже ваше ремесло.");
        long left = p.professionChangedAt + PrevailConfig.PROFESSION_COOLDOWN_HOURS.get() * 3_600_000L - System.currentTimeMillis();
        if (p.profession != Profession.NONE && left > 0) throw new PrevailException("Сменить ремесло можно через " + (left / 3_600_000L + 1) + " ч.");
        p.profession = pr;
        p.branch = null;
        p.professionXp = 0;
        p.grandmaster = false;
        p.professionChangedAt = System.currentTimeMillis();
        return "Ваше ремесло: " + pr.title + ". Ветку выберете на ранге «Подмастерье». Опыт прежнего ремесла утрачен.";
    }

    public static String chooseBranch(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        if (p.profession == Profession.NONE) throw new PrevailException("Сначала выберите ремесло.");
        if (p.branch != null) throw new PrevailException("Ветка уже выбрана: " + p.branch.title + ". Сменить можно только сменив ремесло.");
        if (rawRank(p.professionXp) < 2) throw new PrevailException("Ветку выбирают с ранга «Подмастерье».");
        for (Branch b : Branch.of(p.profession)) {
            if (b.name().equalsIgnoreCase(name) || b.title.equalsIgnoreCase(name)) {
                p.branch = b;
                return "Ваша ветка: " + b.title + " — " + b.perk + ".";
            }
        }
        StringBuilder sb = new StringBuilder("Ветки ремесла «" + p.profession.title + "»: ");
        for (Branch b : Branch.of(p.profession)) sb.append(b.name().toLowerCase(Locale.ROOT)).append(" (").append(b.title).append(") ");
        throw new PrevailException(sb.toString().trim());
    }

    public static String dropLicense(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        if (p.license == null) throw new PrevailException("У вас нет лицензии.");
        String t = p.license.title;
        p.license = null;
        p.licenseXp = 0;
        return "Вы отказались от лицензии «" + t + "».";
    }

    /** Данные для окна профессий (клавиша P) → client/screen/ProfessionScreen. */
    public static void sendScreen(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        long left = Math.max(0, p.professionChangedAt + PrevailConfig.PROFESSION_COOLDOWN_HOURS.get() * 3_600_000L - System.currentTimeMillis());
        if (p.profession == Profession.NONE) left = 0;
        String data = "prof=" + p.profession.name()
                + ";branch=" + (p.branch == null ? "" : p.branch.name())
                + ";xp=" + p.professionXp
                + ";rank=" + rank(p)
                + ";lic=" + (p.license == null ? "" : p.license.name())
                + ";lxp=" + p.licenseXp
                + ";lrank=" + licenseRank(p)
                + ";cd=" + (left == 0 ? 0 : left / 3_600_000L + 1)
                + ";epoch=" + Epoch.current();
        ru.prevailcraft.prevail.network.Network.openScreen(sp, "professions", data);
    }

    public static String info(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        StringBuilder sb = new StringBuilder();
        if (p.profession == Profession.NONE) sb.append("Ремесла нет. /prof choose <ремесло>");
        else {
            sb.append("§e").append(p.profession.title);
            if (p.branch != null) sb.append(" — ").append(p.branch.title);
            sb.append("§f: ").append(RANKS[rank(p) - 1]).append(" (опыт ").append(p.professionXp).append(")");
        }
        if (p.license != null) sb.append("\n§eЛицензия: ").append(p.license.title).append("§f — ").append(RANKS[licenseRank(p) - 1]);
        return sb.toString();
    }

    public static String list() {
        StringBuilder sb = new StringBuilder("§6Основные ремёсла (/prof choose):");
        for (Profession pr : Profession.values()) {
            if (pr == Profession.NONE || pr.licensed) continue;
            sb.append("\n§f").append(pr.name().toLowerCase(Locale.ROOT)).append(" §e").append(pr.title).append(" §7— ");
            for (Branch b : Branch.of(pr)) sb.append(b.title).append(" / ");
            sb.setLength(sb.length() - 3);
        }
        sb.append("\n§6По лицензии канцлера:");
        for (Profession pr : Profession.values()) if (pr.licensed) sb.append("\n§e").append(pr.title).append(" §7— ").append(pr.perk);
        return sb.toString();
    }
}

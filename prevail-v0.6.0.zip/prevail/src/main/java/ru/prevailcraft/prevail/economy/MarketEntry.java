package ru.prevailcraft.prevail.economy;

import java.util.Map;

/**
 * Товар королевского рынка. Склад рынка пополняется ТОЛЬКО через скупщика:
 * игроки сдают ресурсы → склад растёт → рынок их продаёт.
 */
public final class MarketEntry {
    /** Базовая цена скупки за 1 шт., в медяках. */
    public long basePrice;
    public long stock;
    /** «Нормальный» запас: при нём цена равна базовой. */
    public long target;

    public MarketEntry() {}

    public MarketEntry(long basePrice, long target) {
        this.basePrice = basePrice;
        this.target = target;
        this.stock = target / 4;
    }

    private double ratio() {
        double r = Math.sqrt((double) target / Math.max(stock, 1));
        return Math.max(0.3, Math.min(3.0, r));
    }

    /** Сколько платит скупщик за 1 шт. (избыток на складе — платит меньше). */
    public long buyerPrice(double bonus) {
        return Math.max(1, Math.round(basePrice * ratio() * bonus));
    }

    /** Цена на рынке за 1 шт. (наценка короны 50%). */
    public long marketPrice() {
        return Math.max(1, Math.round(basePrice * ratio() * 1.5));
    }

    public static void fillDefaults(Map<String, MarketEntry> m) {
        m.put("minecraft:wheat", new MarketEntry(2, 512));
        m.put("minecraft:bread", new MarketEntry(6, 256));
        m.put("minecraft:carrot", new MarketEntry(2, 512));
        m.put("minecraft:potato", new MarketEntry(2, 512));
        m.put("minecraft:coal", new MarketEntry(4, 512));
        m.put("minecraft:charcoal", new MarketEntry(4, 512));
        m.put("minecraft:oak_log", new MarketEntry(3, 512));
        m.put("minecraft:spruce_log", new MarketEntry(3, 512));
        m.put("minecraft:cobblestone", new MarketEntry(1, 2048));
        m.put("minecraft:iron_ingot", new MarketEntry(15, 256));
        m.put("minecraft:copper_ingot", new MarketEntry(5, 256));
        m.put("minecraft:leather", new MarketEntry(8, 128));
        m.put("minecraft:white_wool", new MarketEntry(5, 256));
        m.put("minecraft:cooked_beef", new MarketEntry(7, 256));
        m.put("minecraft:honey_bottle", new MarketEntry(10, 64));
        m.put("minecraft:torch", new MarketEntry(1, 512));
    }
}

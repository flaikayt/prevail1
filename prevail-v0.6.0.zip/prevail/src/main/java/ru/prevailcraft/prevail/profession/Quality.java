package ru.prevailcraft.prevail.profession;

import java.util.concurrent.ThreadLocalRandom;

/** Качество изделий: меняет прочность. Шедевр могут сделать только гроссмейстеры. */
public enum Quality {
    ROUGH("Грубое", "§7", 0.5),
    DECENT("Добротное", "§f", 1.0),
    FINE("Хорошее", "§a", 1.25),
    EXCELLENT("Отличное", "§9", 1.5),
    MASTERWORK("Шедевр", "§6", 2.0);

    public final String title;
    public final String color;
    public final double durability;

    Quality(String title, String color, double durability) {
        this.title = title;
        this.color = color;
        this.durability = durability;
    }

    /** Ранг 1..5 → качество с небольшим разбросом. */
    public static Quality roll(int rank) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int idx = Math.max(1, Math.min(3, rank - 1));
        if (r.nextDouble() < 0.15) idx = Math.max(1, idx - 1);
        else if (r.nextDouble() < 0.15) idx = Math.min(3, idx + 1);
        if (rank >= 5 && r.nextDouble() < 0.15) return MASTERWORK;
        return values()[idx];
    }

    public static Quality byIndex(int i) {
        return values()[Math.max(0, Math.min(values().length - 1, i))];
    }
}

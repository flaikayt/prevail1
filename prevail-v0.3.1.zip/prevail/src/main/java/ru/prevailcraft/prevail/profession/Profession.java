package ru.prevailcraft.prevail.profession;

/**
 * Ремёсла. Основное выбирает сам игрок (одно), лицензионное — выдаёт канцлер.
 * icon — id предмета-иконки для окна профессий (клавиша P).
 */
public enum Profession {
    NONE("Без ремесла", false, "—", "minecraft:barrier", new String[]{}, ""),

    MINER("Рудокоп", false, "руды и камень", "minecraft:iron_pickaxe",
            new String[]{"Добывает руды и камень.", "Без него руда крошится в гравий.", "Ветки: жильщик и камнелом."},
            "Гора не отдаёт сокровищ чужакам."),
    LUMBERJACK("Лесоруб", false, "древесина и уголь", "minecraft:iron_axe",
            new String[]{"Валит лес и жжёт уголь.", "Обеспечивает Дома топливом.", "Ветки: лесничий и смолокур."},
            "Где топор, там и тепло очага."),
    FARMER("Земледелец", false, "урожай, хлеб, мёд", "minecraft:wheat",
            new String[]{"Выращивает хлеб и овощи.", "Кормит Дома и столицу.", "Ветки: хлебороб и садовод-пасечник."},
            "Сытый вассал — верный вассал."),
    HERDER("Скотовод", false, "скот, шерсть, мясо, кони", "minecraft:lead",
            new String[]{"Разводит скот и коней.", "Даёт шерсть, кожу и мясо.", "Ветки: пастух и коневод."},
            "Табун стоит дороже замка."),
    SMITH("Кузнец", false, "оружие, броня, инструменты", "minecraft:anvil",
            new String[]{"Создаёт оружие, броню и инструменты.", "Без кузнеца вещи выходят грубыми.", "Ветки: оружейник и бронник."},
            "Сталь помнит руку мастера."),
    CARPENTER("Плотник", false, "лодки, корабли, осадные машины", "minecraft:oak_boat",
            new String[]{"Строит лодки и корабли.", "Готовит осадные машины.", "Ветки: корабел и осадный мастер."},
            "Стены падают от дерева, а не от железа."),
    WEAVER("Ткач", false, "ткани, одежда, знамёна", "minecraft:loom",
            new String[]{"Ткёт ткани и шьёт одежду.", "Делает знамёна Домов.", "Ветки: портной и знаменщик."},
            "Под знаменем идут в бой."),

    HEALER("Лекарь-алхимик", true, "варка зелий", "minecraft:brewing_stand",
            new String[]{"Варит зелья и снадобья.", "Только он может пользоваться варочной стойкой."},
            "Яд и лекарство — одно, всё решает мера."),
    MERCENARY("Наёмник", true, "бой и побеги", "minecraft:iron_sword",
            new String[]{"Служит тому, кто платит.", "Может вырваться из кандалов.", "Ловчее вскрывает замки темниц."},
            "Верность измеряется серебром."),
    HUNTSMAN("Егерь", true, "трофеи с чудовищ", "minecraft:bow",
            new String[]{"Охотится на чудовищ.", "Шанс двойного трофея растёт с рангом."},
            "Лес кормит того, кто его знает."),
    FISHER("Рыбак", true, "улов и находки", "minecraft:fishing_rod",
            new String[]{"Ловит рыбу и находит редкие вещи.", "Шанс двойного улова."},
            "Терпение — лучшая наживка."),
    MERCHANT("Торговец", true, "цены у скупщика", "minecraft:emerald",
            new String[]{"Знает цену всему.", "Скупщик платит ему больше."},
            "Золото любит счёт."),
    SORCERER("Чародей", true, "магия Iron's Spells", "minecraft:enchanted_book",
            new String[]{"Наделяет вещи магией.", "Только ему подчиняются книги и свитки заклинаний."},
            "Слово, порою, острее меча.");

    public final String title;
    public final boolean licensed;
    public final String perk;
    public final String icon;
    public final String[] description;
    public final String quote;

    Profession(String title, boolean licensed, String perk, String icon, String[] description, String quote) {
        this.title = title;
        this.licensed = licensed;
        this.perk = perk;
        this.icon = icon;
        this.description = description;
        this.quote = quote;
    }
}

package ru.prevailcraft.prevail.war;

import net.minecraft.server.level.ServerPlayer;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.ChunkKey;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.court.Legitimacy;
import ru.prevailcraft.prevail.economy.PowerCoins;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.territory.TerritoryService;
import ru.prevailcraft.prevail.vassalage.HouseService;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Войны и осады.
 * 1) Лорд объявляет войну (платит из казны), идёт подготовка.
 * 2) Война активна; захват возможен только в окне осад (по умолчанию 18–22 МСК).
 * 3) Атакующий стоит в чанке врага без защитников рядом → чанк оккупирован.
 *    Защитник так же освобождает свои чанки.
 * 4) Захват чанка с родовым гнездом = победа: побеждённый Дом присягает победителю
 *    и платит 30% казны. Если побеждён Дом короля — лорд-победитель коронуется.
 * 5) Капитуляция (/war surrender) или взаимный мир (/war peace, чанки возвращаются).
 */
public final class WarService {
    private WarService() {}

    public static boolean anyWar(String houseId) {
        for (War w : Prevail.data().wars.values()) if (w.involves(houseId)) return true;
        return false;
    }

    public static War between(String a, String b) {
        for (War w : Prevail.data().wars.values()) if (w.involves(a) && w.involves(b)) return w;
        return null;
    }

    public static boolean inActiveWar(String a, String b) {
        War w = between(a, b);
        return w != null && w.state == War.State.ACTIVE;
    }

    public static boolean siegeWindowNow() {
        int h = LocalTime.now(ZoneId.of(PrevailConfig.TIMEZONE.get())).getHour();
        int s = PrevailConfig.SIEGE_START_HOUR.get(), e = PrevailConfig.SIEGE_END_HOUR.get();
        return s <= e ? (h >= s && h < e) : (h >= s || h < e);
    }

    public static String declare(ServerPlayer sp, String targetHouse, String reason) {
        if (System.currentTimeMillis() < Prevail.data().kingdom.peaceEdictUntil) throw new PrevailException("Действует королевский указ о мире.");
        PlayerProfile p = Players.profile(sp);
        House a = HouseService.requireLord(p);
        House d = Players.houseByName(targetHouse);
        if (a.id.equals(d.id)) throw new PrevailException("Нельзя воевать с собой.");
        if (between(a.id, d.id) != null) throw new PrevailException("Вы уже воюете с этим Домом.");
        if (a.suzerain != null && a.suzerain.equals(d.id)) throw new PrevailException("Сначала отрекитесь от клятвы (/house fealty renounce).");
        if (d.id.equals(a.suzerain) || a.id.equals(d.suzerain)) throw new PrevailException("Нельзя воевать с вассалом или сюзереном.");
        long cost = PrevailConfig.WAR_DECLARE_COST.get();
        if (a.treasury < cost) throw new PrevailException("Объявление войны стоит " + Money.fmt(cost) + " из казны Дома.");
        PowerCoins.spend(sp, PrevailConfig.PC_WAR.get(), "Объявление войны");
        a.treasury -= cost;
        return startWar(a, d, reason);
    }

    /** Мятеж: при легитимности ниже 20% любой лорд может пойти войной на Дом короля. */
    public static String rebel(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        House a = HouseService.requireLord(p);
        PlayerProfile king = Players.profile(CourtService.k().king);
        if (king == null || king.houseId == null) throw new PrevailException("Трон пуст — восставать не против кого.");
        if (king.houseId.equals(a.id)) throw new PrevailException("Нельзя восстать против самого себя.");
        if (Legitimacy.value() >= Legitimacy.REBELLION) throw new PrevailException("Мятеж возможен при легитимности ниже " + Legitimacy.REBELLION + "% (сейчас " + (int) Legitimacy.value() + "%).");
        House d = Prevail.data().houses.get(king.houseId);
        if (between(a.id, d.id) != null) throw new PrevailException("Вы уже воюете с Домом короля.");
        PowerCoins.spend(sp, PrevailConfig.PC_WAR.get(), "Мятеж");
        a.suzerain = d.id.equals(a.suzerain) ? null : a.suzerain;
        Players.broadcast("§4🔥 МЯТЕЖ! Дом " + a.name + " поднял восстание против короля!");
        return startWar(a, d, "мятеж против короны");
    }

    private static String startWar(House a, House d, String reason) {
        a.allies.remove(d.id);
        d.allies.remove(a.id);

        War w = new War();
        w.id = a.id + "-vs-" + d.id + "-" + System.currentTimeMillis();
        w.attacker = a.id;
        w.defender = d.id;
        w.reason = reason;
        w.declaredAt = System.currentTimeMillis();
        w.activeAt = w.declaredAt + PrevailConfig.WAR_PREP_MINUTES.get() * 60_000L;
        Prevail.data().wars.put(w.id, w);
        Players.broadcast("§4⚔ Дом " + a.name + " объявил войну Дому " + d.name + " — «" + reason + "». Война начнётся через "
                + PrevailConfig.WAR_PREP_MINUTES.get() + " мин. Осады — с " + PrevailConfig.SIEGE_START_HOUR.get() + ":00 до "
                + PrevailConfig.SIEGE_END_HOUR.get() + ":00.");
        return null;
    }

    public static String surrender(ServerPlayer sp, String enemy) {
        House h = HouseService.requireLord(Players.profile(sp));
        House e = Players.houseByName(enemy);
        War w = between(h.id, e.id);
        if (w == null) throw new PrevailException("Вы не воюете с этим Домом.");
        end(w, e.id, "капитуляция Дома " + h.name);
        return null;
    }

    public static String peace(ServerPlayer sp, String enemy) {
        House h = HouseService.requireLord(Players.profile(sp));
        House e = Players.houseByName(enemy);
        War w = between(h.id, e.id);
        if (w == null) throw new PrevailException("Вы не воюете с этим Домом.");
        if (h.id.equals(w.attacker)) w.attackerWantsPeace = true;
        else w.defenderWantsPeace = true;
        if (w.attackerWantsPeace && w.defenderWantsPeace) {
            for (String c : w.captured) Prevail.data().occupiedChunks.remove(c);
            Prevail.data().wars.remove(w.id);
            Players.broadcast("§a🕊 Дома " + h.name + " и " + e.name + " заключили мир. Захваченные земли возвращены.");
            return null;
        }
        Players.message(e.lord, "§eДом " + h.name + " предлагает мир: /war peace " + h.id);
        return "Предложение мира отправлено.";
    }

    /** Завершение войны победой winnerId. */
    public static void end(War w, String winnerId, String why) {
        Prevail.data().wars.remove(w.id);
        House win = Prevail.data().houses.get(winnerId);
        House lose = Prevail.data().houses.get(w.enemyOf(winnerId));
        if (win == null || lose == null) return;
        long tribute = lose.treasury * 30 / 100;
        lose.treasury -= tribute;
        win.treasury += tribute;
        lose.suzerain = win.id;
        lose.pendingFealtyTo = null;
        Players.broadcast("§6🏆 Война окончена (" + why + "). Дом " + win.name + " победил. Дом " + lose.name
                + " приносит вассальную клятву и платит дань " + Money.fmt(tribute) + ".");

        // Борьба за корону: победа над Домом короля даёт трон
        PlayerProfile king = Players.profile(CourtService.k().king);
        if (king != null && win.id.equals(king.houseId)) Legitimacy.event(5);
        if (king != null && lose.id.equals(king.houseId)) {
            CourtService.setKing(win.lord, "сверг короля силой оружия и");
        }
        Prevail.markDirty();
    }

    // ---------- осады ----------

    public static void tickSecond() {
        long now = System.currentTimeMillis();
        boolean window = siegeWindowNow();
        int need = PrevailConfig.CAPTURE_SECONDS.get();
        List<War> snapshot = new ArrayList<>(Prevail.data().wars.values());
        for (War w : snapshot) {
            if (w.state == War.State.DECLARED && now >= w.activeAt) {
                w.state = War.State.ACTIVE;
                Players.broadcast("§4⚔ Война Домов " + name(w.attacker) + " и " + name(w.defender) + " началась!");
            }
            if (w.state != War.State.ACTIVE || !window) continue;
            if (!Prevail.data().wars.containsKey(w.id)) continue;
            siegeTick(w, need);
        }
    }

    private static void siegeTick(War w, int need) {
        House att = Prevail.data().houses.get(w.attacker);
        House def = Prevail.data().houses.get(w.defender);
        if (att == null || def == null) {
            Prevail.data().wars.remove(w.id);
            return;
        }
        Map<String, Integer> attackers = presence(att);
        Map<String, Integer> defenders = presence(def);
        Set<String> touched = new HashSet<>();

        // Наступление: атакующие в чанках защитника без сопротивления
        for (Map.Entry<String, Integer> e : attackers.entrySet()) {
            String key = e.getKey();
            if (defenders.containsKey(key)) continue; // бой идёт — прогресс заморожен
            if (!ownerIs(key, def.id)) continue;
            touched.add(key);
            int prog = w.progress.merge(key, e.getValue(), Integer::sum);
            if (prog >= need) {
                w.progress.remove(key);
                Prevail.data().occupiedChunks.put(key, att.id);
                w.captured.add(key);
                Players.messageHouse(def, "§c🏳 Дом " + att.name + " захватил вашу землю " + pretty(key));
                Players.messageHouse(att, "§a🚩 Земля " + pretty(key) + " захвачена!");
                if (def.seat != null && key.equals(ChunkKey.of(def.seat.dim, (int) Math.floor(def.seat.x) >> 4, (int) Math.floor(def.seat.z) >> 4))) {
                    end(w, att.id, "пало родовое гнездо Дома " + def.name);
                    return;
                }
            }
        }
        // Контрнаступление: защитники освобождают оккупированные чанки
        for (Map.Entry<String, Integer> e : defenders.entrySet()) {
            String key = e.getKey();
            if (attackers.containsKey(key)) continue;
            if (!att.id.equals(Prevail.data().occupiedChunks.get(key)) || !w.captured.contains(key)) continue;
            touched.add(key);
            int prog = w.progress.merge(key, e.getValue(), Integer::sum);
            if (prog >= need) {
                w.progress.remove(key);
                Prevail.data().occupiedChunks.remove(key);
                w.captured.remove(key);
                Players.messageHouse(def, "§a🚩 Земля " + pretty(key) + " освобождена!");
                Players.messageHouse(att, "§c🏳 Дом " + def.name + " отбил землю " + pretty(key));
            }
        }
        w.progress.keySet().retainAll(touched); // ушёл из чанка — прогресс сгорает
        Prevail.markDirty();
    }

    /** ключ чанка → сколько онлайн-членов Дома в нём стоит. */
    private static Map<String, Integer> presence(House h) {
        Map<String, Integer> m = new HashMap<>();
        for (String id : h.members) {
            ServerPlayer p = Players.online(id);
            if (p == null || !p.isAlive()) continue;
            m.merge(ChunkKey.of(p), 1, Integer::sum);
        }
        return m;
    }

    private static boolean ownerIs(String key, String houseId) {
        String[] parts = key.split("\\|");
        var level = VersionCompat.level(Prevail.server(), parts[0]);
        if (level == null) return false;
        House h = TerritoryService.houseAt(level, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
        return h != null && h.id.equals(houseId);
    }

    private static String pretty(String key) {
        String[] p = key.split("\\|");
        return "[чанк " + p[1] + ", " + p[2] + "]";
    }

    private static String name(String houseId) {
        House h = Prevail.data().houses.get(houseId);
        return h == null ? "?" : h.name;
    }

    public static String list() {
        if (Prevail.data().wars.isEmpty()) return "В королевстве мир.";
        StringBuilder sb = new StringBuilder("§4═══ Войны ═══");
        long now = System.currentTimeMillis();
        for (War w : Prevail.data().wars.values()) {
            sb.append("\n§f").append(name(w.attacker)).append(" ⚔ ").append(name(w.defender)).append(" §7«").append(w.reason).append("» — ");
            if (w.state == War.State.DECLARED) sb.append("начнётся через ").append((w.activeAt - now) / 60_000).append(" мин.");
            else sb.append("идёт, захвачено чанков: ").append(w.captured.size());
        }
        sb.append("\n§7Окно осад сейчас: ").append(siegeWindowNow() ? "§aоткрыто" : "§cзакрыто");
        return sb.toString();
    }
}

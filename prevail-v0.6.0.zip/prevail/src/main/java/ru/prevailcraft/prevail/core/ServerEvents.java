package ru.prevailcraft.prevail.core;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import ru.prevailcraft.prevail.court.RegaliaService;
import ru.prevailcraft.prevail.economy.EconomyService;
import ru.prevailcraft.prevail.house.HearthService;
import ru.prevailcraft.prevail.law.PrisonService;
import ru.prevailcraft.prevail.law.WantedService;
import ru.prevailcraft.prevail.territory.SuspicionService;
import ru.prevailcraft.prevail.war.WarService;
import ru.prevailcraft.prevail.world.FundService;

/** Жизненный цикл сервера и общий «пульс». */
public final class ServerEvents {
    private long ticks;

    @SubscribeEvent
    public void onStarted(ServerStartedEvent e) {
        Prevail.start(e.getServer());
    }

    @SubscribeEvent
    public void onStopping(ServerStoppingEvent e) {
        Prevail.stop();
    }

    @SubscribeEvent
    public void onTick(ServerTickEvent.Post e) {
        if (!Prevail.running()) return;
        ticks++;
        if (ticks % 20 == 0) {
            PrisonService.tickSecond();
            WarService.tickSecond();
            SuspicionService.tickSecond();
            EconomyService.tickSecond();
            FundService.tickSecond();
            TitleEvents.herald();
        }
        if (ticks % 100 == 0) RegaliaService.scan();
        if (ticks % (20 * 30) == 0) {
            HearthService.tick();
            ru.prevailcraft.prevail.profession.AbilityService.tick();
            ru.prevailcraft.prevail.profession.ProfessionEvents.tickHaste();
            TitleEvents.refreshNames();
            long now = System.currentTimeMillis();
            for (ServerPlayer p : e.getServer().getPlayerList().getPlayers()) Players.profile(p).lastSeen = now;
        }
        if (ticks % (20 * 60 * 5) == 0) Prevail.store().saveIfDirty();
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        Players.profile(p).lastSeen = System.currentTimeMillis();
        Prevail.markDirty();
        PrisonService.onLogin(p);
        WantedService.onLogin(p);
        RegaliaService.onLogin(p);
    }
}

package ru.prevailcraft.prevail.economy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.Kingdom;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.court.Legitimacy;
import ru.prevailcraft.prevail.profession.Profession;
import ru.prevailcraft.prevail.profession.ProfessionService;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.TerritoryService;
import ru.prevailcraft.prevail.ui.ChestGui;
import ru.prevailcraft.prevail.ui.Icons;
import ru.prevailcraft.prevail.vassalage.HouseService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Деньги королевства: казна Домов, налог, чеканка (через скупщика), рынок, кошелёк.
 * Откуда берутся деньги: (1) скупщик чеканит медь, пока чеканка открыта;
 * (2) продажа на рынок; (3) заказы между игроками.
 */
public final class EconomyService {
    private EconomyService() {}

    // ---------- казна Дома ----------

    public static String deposit(ServerPlayer sp, long amount) {
        if (amount <= 0) throw new PrevailException("Сумма должна быть больше нуля.");
        House h = Players.requireHouse(Players.profile(sp));
        if (!Money.take(sp, amount)) throw new PrevailException("У вас нет столько денег.");
        h.treasury += amount;
        payDebt(h);
        return "В казну Дома внесено " + Money.fmt(amount) + ". Казна: " + Money.fmt(h.treasury);
    }

    public static String withdraw(ServerPlayer sp, long amount) {
        if (amount <= 0) throw new PrevailException("Сумма должна быть больше нуля.");
        House h = HouseService.requireLord(Players.profile(sp));
        if (h.treasury < amount) throw new PrevailException("В казне только " + Money.fmt(h.treasury) + ".");
        h.treasury -= amount;
        Money.give(sp, amount);
        return "Из казны выдано " + Money.fmt(amount) + ".";
    }

    private static void payDebt(House h) {
        if (h.debt <= 0 || h.treasury <= 0) return;
        long pay = Math.min(h.debt, h.treasury);
        h.treasury -= pay;
        h.debt -= pay;
        Prevail.data().kingdom.treasury += pay;
    }

    // ---------- налоги и чеканка ----------

    public static long taxPerChunk() {
        Kingdom k = Prevail.data().kingdom;
        return k.taxPerChunk >= 0 ? k.taxPerChunk : PrevailConfig.TAX_PER_CHUNK.get();
    }

    public static void collectTaxes() {
        Kingdom k = Prevail.data().kingdom;
        if (k.king == null) return; // нет короля — нет налога
        long rate = taxPerChunk();
        PlayerProfile king = Players.profile(k.king);
        for (House h : Prevail.data().houses.values()) {
            if (king != null && h.id.equals(king.houseId)) continue;
            long due = TerritoryService.chunkCount(h) * rate;
            if (due <= 0) continue;
            long paid = Math.min(due, h.treasury);
            h.treasury -= paid;
            k.treasury += paid;
            if (paid < due) {
                h.debt += due - paid;
                Players.message(h.lord, "§c💰 Казна не покрыла налог. Недоимка: " + Money.fmt(h.debt));
            }
        }
        Prevail.markDirty();
    }

    public static String setMinting(ServerPlayer sp, boolean open) {
        PlayerProfile p = Players.profile(sp);
        if (!CourtService.has(p.uuid, CourtOffice.TREASURER)) throw new PrevailException("Чеканкой управляют король, десница и казначей.");
        Legitimacy.require(Legitimacy.TAXES, "Управление чеканкой");
        Prevail.data().kingdom.mintingOpen = open;
        Players.broadcast(open ? "§e📜 Указ: скупщик снова чеканит медь." : "§e📜 Указ: чеканка остановлена — скупщик платит из королевской казны.");
        return null;
    }

    public static void tickSecond() {
        long now = System.currentTimeMillis();
        var d = Prevail.data();
        long interval = PrevailConfig.TAX_INTERVAL_MINUTES.get() * 60_000L;
        if (d.lastTaxMillis == 0) d.lastTaxMillis = now;
        if (now - d.lastTaxMillis >= interval) {
            d.lastTaxMillis = now;
            collectTaxes();
        }
        if (now - d.lastMarketDriftMillis >= 3_600_000L) {
            d.lastMarketDriftMillis = now;
            for (MarketEntry e : d.market.values()) e.stock = Math.max(0, e.stock - Math.max(1, e.stock / 50)); // порча/расход склада
        }
    }

    // ---------- скупщик ----------

    private static double merchantBonus(PlayerProfile p) {
        return p.license == Profession.MERCHANT ? 1.1 + 0.03 * ProfessionService.licenseRank(p) : 1.0;
    }

    public static void openBuyer(ServerPlayer sp) {
        new ChestGui(6, "Скупщик — Shift+клик по товару", gui -> {
            Kingdom k = Prevail.data().kingdom;
            PlayerProfile p = Players.profile(sp);
            gui.set(4, Icons.of(Items.GOLD_INGOT, "§6Скупщик короны",
                    "§7Сдавайте ресурсы — получайте монеты.",
                    "§7Shift+клик по предмету в своём инвентаре.",
                    k.mintingOpen ? "§aЧеканка открыта: монеты новые" : "§cЧеканка закрыта: платит казна (" + Money.fmt(k.treasury) + ")"), null);
            int slot = 9;
            for (Map.Entry<String, MarketEntry> en : Prevail.data().market.entrySet()) {
                if (slot >= 54) break;
                Item item = VersionCompat.item(en.getKey());
                MarketEntry e = en.getValue();
                gui.set(slot++, Icons.of(item, "§f" + Icons.name(item),
                        "§7Платим: §e" + Money.fmt(e.buyerPrice(merchantBonus(p))) + " §7за шт.",
                        "§7На складе: " + e.stock + " / норма " + e.target), null);
            }
            gui.onDeposit((pl, stack) -> sellStack(pl, stack));
        }).open(sp);
    }

    private static boolean sellStack(ServerPlayer sp, ItemStack stack) {
        String id = VersionCompat.itemId(stack.getItem());
        MarketEntry e = Prevail.data().market.get(id);
        if (e == null) throw new PrevailException("Скупщик не берёт этот товар.");
        PlayerProfile p = Players.profile(sp);
        int n = stack.getCount();
        long total = 0;
        for (int i = 0; i < n; i++) {
            total += e.buyerPrice(merchantBonus(p));
            e.stock++;
        }
        Kingdom k = Prevail.data().kingdom;
        if (!k.mintingOpen) {
            if (k.treasury < total) {
                e.stock -= n;
                throw new PrevailException("Чеканка закрыта, а в казне всего " + Money.fmt(k.treasury) + ".");
            }
            k.treasury -= total;
        }
        stack.shrink(n);
        Money.give(sp, total);
        ProfessionService.addLicenseXp(p, Profession.MERCHANT, n);
        sp.sendSystemMessage(net.minecraft.network.chat.Component.literal("§aПродано " + n + " шт. за " + Money.fmt(total)));
        return true;
    }

    // ---------- рынок ----------

    public static void openMarket(ServerPlayer sp) {
        new ChestGui(6, "Королевский рынок", gui -> {
            gui.set(4, Icons.of(Items.EMERALD, "§6Королевский рынок",
                    "§7ЛКМ — купить 1, ПКМ — 16, Shift — 64.",
                    "§7Товар появляется, когда его сдают скупщику.",
                    "§7У вас: §e" + Money.fmt(Money.count(sp))), null);
            int slot = 9;
            for (Map.Entry<String, MarketEntry> en : Prevail.data().market.entrySet()) {
                if (slot >= 54) break;
                MarketEntry e = en.getValue();
                Item item = VersionCompat.item(en.getKey());
                String id = en.getKey();
                gui.set(slot++, Icons.of(item, (int) Math.min(64, Math.max(1, e.stock)), "§f" + Icons.name(item),
                        "§7Цена: §e" + Money.fmt(e.marketPrice()) + " §7за шт.",
                        e.stock > 0 ? "§7В наличии: " + e.stock : "§cНет в наличии"),
                        (pl, right, shift) -> buy(pl, id, shift ? 64 : right ? 16 : 1));
            }
        }).open(sp);
    }

    public static void buy(ServerPlayer sp, String id, int count) {
        MarketEntry e = Prevail.data().market.get(id);
        if (e == null) throw new PrevailException("Такого товара нет.");
        if (e.stock < count) throw new PrevailException("На складе только " + e.stock + " шт.");
        long saved = e.stock;
        long total = 0;
        for (int i = 0; i < count; i++) {
            total += e.marketPrice();
            e.stock--;
        }
        e.stock = saved;
        if (!Money.take(sp, total)) throw new PrevailException("Нужно " + Money.fmt(total) + ".");
        e.stock -= count;
        Prevail.data().kingdom.treasury += total;
        Money.giveStacks(sp, VersionCompat.item(id), count);
    }

    // ---------- кошелёк ----------

    /** ПКМ кошельком: собрать все монеты в кошелёк. */
    public static void walletAbsorb(ServerPlayer sp, ItemStack wallet) {
        long loose = Money.loose(sp);
        if (loose == 0) {
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal("§7В кошельке: " + Money.fmt(Money.walletBalance(wallet))));
            return;
        }
        var inv = sp.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) if (Money.valueOf(inv.getItem(i)) > 0) inv.setItem(i, ItemStack.EMPTY);
        Money.setWalletBalance(wallet, Money.walletBalance(wallet) + loose);
        sp.sendSystemMessage(net.minecraft.network.chat.Component.literal("§aВ кошелёк убрано " + Money.fmt(loose) + ". Всего: " + Money.fmt(Money.walletBalance(wallet))));
    }

    /** Shift+ПКМ кошельком: окно выдачи монет. */
    public static void openWallet(ServerPlayer sp) {
        new ChestGui(1, "Кошелёк", gui -> {
            ItemStack w = sp.getMainHandItem();
            if (!Money.isWallet(w)) return;
            long bal = Money.walletBalance(w);
            gui.set(0, Icons.of(ModItems.WALLET.get(), "§6Кошелёк", "§7Внутри: §f" + Money.fmt(bal), "§7ЛКМ — 1 монета, ПКМ — 10"), null);
            int slot = 2;
            for (long v : new long[]{Money.PLATINUM, Money.GOLD, Money.SILVER, Money.COPPER}) {
                long value = v;
                gui.set(slot, Icons.of(Money.coin(v), "§fДостать: " + Money.fmt(v)), (pl, right, shift) -> {
                    ItemStack wl = pl.getMainHandItem();
                    if (!Money.isWallet(wl)) throw new PrevailException("Держите кошелёк в руке.");
                    long want = value * (right ? 10 : 1);
                    long b = Money.walletBalance(wl);
                    if (b < want) throw new PrevailException("В кошельке только " + Money.fmt(b) + ".");
                    Money.setWalletBalance(wl, b - want);
                    Money.giveStacks(pl, Money.coin(value), want / value);
                });
                slot += 2;
            }
        }).open(sp);
    }

    public static List<String> marketIds() {
        return new ArrayList<>(Prevail.data().market.keySet());
    }
}

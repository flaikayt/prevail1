package ru.prevailcraft.prevail.profession;

/** Заготовка на кузнечной наковальне. */
public final class AnvilWork {
    public long heatedAt;
    public int strikes;
    public String smith;

    public AnvilWork() {}
}

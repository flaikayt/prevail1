package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.menu.KeyringMenu;

/** Связка ключей: кольцо с 8 ячейками по кругу. */
public class KeyringScreen extends AbstractContainerScreen<KeyringMenu> {
    public KeyringScreen(KeyringMenu menu, Inventory inv, Component title) {
        super(menu, inv, title, 176, 174);
        this.inventoryLabelY = 81;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(g, mouseX, mouseY, partialTick);
        int x = leftPos, y = topPos;
        Ui.panel(g, x, y, imageWidth, imageHeight, 0xFF2E2A3A);
        // кольцо
        int cx = x + KeyringMenu.CX, cy = y + KeyringMenu.CY;
        for (int a = 0; a < 360; a += 3) {
            double r = Math.toRadians(a);
            int px = cx + (int) Math.round(Math.cos(r) * KeyringMenu.R), py = cy + (int) Math.round(Math.sin(r) * KeyringMenu.R);
            Ui.fill(g, px - 1, py - 1, px + 2, py + 2, 0xFFB8C4D0);
        }
        for (int i = 0; i < KeyringMenu.SIZE; i++) {
            double a = Math.toRadians(-90 + i * 45);
            int sx = cx + (int) Math.round(Math.cos(a) * KeyringMenu.R) - 9;
            int sy = cy + (int) Math.round(Math.sin(a) * KeyringMenu.R) - 9;
            Ui.slot(g, sx, sy);
        }
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 91 + r * 18);
        for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 149);
    }

    @Override
    protected void extractLabels(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        g.text(font, title, titleLabelX, titleLabelY, 0xFFE0E0E0, false);
        g.text(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, 0xFFE0E0E0, false);
    }
}

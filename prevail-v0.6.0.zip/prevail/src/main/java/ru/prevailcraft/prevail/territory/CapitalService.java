package ru.prevailcraft.prevail.territory;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.ChunkKey;
import ru.prevailcraft.prevail.core.Kingdom;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.economy.Money;

/**
 * Столица: квадрат чанков вокруг центра. Здесь стоят Фонд, рынок, скупщик и Корона.
 * Пока в королевской казне есть деньги, «стража» не даёт ломать и строить в столице
 * никому, кроме короля, десницы, архитектора, его бригады и арендаторов своих участков.
 */
public final class CapitalService {
    private CapitalService() {}

    private static Kingdom k() {
        return Prevail.data().kingdom;
    }

    public static boolean exists() {
        return k().capitalRadius >= 0 && k().capitalDim != null;
    }

    public static boolean inCapital(Level level, BlockPos pos) {
        if (!exists() || !k().capitalDim.equals(VersionCompat.dimId(level))) return false;
        int cx = pos.getX() >> 4, cz = pos.getZ() >> 4;
        return Math.abs(cx - k().capitalX) <= k().capitalRadius && Math.abs(cz - k().capitalZ) <= k().capitalRadius;
    }

    /** Столица основывается установкой Фонда: центр — чанк Фонда, 9×9 чанков. */
    public static String setCapitalAt(ServerPlayer sp, Level level, BlockPos pos) {
        k().capitalDim = VersionCompat.dimId(level);
        k().capitalX = pos.getX() >> 4;
        k().capitalZ = pos.getZ() >> 4;
        k().capitalRadius = 4;
        return "Основана столица королевства: " + claimCapital(sp, level);
    }

    /** Клеймит 9×9 серверными клеймами OPAC и снимает с них защиту OPAC (защиту столицы ведёт Prevail). */
    private static String claimCapital(ServerPlayer sp, Level level) {
        java.util.UUID owner = OpacBridge.serverClaimId();
        if (owner == null) owner = sp.getUUID();
        int n = OpacBridge.claimArea(Prevail.server(), level, k().capitalX, k().capitalZ, 4, owner);
        boolean relaxed = OpacBridge.relaxServerClaims(Prevail.server());
        return n + " из 81 чанка (9×9) на карте." + (relaxed ? "" :
                " §cВНИМАНИЕ: отключите защиту серверных клеймов в openpartiesandclaims-server-claim-config.toml (protectClaimedChunks = false), иначе в столице нельзя будет открывать двери и сундуки.");
    }

    public static String setCapital(ServerPlayer sp, int radius) {
        k().capitalDim = VersionCompat.dimId(sp.level());
        k().capitalX = sp.blockPosition().getX() >> 4;
        k().capitalZ = sp.blockPosition().getZ() >> 4;
        k().capitalRadius = radius;
        return "Столица перенесена: центр в чанке " + k().capitalX + ", " + k().capitalZ + ". " + claimCapital(sp, sp.level());
    }

    /** Можно ли игроку менять блоки в этой точке столицы. */
    public static boolean mayBuild(ServerPlayer p, Level level, BlockPos pos) {
        if (VersionCompat.isAdmin(p)) return true;
        String id = p.getUUID().toString();
        if (CourtService.has(id, CourtOffice.ARCHITECT)) return true; // король, десница, архитектор
        if (k().brigade.contains(id)) {
            Plot plot = k().plots.get(ChunkKey.of(level, pos));
            return plot == null || plot.free(); // бригада не трогает частные участки
        }
        Plot plot = k().plots.get(ChunkKey.of(level, pos));
        if (plot != null && plot.rentedBy(id)) return true;
        return k().treasury <= 0; // казна пуста — стража разбежалась
    }

    // ---------- аренда ----------

    public static String createPlot(ServerPlayer sp, long rent) {
        if (!CourtService.has(Players.profile(sp).uuid, CourtOffice.CHANCELLOR)) throw new PrevailException("Участками ведает канцлер.");
        if (!inCapital(sp.level(), sp.blockPosition())) throw new PrevailException("Участки есть только в столице.");
        String key = ChunkKey.of(sp);
        Plot p = k().plots.computeIfAbsent(key, x -> new Plot());
        p.rentPerDay = rent;
        return "Участок [" + key + "] сдаётся за " + Money.fmt(rent) + " в сутки.";
    }

    public static String evict(ServerPlayer sp) {
        if (!CourtService.has(Players.profile(sp).uuid, CourtOffice.CHANCELLOR)) throw new PrevailException("Выселяет канцлер.");
        Plot p = k().plots.get(ChunkKey.of(sp));
        if (p == null || p.tenant == null) throw new PrevailException("Здесь нет арендатора.");
        Players.message(p.tenant, "§cКанцлер расторг вашу аренду участка в столице.");
        p.tenant = null;
        p.paidUntil = 0;
        return "Арендатор выселен.";
    }

    public static String rent(ServerPlayer sp, int days) {
        if (days < 1 || days > 30) throw new PrevailException("Срок аренды: 1–30 суток.");
        Plot p = k().plots.get(ChunkKey.of(sp));
        if (p == null) throw new PrevailException("Этот участок не сдаётся.");
        String id = sp.getUUID().toString();
        if (!p.free() && !id.equals(p.tenant)) throw new PrevailException("Участок уже арендован.");
        long cost = p.rentPerDay * days;
        if (!Money.take(sp, cost)) throw new PrevailException("Аренда на " + days + " сут. стоит " + Money.fmt(cost) + ".");
        k().treasury += cost;
        long base = id.equals(p.tenant) ? Math.max(p.paidUntil, System.currentTimeMillis()) : System.currentTimeMillis();
        p.tenant = id;
        p.paidUntil = base + days * 86_400_000L;
        return "Участок ваш ещё на " + days + " сут.";
    }

    public static String plotInfo(ServerPlayer sp) {
        Plot p = k().plots.get(ChunkKey.of(sp));
        if (p == null) return inCapital(sp.level(), sp.blockPosition()) ? "Королевская земля, не сдаётся." : "Это не столица.";
        if (p.free()) return "Участок свободен: " + Money.fmt(p.rentPerDay) + " в сутки. /plot rent <дней>";
        long h = (p.paidUntil - System.currentTimeMillis()) / 3_600_000L;
        return "Арендатор: " + Players.name(p.tenant) + ", оплачено ещё ~" + h + " ч.";
    }

    // ---------- бригада ----------

    public static String brigade(ServerPlayer sp, String action, String name) {
        PlayerProfile me = Players.profile(sp);
        if (!CourtService.has(me.uuid, CourtOffice.ARCHITECT)) throw new PrevailException("Бригады собирает архитектор.");
        switch (action) {
            case "add" -> {
                PlayerProfile t = Players.byName(name);
                k().brigade.add(t.uuid);
                Players.message(t.uuid, "§aВы приняты в строительную бригаду столицы до конца рабочего дня.");
                return t.name + " в бригаде.";
            }
            case "remove" -> {
                PlayerProfile t = Players.byName(name);
                k().brigade.remove(t.uuid);
                return t.name + " выведен из бригады.";
            }
            default -> {
                for (String m : k().brigade) Players.message(m, "§7Рабочий день окончен — бригада распущена.");
                k().brigade.clear();
                return "Бригада распущена.";
            }
        }
    }
}

package ru.prevailcraft.prevail.vassalage;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.registry.ModItems;

/** Обряды: Грамота — принять крепостного, меч — посвятить в рыцари. */
public final class VassalEvents {

    @SubscribeEvent
    public void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (!Prevail.running() || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getEntity() instanceof ServerPlayer sp) || !(e.getTarget() instanceof ServerPlayer target)) return;
        ItemStack hand = e.getItemStack();
        try {
            if (hand.is(ModItems.HOUSE_CHARTER.get())) {
                e.setCanceled(true);
                HouseService.inviteByRitual(sp, target);
            } else if (hand.is(ItemTags.SWORDS) && target.isCrouching()) {
                e.setCanceled(true);
                HouseService.knightByRitual(sp, target);
            }
        } catch (PrevailException ex) {
            sp.sendSystemMessage(Component.literal("§c" + ex.getMessage()));
        }
    }
}

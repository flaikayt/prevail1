package ru.prevailcraft.prevail.economy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.compat.ItemData;
import ru.prevailcraft.prevail.registry.ModItems;

/**
 * Деньги — физические монеты: 1 платиновая = 10 золотых = 100 серебряных = 1000 медных.
 * Кошелёк хранит сумму внутри себя и тоже учитывается при оплате.
 * Все суммы в коде — в медяках.
 */
public final class Money {
    public static final long PLATINUM = 1000, GOLD = 100, SILVER = 10, COPPER = 1;

    private Money() {}

    public static Item coin(long value) {
        if (value == PLATINUM) return ModItems.PLATINUM_COIN.get();
        if (value == GOLD) return ModItems.GOLD_COIN.get();
        if (value == SILVER) return ModItems.SILVER_COIN.get();
        return ModItems.COPPER_COIN.get();
    }

    public static long valueOf(ItemStack s) {
        if (s.is(ModItems.PLATINUM_COIN.get())) return PLATINUM * s.getCount();
        if (s.is(ModItems.GOLD_COIN.get())) return GOLD * s.getCount();
        if (s.is(ModItems.SILVER_COIN.get())) return SILVER * s.getCount();
        if (s.is(ModItems.COPPER_COIN.get())) return COPPER * s.getCount();
        return 0;
    }

    public static boolean isWallet(ItemStack s) {
        return s.is(ModItems.WALLET.get());
    }

    public static long walletBalance(ItemStack s) {
        return ItemData.getLong(s, "balance");
    }

    public static void setWalletBalance(ItemStack s, long v) {
        ItemData.putLong(s, "balance", Math.max(0, v));
        ItemData.lore(s, "§7Внутри: §f" + fmt(Math.max(0, v)), "§8ПКМ — сложить все монеты;", "§8если монет нет — достать стопку самых крупных");
    }

    public static long loose(ServerPlayer p) {
        Inventory inv = p.getInventory();
        long t = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) t += valueOf(inv.getItem(i));
        return t;
    }

    public static long count(ServerPlayer p) {
        Inventory inv = p.getInventory();
        long t = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            t += valueOf(s);
            if (isWallet(s)) t += walletBalance(s);
        }
        return t;
    }

    /** Списать сумму: сначала россыпь (со сдачей), потом кошельки. */
    public static boolean take(ServerPlayer p, long amount) {
        if (amount <= 0) return true;
        if (count(p) < amount) return false;
        Inventory inv = p.getInventory();
        long l = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            long v = valueOf(inv.getItem(i));
            if (v > 0) {
                l += v;
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
        if (l >= amount) {
            give(p, l - amount);
            return true;
        }
        long need = amount - l;
        for (int i = 0; i < inv.getContainerSize() && need > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (!isWallet(s)) continue;
            long b = walletBalance(s);
            long d = Math.min(b, need);
            setWalletBalance(s, b - d);
            need -= d;
        }
        return true;
    }

    public static void give(ServerPlayer p, long amount) {
        for (long v : new long[]{PLATINUM, GOLD, SILVER, COPPER}) {
            long n = amount / v;
            amount %= v;
            giveStacks(p, coin(v), n);
        }
    }

    public static void giveStacks(ServerPlayer p, Item item, long n) {
        while (n > 0) {
            int k = (int) Math.min(item.getDefaultMaxStackSize(), n);
            ItemStack st = new ItemStack(item, k);
            if (!p.getInventory().add(st) && !st.isEmpty()) p.drop(st, false);
            n -= k;
        }
    }

    /** Все суммы показываются в медных монетах: «1 250 мед.». */
    public static String fmt(long c) {
        String digits = String.valueOf(Math.abs(c));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < digits.length(); i++) {
            if (i > 0 && (digits.length() - i) % 3 == 0) sb.append(' ');
            sb.append(digits.charAt(i));
        }
        return (c < 0 ? "-" : "") + sb + " мед.";
    }
}

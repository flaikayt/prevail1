package ru.prevailcraft.prevail.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.ChunkKey;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.economy.EconomyService;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.economy.PowerCoins;
import ru.prevailcraft.prevail.law.PrisonService;
import ru.prevailcraft.prevail.law.WantedService;
import ru.prevailcraft.prevail.profession.Branch;
import ru.prevailcraft.prevail.profession.Profession;
import ru.prevailcraft.prevail.profession.ProfessionService;
import ru.prevailcraft.prevail.territory.CapitalService;
import ru.prevailcraft.prevail.territory.SuspicionService;
import ru.prevailcraft.prevail.territory.TerritoryService;
import ru.prevailcraft.prevail.vassalage.HouseService;
import ru.prevailcraft.prevail.war.WarService;
import ru.prevailcraft.prevail.world.Epoch;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

/**
 * Команды. Основная игра идёт через блоки и обряды; команды — для того,
 * что неудобно делать в окне (названия, ники, суммы).
 * /house /treasury /land /plot /war /wanted /prison /court /prof /epoch /prevailadmin
 */
public final class PrevailCommands {

    private static SuggestionProvider<CommandSourceStack> words(List<String> list) {
        return (c, b) -> SharedSuggestionProvider.suggest(list, b);
    }

    private static final SuggestionProvider<CommandSourceStack> OFFICES =
            words(Arrays.stream(CourtOffice.values()).map(o -> o.name().toLowerCase(Locale.ROOT)).toList());
    private static final SuggestionProvider<CommandSourceStack> PROFS =
            words(Arrays.stream(Profession.values()).filter(p -> p != Profession.NONE).map(p -> p.name().toLowerCase(Locale.ROOT)).toList());
    private static final SuggestionProvider<CommandSourceStack> BRANCHES =
            words(Arrays.stream(Branch.values()).map(b -> b.name().toLowerCase(Locale.ROOT)).toList());

    @SubscribeEvent
    public void onRegister(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        house(d);
        economy(d);
        land(d);
        war(d);
        law(d);
        court(d);
        prof(d);
        admin(d);
    }

    // ═══════════ Вассалитет ═══════════
    private static void house(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("house")
                .executes(c -> Cmd.player(c, p -> HouseService.info(Players.requireHouse(Players.profile(p)))))
                .then(literal("info").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .executes(c -> Cmd.player(c, p -> HouseService.info(Players.houseByName(getString(c, "house")))))))
                .then(literal("list").executes(c -> Cmd.any(c, s -> HouseService.list())))
                .then(literal("accept").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .executes(c -> Cmd.player(c, p -> HouseService.accept(p, getString(c, "house"))))))
                .then(literal("leave").executes(c -> Cmd.player(c, HouseService::leave)))
                .then(literal("kick").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.player(c, p -> HouseService.kick(p, getString(c, "player"))))))
                .then(literal("demote").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.player(c, p -> HouseService.demote(p, getString(c, "player"))))))
                .then(literal("assign").then(argument("serf", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .then(argument("knight", word()).suggests(Cmd.KNOWN_PLAYERS)
                                .executes(c -> Cmd.player(c, p -> HouseService.assign(p, getString(c, "serf"), getString(c, "knight")))))))
                .then(literal("transfer").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.player(c, p -> HouseService.transfer(p, getString(c, "player"))))))
                .then(literal("disband").executes(c -> Cmd.player(c, HouseService::disband)))
                .then(literal("seat").executes(c -> Cmd.player(c, HouseService::setSeat)))
                .then(literal("prison").executes(c -> Cmd.player(c, HouseService::setPrison)))
                .then(literal("ally").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .executes(c -> Cmd.player(c, p -> HouseService.ally(p, getString(c, "house"), true)))))
                .then(literal("unally").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .executes(c -> Cmd.player(c, p -> HouseService.ally(p, getString(c, "house"), false)))))
                .then(literal("fealty")
                        .then(literal("offer").then(argument("house", word()).suggests(Cmd.HOUSES)
                                .executes(c -> Cmd.player(c, p -> HouseService.offerFealty(p, getString(c, "house"))))))
                        .then(literal("accept").then(argument("house", word()).suggests(Cmd.HOUSES)
                                .executes(c -> Cmd.player(c, p -> HouseService.acceptFealty(p, getString(c, "house"))))))
                        .then(literal("renounce").executes(c -> Cmd.player(c, HouseService::renounce)))
                        .then(literal("release").then(argument("house", word()).suggests(Cmd.HOUSES)
                                .executes(c -> Cmd.player(c, p -> HouseService.releaseVassal(p, getString(c, "house"))))))));
    }

    // ═══════════ Деньги ═══════════
    private static void economy(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("treasury")
                .executes(c -> Cmd.player(c, p -> {
                    House h = Players.requireHouse(Players.profile(p));
                    return "Казна Дома " + h.name + ": " + Money.fmt(h.treasury) + (h.debt > 0 ? " §c(недоимка " + Money.fmt(h.debt) + ")" : "")
                            + "\n§7При себе: " + Money.fmt(Money.count(p)) + ", монет власти: " + PowerCoins.count(p);
                }))
                .then(literal("deposit").then(argument("amount", LongArgumentType.longArg(1))
                        .executes(c -> Cmd.player(c, p -> EconomyService.deposit(p, LongArgumentType.getLong(c, "amount"))))))
                .then(literal("withdraw").then(argument("amount", LongArgumentType.longArg(1))
                        .executes(c -> Cmd.player(c, p -> EconomyService.withdraw(p, LongArgumentType.getLong(c, "amount")))))));
    }

    // ═══════════ Земли и столица ═══════════
    private static void land(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("land")
                .executes(c -> Cmd.player(c, PrevailCommands::landInfo))
                .then(literal("suspects").executes(c -> Cmd.player(c, p -> {
                    House h = HouseService.requireOfficial(Players.profile(p));
                    Map<String, Double> m = Prevail.data().suspicion.get(h.id);
                    if (m == null || m.isEmpty()) return "На ваших землях спокойно.";
                    StringBuilder sb = new StringBuilder("§eПодозреваемые на землях Дома:");
                    m.entrySet().stream().sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                            .forEach(en -> sb.append("\n§f").append(Players.name(en.getKey())).append(" — ").append(en.getValue().intValue()));
                    return sb.toString();
                }))));
        d.register(literal("plot")
                .executes(c -> Cmd.player(c, CapitalService::plotInfo))
                .then(literal("rent").then(argument("days", IntegerArgumentType.integer(1, 30))
                        .executes(c -> Cmd.player(c, p -> CapitalService.rent(p, IntegerArgumentType.getInteger(c, "days")))))));
        d.register(literal("epoch").executes(c -> Cmd.any(c, s -> {
            Epoch e = Epoch.of(Epoch.current());
            return "§6Эпоха " + e.number + "/10: " + e.title + "§f — открыто: " + e.unlocks + ". Вклады — у Фонда.";
        })));
    }

    private static String landInfo(ServerPlayer p) {
        int cx = p.blockPosition().getX() >> 4, cz = p.blockPosition().getZ() >> 4;
        if (CapitalService.inCapital(p.level(), p.blockPosition())) return "Столица королевства. " + CapitalService.plotInfo(p);
        House owner = TerritoryService.houseAt(p.level(), cx, cz);
        House base = TerritoryService.baseHouseAt(p.level(), cx, cz);
        if (owner == null) return "Ничейная земля [чанк " + cx + ", " + cz + "]. Заклеймить — через карту Xaero (Open Parties and Claims).";
        StringBuilder sb = new StringBuilder("Земли Дома §e" + owner.name + "§f [чанк " + cx + ", " + cz + "]");
        if (base != null && !base.id.equals(owner.id)) sb.append(" §c(оккупировано, законный владелец — ").append(base.name).append(")");
        double s = SuspicionService.get(owner.id, Players.profile(p).uuid);
        if (s > 0) sb.append("\n§7Ваша подозрительность здесь: ").append((int) s);
        return sb.toString();
    }

    // ═══════════ Войны ═══════════
    private static void war(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("war")
                .executes(c -> Cmd.any(c, s -> WarService.list()))
                .then(literal("declare").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .then(argument("reason", greedyString())
                                .executes(c -> Cmd.player(c, p -> WarService.declare(p, getString(c, "house"), getString(c, "reason")))))))
                .then(literal("rebel").executes(c -> Cmd.player(c, WarService::rebel)))
                .then(literal("surrender").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .executes(c -> Cmd.player(c, p -> WarService.surrender(p, getString(c, "house"))))))
                .then(literal("peace").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .executes(c -> Cmd.player(c, p -> WarService.peace(p, getString(c, "house")))))));
    }

    // ═══════════ Закон ═══════════
    private static void law(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("wanted")
                .executes(c -> Cmd.any(c, s -> WantedService.list()))
                .then(literal("declare").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .then(argument("scope", word()).suggests(words(List.of("royal", "house")))
                                .then(argument("bounty", LongArgumentType.longArg(0))
                                        .then(argument("reason", greedyString())
                                                .executes(c -> Cmd.player(c, p -> WantedService.declare(p, getString(c, "player"), getString(c, "scope"),
                                                        LongArgumentType.getLong(c, "bounty"), getString(c, "reason")))))))))
                .then(literal("revoke").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .then(argument("scope", word()).suggests(words(List.of("royal", "house")))
                                .executes(c -> Cmd.player(c, p -> WantedService.revoke(p, getString(c, "player"), getString(c, "scope"))))))));
        d.register(literal("prison")
                .executes(c -> Cmd.player(c, PrisonService::status))
                .then(literal("bail").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.player(c, p -> PrisonService.bail(p, getString(c, "player")))))));
    }

    // ═══════════ Двор ═══════════
    private static void court(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("court")
                .executes(c -> Cmd.any(c, s -> CourtService.info()))
                .then(literal("claim").executes(c -> Cmd.player(c, CourtService::claim)))
                .then(literal("vote").then(argument("lord", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.player(c, p -> CourtService.vote(p, getString(c, "lord"))))))
                .then(literal("bribe").then(argument("lord", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .then(argument("coins", IntegerArgumentType.integer(2, 1000))
                                .executes(c -> Cmd.player(c, p -> CourtService.bribe(p, getString(c, "lord"), IntegerArgumentType.getInteger(c, "coins")))))))
                .then(literal("crown").executes(c -> Cmd.player(c, CourtService::crown)))
                .then(literal("abdicate").executes(c -> Cmd.player(c, CourtService::abdicate)))
                .then(literal("swear").executes(c -> Cmd.player(c, CourtService::swear)))
                .then(literal("donate").then(argument("coins", IntegerArgumentType.integer(1, 1000))
                        .executes(c -> Cmd.player(c, p -> CourtService.donate(p, IntegerArgumentType.getInteger(c, "coins"))))))
                .then(literal("appoint").then(argument("office", word()).suggests(OFFICES)
                        .then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                                .executes(c -> Cmd.player(c, p -> CourtService.appoint(p, CourtService.parseOffice(getString(c, "office")),
                                        Players.byName(getString(c, "player"))))))))
                .then(literal("dismiss").then(argument("office", word()).suggests(OFFICES)
                        .executes(c -> Cmd.player(c, p -> CourtService.dismiss(p, CourtService.parseOffice(getString(c, "office")))))))
                .then(literal("tax").then(argument("perChunk", LongArgumentType.longArg(0))
                        .executes(c -> Cmd.player(c, p -> CourtService.setTax(p, LongArgumentType.getLong(c, "perChunk"))))))
                .then(literal("mint")
                        .then(literal("open").executes(c -> Cmd.player(c, p -> EconomyService.setMinting(p, true))))
                        .then(literal("close").executes(c -> Cmd.player(c, p -> EconomyService.setMinting(p, false)))))
                .then(literal("withdraw").then(argument("amount", LongArgumentType.longArg(1))
                        .executes(c -> Cmd.player(c, p -> CourtService.treasuryWithdraw(p, LongArgumentType.getLong(c, "amount"))))))
                .then(literal("prison").executes(c -> Cmd.player(c, CourtService::setRoyalPrison)))
                .then(literal("pardon").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.player(c, p -> PrisonService.pardon(p, getString(c, "player"))))))
                .then(literal("hunt").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .then(argument("bounty", LongArgumentType.longArg(0))
                                .executes(c -> Cmd.player(c, p -> CourtService.hunt(p, getString(c, "player"), LongArgumentType.getLong(c, "bounty")))))))
                .then(literal("edict").then(literal("peace").executes(c -> Cmd.player(c, CourtService::edictPeace))))
                .then(literal("license").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .then(argument("profession", word()).suggests(PROFS)
                                .executes(c -> Cmd.player(c, p -> CourtService.license(p, getString(c, "player"), getString(c, "profession")))))))
                .then(literal("unlicense").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.player(c, p -> CourtService.revokeLicense(p, getString(c, "player"))))))
                .then(literal("plot")
                        .then(argument("rent", LongArgumentType.longArg(0))
                                .executes(c -> Cmd.player(c, p -> CapitalService.createPlot(p, LongArgumentType.getLong(c, "rent")))))
                        .then(literal("evict").executes(c -> Cmd.player(c, CapitalService::evict))))
                .then(literal("brigade")
                        .then(literal("add").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                                .executes(c -> Cmd.player(c, p -> CapitalService.brigade(p, "add", getString(c, "player"))))))
                        .then(literal("remove").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                                .executes(c -> Cmd.player(c, p -> CapitalService.brigade(p, "remove", getString(c, "player"))))))
                        .then(literal("dismiss").executes(c -> Cmd.player(c, p -> CapitalService.brigade(p, "dismiss", null))))));
    }

    // ═══════════ Ремёсла ═══════════
    private static void prof(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("prof")
                .executes(c -> Cmd.player(c, ProfessionService::info))
                .then(literal("list").executes(c -> Cmd.any(c, s -> ProfessionService.list())))
                .then(literal("choose").then(argument("profession", word()).suggests(PROFS)
                        .executes(c -> Cmd.player(c, p -> ProfessionService.choose(p, getString(c, "profession"))))))
                .then(literal("branch").then(argument("branch", word()).suggests(BRANCHES)
                        .executes(c -> Cmd.player(c, p -> ProfessionService.chooseBranch(p, getString(c, "branch")))))));
    }

    // ═══════════ Администрирование ═══════════
    private static void admin(CommandDispatcher<CommandSourceStack> d) {
        d.register(literal("prevailadmin")
                .requires(VersionCompat::isAdmin)
                .then(literal("save").executes(c -> Cmd.any(c, s -> {
                    Prevail.store().save();
                    return "Данные Prevail сохранены.";
                })))
                .then(literal("capital").then(argument("radius", IntegerArgumentType.integer(0, 64))
                        .executes(c -> Cmd.player(c, p -> CapitalService.setCapital(p, IntegerArgumentType.getInteger(c, "radius"))))))
                .then(literal("setking").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.any(c, s -> {
                            CourtService.setKing(Players.byName(getString(c, "player")).uuid, "по воле богов");
                            return null;
                        }))))
                .then(literal("epoch").then(argument("n", IntegerArgumentType.integer(1, 10))
                        .executes(c -> Cmd.any(c, s -> {
                            Prevail.data().kingdom.epoch = IntegerArgumentType.getInteger(c, "n");
                            Prevail.data().kingdom.epochProgress.clear();
                            ru.prevailcraft.prevail.world.FundService.refreshSlots();
                            return "Эпоха установлена: " + Epoch.of(Prevail.data().kingdom.epoch).title;
                        }))))
                .then(literal("essence").then(argument("n", IntegerArgumentType.integer(0, 5))
                        .executes(c -> Cmd.any(c, s -> {
                            Prevail.data().kingdom.essence = IntegerArgumentType.getInteger(c, "n");
                            return "Истока в Фонде: " + Prevail.data().kingdom.essence;
                        }))))
                .then(literal("givepower").then(argument("n", IntegerArgumentType.integer(1, 1000))
                        .executes(c -> Cmd.player(c, p -> {
                            PowerCoins.give(p, IntegerArgumentType.getInteger(c, "n"));
                            return "Выдано.";
                        }))))
                .then(literal("crowntreasury").then(argument("amount", LongArgumentType.longArg())
                        .executes(c -> Cmd.any(c, s -> {
                            CourtService.k().treasury += LongArgumentType.getLong(c, "amount");
                            return "Королевская казна: " + Money.fmt(CourtService.k().treasury);
                        }))))
                .then(literal("housetreasury").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .then(argument("amount", LongArgumentType.longArg())
                                .executes(c -> Cmd.any(c, s -> {
                                    House h = Players.houseByName(getString(c, "house"));
                                    h.treasury += LongArgumentType.getLong(c, "amount");
                                    return "Казна " + h.name + ": " + Money.fmt(h.treasury);
                                })))))
                .then(literal("release").then(argument("player", word()).suggests(Cmd.KNOWN_PLAYERS)
                        .executes(c -> Cmd.any(c, s -> {
                            PrisonService.release(Players.byName(getString(c, "player")).uuid, "решение администрации");
                            return "Освобождён.";
                        }))))
                .then(literal("taxnow").executes(c -> Cmd.any(c, s -> {
                    EconomyService.collectTaxes();
                    return "Налоги собраны.";
                })))
                .then(literal("heart").then(argument("house", word()).suggests(Cmd.HOUSES)
                        .executes(c -> Cmd.player(c, p -> {
                            House h = Players.houseByName(getString(c, "house"));
                            p.getInventory().add(HouseService.makeHeart(h));
                            return "Выдано Сердце Дома " + h.name + ".";
                        }))))
                .then(literal("unoccupy").executes(c -> Cmd.player(c, p -> {
                    if (Prevail.data().occupiedChunks.remove(ChunkKey.of(p)) == null) throw new PrevailException("Этот чанк не оккупирован.");
                    return "Оккупация снята.";
                }))));
    }

}

package ru.prevailcraft.prevail.registry;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import java.util.function.UnaryOperator;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.prevailcraft.prevail.PrevailMod;

import java.util.List;

/**
 * Блоки мода. Это простые блоки без BlockEntity: их состояние хранится
 * в data.json по координатам, а GUI открывается через событие ПКМ
 * (см. world/BlockEvents). Так меньше версионно-хрупкого кода.
 */
public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(PrevailMod.MODID);

    /** Неразрушимые в выживании — ставит администрация/король в столице. */
    public static final DeferredBlock<Block> FUND = block("fund", unbreakable());
    public static final DeferredBlock<Block> MARKET = block("market", unbreakable());
    public static final DeferredBlock<Block> BUYER = block("buyer", unbreakable());
    public static final DeferredBlock<Block> THRONE = block("throne", unbreakable());

    /** Обычные, крафтятся игроками. */
    public static final DeferredBlock<Block> HEARTH = block("hearth", p -> p.strength(6f, 1200f).sound(SoundType.STONE).lightLevel(s -> 12));
    public static final DeferredBlock<Block> STRATEGIST = block("strategist", p -> p.strength(2.5f).sound(SoundType.WOOD));
    public static final DeferredBlock<Block> FORGE_ANVIL = block("forge_anvil", p -> p.strength(5f, 1200f).sound(SoundType.ANVIL));

    public static final List<DeferredBlock<Block>> ALL = List.of(FUND, MARKET, BUYER, THRONE, HEARTH, STRATEGIST, FORGE_ANVIL);

    private ModBlocks() {}

    private static UnaryOperator<BlockBehaviour.Properties> unbreakable() {
        return p -> p.strength(-1f, 3_600_000f).sound(SoundType.STONE);
    }

    private static DeferredBlock<Block> block(String name, UnaryOperator<BlockBehaviour.Properties> props) {
        DeferredBlock<Block> b = BLOCKS.registerSimpleBlock(name, props);
        ModItems.ITEMS.registerSimpleBlockItem(b);
        return b;
    }

    public static boolean is(BlockState state, DeferredBlock<Block> b) {
        return state.is(b.get());
    }

    public static void register(IEventBus modBus) {
        BLOCKS.register(modBus);
    }
}

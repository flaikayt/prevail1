package ru.prevailcraft.prevail.house;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import ru.prevailcraft.prevail.compat.ItemData;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Pos;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.TerritoryService;
import ru.prevailcraft.prevail.ui.ChestGui;
import ru.prevailcraft.prevail.ui.Icons;
import ru.prevailcraft.prevail.vassalage.HouseService;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Родовой очаг. В него вкладывают Сердце Дома, и он потребляет содержание:
 *   топливо — 2/ч за домен;   еда — 5 сытости/ч за члена Дома (любая еда!);
 *   ткань — 1/ч за домен (от 10 членов);   роскошь — 1/ч за каждые 10 членов (от 20).
 * Голод: 1 ч — слабость членам; 12 ч — Дом перестаёт стеречь земли; 48 ч — Сердце раскалывается.
 */
public final class HearthService {
    public static final String FUEL = "fuel", FOOD = "food", CLOTH = "cloth", LUXURY = "luxury";

    private HearthService() {}

    public static Map<String, Double> needPerHour(House h) {
        int domains = TerritoryService.domainCount(h);
        int members = h.members.size();
        Map<String, Double> m = new LinkedHashMap<>();
        m.put(FUEL, 2.0 * domains);
        m.put(FOOD, 5.0 * members);
        m.put(CLOTH, members >= 10 ? 1.0 * domains : 0);
        m.put(LUXURY, members >= 20 ? (double) (members / 10) : 0);
        return m;
    }

    public static String title(String cat) {
        return switch (cat) {
            case FUEL -> "Топливо";
            case FOOD -> "Пропитание";
            case CLOTH -> "Ткани";
            default -> "Роскошь";
        };
    }

    /** Категория и ценность предмета для очага, либо null. */
    private static Object[] value(ItemStack s) {
        if (s.is(Items.HONEY_BOTTLE) || s.is(Items.CAKE) || s.is(Items.PUMPKIN_PIE) || s.is(Items.GOLDEN_APPLE)) return new Object[]{LUXURY, 4.0};
        if (s.is(Items.COOKIE) || s.is(Items.GLOW_BERRIES)) return new Object[]{LUXURY, 1.0};
        if (s.is(Items.COAL) || s.is(Items.CHARCOAL)) return new Object[]{FUEL, 8.0};
        if (s.is(Items.COAL_BLOCK)) return new Object[]{FUEL, 72.0};
        if (s.is(ItemTags.LOGS)) return new Object[]{FUEL, 2.0};
        if (s.is(ItemTags.PLANKS)) return new Object[]{FUEL, 0.5};
        if (s.is(ItemTags.WOOL) || s.is(Items.LEATHER)) return new Object[]{CLOTH, 4.0};
        if (s.is(Items.STRING)) return new Object[]{CLOTH, 1.0};
        FoodProperties food = s.get(DataComponents.FOOD);
        if (food != null) return new Object[]{FOOD, (double) food.nutrition()};
        return null;
    }

    // ---------- блок ----------

    /** ПКМ по очагу: Сердцем — разжечь; иначе открыть окно. */
    public static void use(ServerPlayer sp, String blockKey) {
        ItemStack hand = sp.getMainHandItem();
        House owner = null;
        for (House h : Prevail.data().houses.values()) if (blockKey.equals(h.hearth)) owner = h;
        if (hand.is(ModItems.HOUSE_HEART.get())) {
            House h = Prevail.data().houses.get(ItemData.getString(hand, "house"));
            if (h == null) throw new PrevailException("Сердце мёртвого Дома холодно.");
            if (owner != null && owner != h) throw new PrevailException("Этот очаг принадлежит Дому " + owner.name + ".");
            Pos pos = Pos.fromBlockKey(blockKey);
            var lvl = sp.level();
            House land = TerritoryService.houseAt(lvl, (int) Math.floor(pos.x) >> 4, (int) Math.floor(pos.z) >> 4);
            if (land != h) throw new PrevailException("Очаг должен стоять на земле вашего Дома.");
            hand.shrink(1);
            h.hearth = blockKey;
            h.heartPlaced = true;
            if (h.lastUpkeepMillis == 0) h.lastUpkeepMillis = System.currentTimeMillis();
            Players.messageHouse(h, "§6🔥 Родовой очаг Дома " + h.name + " разожжён.");
            return;
        }
        if (owner == null) throw new PrevailException("Очаг холоден. Вложите в него Сердце Дома (ПКМ Сердцем).");
        open(sp, owner);
    }

    public static void open(ServerPlayer sp, House h) {
        new ChestGui(3, "Очаг Дома " + h.name, gui -> {
            Map<String, Double> need = needPerHour(h);
            int stage = h.hungerStage();
            gui.set(4, Icons.of(stage == 0 ? Items.CAMPFIRE : Items.SOUL_CAMPFIRE,
                    stage == 0 ? "§6Очаг горит" : "§cДом голодает (стадия " + stage + ")",
                    "§7Без еды и топлива: " + h.hungryHours + " ч.",
                    "§71 ч — слабость, 12 ч — земли без стражи, 48 ч — гибель Дома",
                    "§7Shift+клик по предметам — подбросить в очаг"), null);
            int slot = 10;
            for (Map.Entry<String, Double> n : need.entrySet()) {
                double stock = h.upkeep.getOrDefault(n.getKey(), 0.0);
                double per = n.getValue();
                String left = per <= 0 ? "не требуется" : String.format("хватит на %.1f ч.", stock / per);
                gui.set(slot, Icons.of(icon(n.getKey()), "§e" + title(n.getKey()),
                        "§7Запас: §f" + (int) stock, "§7Расход: §f" + per + "/ч", "§7" + left), null);
                slot += 2;
            }
            Icons.frame(gui);
            gui.onDeposit((pl, stack) -> feed(h, pl, stack));
        }).open(sp);
    }

    private static net.minecraft.world.item.Item icon(String cat) {
        if (FUEL.equals(cat)) return Items.COAL;
        if (FOOD.equals(cat)) return Items.BREAD;
        if (CLOTH.equals(cat)) return Items.LEATHER;
        return Items.HONEY_BOTTLE;
    }

    private static boolean feed(House h, ServerPlayer sp, ItemStack stack) {
        Object[] v = value(stack);
        if (v == null) throw new PrevailException("Очагу это не нужно.");
        String cat = (String) v[0];
        double pts = (double) v[1] * stack.getCount();
        h.upkeep.merge(cat, pts, Double::sum);
        stack.shrink(stack.getCount());
        sp.sendSystemMessage(Component.literal("§a+" + (int) pts + " к запасу «" + title(cat) + "»"), true);
        return true;
    }

    // ---------- раз в 30 секунд ----------

    public static void tick() {
        long now = System.currentTimeMillis();
        List<House> dead = new ArrayList<>();
        for (House h : Prevail.data().houses.values()) {
            if (h.lastUpkeepMillis == 0) h.lastUpkeepMillis = now;
            int guard = 0;
            while (now - h.lastUpkeepMillis >= 3_600_000L && guard++ < 48) {
                h.lastUpkeepMillis += 3_600_000L;
                hour(h);
            }
            if (h.hungerStage() >= 3) dead.add(h);
            else if (h.hungerStage() >= 1) {
                for (String m : h.members) {
                    ServerPlayer p = Players.online(m);
                    if (p != null) p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 20 * 40, 0));
                }
            }
        }
        for (House h : dead) {
            Players.broadcast("§8☠ Очаг Дома " + h.name + " угас, Сердце раскололось. Дом прекратил существование.");
            HouseService.destroy(h);
        }
    }

    private static void hour(House h) {
        boolean starving = !h.heartPlaced;
        for (Map.Entry<String, Double> n : needPerHour(h).entrySet()) {
            if (n.getValue() <= 0) continue;
            double stock = h.upkeep.getOrDefault(n.getKey(), 0.0);
            if (stock >= n.getValue()) h.upkeep.put(n.getKey(), stock - n.getValue());
            else {
                h.upkeep.put(n.getKey(), 0.0);
                starving = true;
            }
        }
        int before = h.hungerStage();
        h.hungryHours = starving ? h.hungryHours + 1 : 0;
        if (h.hungerStage() > before) {
            Players.messageHouse(h, "§c🔥 Очаг Дома слабеет! Стадия голода: " + h.hungerStage() + ". Пополните запасы.");
        }
        Prevail.markDirty();
    }

    /** Очаг сломан: Сердце выпадает, Дом начинает голодать. */
    public static void onHearthBroken(String blockKey, ServerPlayer breaker) {
        for (House h : Prevail.data().houses.values()) {
            if (!blockKey.equals(h.hearth)) continue;
            h.hearth = null;
            if (h.heartPlaced) {
                h.heartPlaced = false;
                ItemStack heart = HouseService.makeHeart(h);
                if (!breaker.getInventory().add(heart)) breaker.drop(heart, false);
                Players.messageHouse(h, "§4⚠ Родовой очаг разрушен! Сердце Дома у " + breaker.getName().getString() + ".");
            }
        }
    }
}

package ru.prevailcraft.prevail.profession;

import java.util.ArrayList;
import java.util.List;

/** Ветки специализации. Выбор ветки — полноценное ограничение, а не только бонус. */
public enum Branch {
    VEIN(Profession.MINER, "Жильщик", "металлы и самоцветы; камнелом из руды получит пустую породу"),
    STONE(Profession.MINER, "Камнелом", "камень, сланец, глина — двойная добыча"),
    FORESTER(Profession.LUMBERJACK, "Лесничий", "двойная добыча брёвен"),
    COLLIER(Profession.LUMBERJACK, "Смолокур", "древесный уголь, двойной выход"),
    GRAIN(Profession.FARMER, "Хлебороб", "пшеница и хлеб"),
    GARDENER(Profession.FARMER, "Садовод-пасечник", "овощи, ягоды, мёд"),
    SHEPHERD(Profession.HERDER, "Пастух", "двойная шерсть и мясо"),
    HORSEMASTER(Profession.HERDER, "Коневод", "разведение коней"),
    WEAPONSMITH(Profession.SMITH, "Оружейник", "качественное оружие; броня у него грубая"),
    ARMORER(Profession.SMITH, "Бронник", "качественная броня; оружие у него грубое"),
    SHIPWRIGHT(Profession.CARPENTER, "Корабел", "лодки и корабли"),
    SIEGE(Profession.CARPENTER, "Осадный мастер", "тараны и осадные машины (следующий этап)"),
    TAILOR(Profession.WEAVER, "Портной", "одежда и кожаная броня"),
    BANNERMAKER(Profession.WEAVER, "Знаменщик", "знамёна Домов");

    public final Profession profession;
    public final String title;
    public final String perk;

    Branch(Profession profession, String title, String perk) {
        this.profession = profession;
        this.title = title;
        this.perk = perk;
    }

    public static List<Branch> of(Profession p) {
        List<Branch> l = new ArrayList<>();
        for (Branch b : values()) if (b.profession == p) l.add(b);
        return l;
    }
}

package ru.prevailcraft.prevail.world;

import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 10 эпох мира. Переход требует платиновых монет И вклада ремёсел —
 * развитие мира движет вся экономика, а не только богачи.
 */
public enum Epoch {
    FOUNDATION(1, "Основание", "Дома, рынок, базовые ремёсла"),
    TRADE(2, "Торговля", "лицензионные профессии"),
    STEEL(3, "Сталь", "ковка стали на кузнечной наковальне"),
    GUILDS(4, "Гильдии", "ранг гроссмейстера"),
    FLAME(5, "Пламя", "открывается Незер"),
    CHIVALRY(6, "Рыцарство", "больше мест для рыцарей и крепостных"),
    MAGIC(7, "Магия", "лицензия Чародея (Iron's Spells)"),
    DRAGONS(8, "Драконы", "драконы (следующий этап разработки)"),
    END(9, "Край", "открывается Энд"),
    LEGEND(10, "Легенда", "мир достиг вершины — но игра продолжается");

    public final int number;
    public final String title;
    public final String unlocks;

    Epoch(int number, String title, String unlocks) {
        this.number = number;
        this.title = title;
        this.unlocks = unlocks;
    }

    public static Epoch of(int n) {
        for (Epoch e : values()) if (e.number == n) return e;
        return LEGEND;
    }

    public static int current() {
        return Prevail.data().kingdom.epoch;
    }

    public static void require(int n, String what) {
        if (current() < n) throw new PrevailException(what + " откроется в эпоху «" + of(n).title + "» (сейчас — «" + of(current()).title + "»).");
    }

    /** Что нужно внести в Фонд, чтобы перейти В эту эпоху. */
    public Map<String, Long> requirements() {
        Map<String, Long> m = new LinkedHashMap<>();
        switch (this) {
            case TRADE -> { m.put("prevail:platinum_coin", 2L); m.put("minecraft:bread", 128L); m.put("minecraft:oak_log", 256L); }
            case STEEL -> { m.put("prevail:platinum_coin", 4L); m.put("minecraft:iron_ingot", 256L); m.put("minecraft:coal", 256L); }
            case GUILDS -> { m.put("prevail:platinum_coin", 6L); m.put("prevail:steel_ingot", 64L); m.put("minecraft:white_wool", 128L); }
            case FLAME -> { m.put("prevail:platinum_coin", 10L); m.put("prevail:steel_ingot", 128L); m.put("minecraft:obsidian", 64L); }
            case CHIVALRY -> { m.put("prevail:platinum_coin", 14L); m.put("minecraft:leather", 256L); m.put("minecraft:gold_ingot", 128L); }
            case MAGIC -> { m.put("prevail:platinum_coin", 18L); m.put("minecraft:lapis_lazuli", 256L); m.put("minecraft:amethyst_shard", 128L); }
            case DRAGONS -> { m.put("prevail:platinum_coin", 24L); m.put("minecraft:diamond", 64L); m.put("prevail:steel_ingot", 256L); }
            case END -> { m.put("prevail:platinum_coin", 32L); m.put("minecraft:ender_pearl", 64L); m.put("minecraft:blaze_rod", 64L); }
            case LEGEND -> { m.put("prevail:platinum_coin", 50L); m.put("minecraft:netherite_ingot", 8L); m.put("minecraft:nether_star", 1L); }
            default -> { }
        }
        return m;
    }
}

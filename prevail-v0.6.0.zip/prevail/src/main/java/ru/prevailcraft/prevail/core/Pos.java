package ru.prevailcraft.prevail.core;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import ru.prevailcraft.prevail.compat.VersionCompat;

/** Позиция в мире, удобная для JSON. */
public final class Pos {
    public String dim;
    public double x, y, z;

    public Pos() {}

    public static Pos of(ServerPlayer p) {
        Pos q = new Pos();
        q.dim = VersionCompat.dimId(p.level());
        q.x = p.getX();
        q.y = p.getY();
        q.z = p.getZ();
        return q;
    }

    public static Pos of(Level level, BlockPos b) {
        Pos q = new Pos();
        q.dim = VersionCompat.dimId(level);
        q.x = b.getX() + 0.5;
        q.y = b.getY() + 1;
        q.z = b.getZ() + 0.5;
        return q;
    }

    /** Ключ блока "dim|x|y|z". */
    public static String blockKey(Level level, BlockPos b) {
        return VersionCompat.dimId(level) + "|" + b.getX() + "|" + b.getY() + "|" + b.getZ();
    }

    public static Pos fromBlockKey(String key) {
        String[] p = key.split("\\|");
        Pos q = new Pos();
        q.dim = p[0];
        q.x = Integer.parseInt(p[1]) + 0.5;
        q.y = Integer.parseInt(p[2]) + 1;
        q.z = Integer.parseInt(p[3]) + 0.5;
        return q;
    }

    public boolean near(ServerPlayer p, double dist) {
        return dim.equals(VersionCompat.dimId(p.level())) && p.distanceToSqr(x, y, z) <= dist * dist;
    }

    public String pretty() {
        return (int) Math.floor(x) + " " + (int) Math.floor(y) + " " + (int) Math.floor(z);
    }
}

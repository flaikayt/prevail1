package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.prevailcraft.prevail.client.PrevailClient;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.profession.Branch;
import ru.prevailcraft.prevail.profession.Profession;

import java.util.Map;

/** Карточка ремесла: иконка, название, 5 рангов, описание, кнопки «Выбрать» / ветки / «Отказаться». */
public class ProfessionDetailScreen extends Screen {
    private static final int W = 230, H = 178;

    private final ProfessionScreen parent;
    private final Profession p;
    private Map<String, String> d;
    private int left, top;

    public ProfessionDetailScreen(ProfessionScreen parent, Profession p, Map<String, String> d) {
        super(Component.literal(p.title));
        this.parent = parent;
        this.p = p;
        this.d = d;
    }

    public void update(Map<String, String> d) {
        this.d = d;
        parent.update(d);
        rebuildWidgets();
    }

    private Profession main() {
        return ProfessionScreen.prof(d.get("prof"));
    }

    private Profession lic() {
        return ProfessionScreen.prof(d.get("lic"));
    }

    private int rank() {
        if (p == main()) return ProfessionScreen.num(d, "rank");
        if (p == lic()) return ProfessionScreen.num(d, "lrank");
        return 0;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        addRenderableWidget(Button.builder(Component.literal("<<"), b -> onClose()).bounds(left - 26, top, 22, 20).build());

        int by = top + H - 26;
        if (!p.licensed) {
            if (p != main()) {
                Button choose = Button.builder(Component.literal("Выбрать ремесло"), b -> PrevailClient.send("prof_choose", p.name()))
                        .bounds(left + 10, by, 110, 20).build();
                choose.active = ProfessionScreen.num(d, "cd") == 0;
                addRenderableWidget(choose);
            } else if (rank() >= 2 && d.getOrDefault("branch", "").isEmpty()) {
                int x = left + 10;
                for (Branch br : Branch.of(p)) {
                    addRenderableWidget(Button.builder(Component.literal(br.title), b -> PrevailClient.send("prof_branch", br.name()))
                            .bounds(x, by, 102, 20).build());
                    x += 106;
                }
            }
        } else if (p == lic()) {
            addRenderableWidget(Button.builder(Component.literal("Отказаться"), b -> PrevailClient.send("prof_drop_license", ""))
                    .bounds(left + 10, by, 90, 20).build());
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        Ui.panel(g, left, top, W, H, 0xFF2B2B2B);
        Ui.fill(g, left + 8, top + 8, left + 60, top + 60, 0xFF1A1A1A);
        Ui.outline(g, left + 8, top + 8, 52, 52, 0xFF6A6A6A);
        Ui.bigItem(g, p.icon, left + 10, top + 10, 3f);

        Ui.text(g, p.title.toUpperCase(), left + 70, top + 12, Ui.WHITE, true);
        Ui.text(g, p.licensed ? "Дополнительная лицензия" : "Основное ремесло", left + 70, top + 24, 0xFFAAAAAA, false);
        Ui.rankNodes(g, left + 70, top + 40, rank(), 28);
        if (rank() > 0) Ui.text(g, ProfessionScreen.RANKS[rank() - 1], left + 70, top + 50, Ui.GREEN, false);

        Ui.fill(g, left + 8, top + 66, left + W - 8, top + H - 32, 0xFF1A1A1A);
        int y = top + 72;
        for (String line : p.description) {
            Ui.text(g, line, left + 14, y, Ui.WHITE, false);
            y += 11;
        }
        if (!p.quote.isEmpty()) Ui.text(g, p.quote, left + 14, y + 4, 0xFF888888, false);

        String status;
        if (!p.licensed) {
            if (p == main()) {
                String br = d.getOrDefault("branch", "");
                status = br.isEmpty() ? (rank() >= 2 ? "Выберите ветку:" : "Ветка откроется на ранге «Подмастерье»")
                        : "Ветка: " + Branch.valueOf(br).title;
            } else {
                int cd = ProfessionScreen.num(d, "cd");
                status = cd > 0 ? "Сменить ремесло можно через " + cd + " ч." : "Опыт прежнего ремесла сгорит";
            }
        } else {
            status = p == lic() ? "Ваша лицензия" : "Лицензию выдаёт канцлер (со 2-й эпохи)";
        }
        Ui.text(g, status, left + 10, top + H - 40, 0xFFCCCCCC, false);
        super.extractRenderState(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        Ui.open(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

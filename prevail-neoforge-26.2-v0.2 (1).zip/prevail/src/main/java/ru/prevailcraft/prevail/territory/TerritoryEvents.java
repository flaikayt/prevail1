package ru.prevailcraft.prevail.territory;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.law.PrisonService;

/** Защита столицы, ограничения заключённых и подозрительность на чужих землях. */
public final class TerritoryEvents {

    @SubscribeEvent
    public void onBreak(BlockEvent.BreakEvent e) {
        if (!Prevail.running() || !(e.getPlayer() instanceof ServerPlayer p)) return;
        if (PrisonService.isImprisoned(p)) {
            if (!PrisonService.hardLabour(p, e.getState(), e.getPos())) {
                e.setCanceled(true);
                p.sendSystemMessage(Component.literal("§cВ заключении можно только долбить камень в каменоломне."), true);
            }
            return;
        }
        if (CapitalService.inCapital(p.level(), e.getPos()) && !CapitalService.mayBuild(p, p.level(), e.getPos())) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cСтража столицы не позволяет ломать здесь."), true);
            return;
        }
        SuspicionService.onAction(p, e.getPos(), 2.0, "ломает постройки");
    }

    @SubscribeEvent
    public void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (PrisonService.isImprisoned(p)) {
            e.setCanceled(true);
            return;
        }
        if (CapitalService.inCapital(p.level(), e.getPos()) && !CapitalService.mayBuild(p, p.level(), e.getPos())) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cСтроить в столице можно на своём участке или в бригаде архитектора."), true);
            return;
        }
        SuspicionService.onAction(p, e.getPos(), 1.0, "строит");
    }

    @SubscribeEvent
    public void onOpen(PlayerInteractEvent.RightClickBlock e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        BlockEntity be = e.getLevel().getBlockEntity(e.getPos());
        if (be instanceof Container) SuspicionService.onAction(p, e.getPos(), 3.0, "открывает хранилища");
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (e.getTarget() instanceof Animal) SuspicionService.onAction(p, e.getTarget().blockPosition(), 1.5, "бьёт скот");
    }
}

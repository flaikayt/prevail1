package ru.prevailcraft.prevail.law;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.registry.ModItems;

/** Кандалы (арест), отмычка (побег), награда за врагов короны. */
public final class LawEvents {

    @SubscribeEvent
    public void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (!Prevail.running() || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getEntity() instanceof ServerPlayer captor) || !(e.getTarget() instanceof ServerPlayer target)) return;
        if (!e.getItemStack().is(ModItems.SHACKLES.get())) return;
        e.setCanceled(true);
        try {
            String msg = PrisonService.arrest(captor, target);
            if (msg != null) captor.sendSystemMessage(Component.literal(msg));
        } catch (PrevailException ex) {
            captor.sendSystemMessage(Component.literal("§c" + ex.getMessage()));
        }
    }

    @SubscribeEvent
    public void onUseItem(PlayerInteractEvent.RightClickItem e) {
        if (!Prevail.running() || e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (e.getItemStack().is(ModItems.LOCKPICK.get()) && PrisonService.isImprisoned(p)) {
            e.setCanceled(true);
            PrisonService.tryLockpick(p, e.getItemStack());
        }
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (!Prevail.running()) return;
        if (e.getEntity() instanceof ServerPlayer victim && e.getSource().getEntity() instanceof ServerPlayer killer) {
            CourtService.onKill(killer, victim);
        }
    }
}

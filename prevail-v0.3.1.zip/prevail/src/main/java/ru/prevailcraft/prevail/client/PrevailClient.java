package ru.prevailcraft.prevail.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.network.event.RegisterClientPayloadHandlersEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;
import ru.prevailcraft.prevail.PrevailMod;
import ru.prevailcraft.prevail.client.screen.BuyerScreen;
import ru.prevailcraft.prevail.network.ActionPayload;
import ru.prevailcraft.prevail.network.OpenScreenPayload;
import ru.prevailcraft.prevail.registry.ModMenus;

/**
 * Клиентская часть мода (на сервере не загружается):
 * экраны, клавиша P (окно ремёсел), приём пакетов «открыть экран».
 */
@Mod(value = PrevailMod.MODID, dist = Dist.CLIENT)
public final class PrevailClient {
    public static final KeyMapping PROFESSIONS_KEY = new KeyMapping(
            "key.prevail.professions", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_P, KeyMapping.Category.MISC);

    public PrevailClient(IEventBus modBus, ModContainer container) {
        modBus.addListener(RegisterKeyMappingsEvent.class, e -> e.register(PROFESSIONS_KEY));
        modBus.addListener(RegisterMenuScreensEvent.class, e -> e.register(ModMenus.BUYER.get(), BuyerScreen::new));
        modBus.addListener(RegisterClientPayloadHandlersEvent.class,
                e -> e.register(OpenScreenPayload.TYPE, ClientHandler::onOpenScreen));
        NeoForge.EVENT_BUS.addListener(ClientTickEvent.Post.class, e -> {
            while (PROFESSIONS_KEY.consumeClick()) {
                if (Minecraft.getInstance().player != null && Ui.current() == null) {
                    send("prof_request", "");
                }
            }
        });
    }

    public static void send(String action, String data) {
        ClientPacketDistributor.sendToServer(new ActionPayload(action, data));
    }
}

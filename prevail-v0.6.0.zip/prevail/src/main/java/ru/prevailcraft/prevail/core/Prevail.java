package ru.prevailcraft.prevail.core;

import net.minecraft.server.MinecraftServer;

/** Глобальный доступ к серверу и данным мода (живёт, пока запущен сервер). */
public final class Prevail {
    private static MinecraftServer server;
    private static DataStore store;

    private Prevail() {}

    public static void start(MinecraftServer s) {
        server = s;
        store = DataStore.load(s);
    }

    public static void stop() {
        if (store != null) store.save();
        store = null;
        server = null;
    }

    public static boolean running() {
        return store != null;
    }

    public static MinecraftServer server() {
        return server;
    }

    public static PrevailData data() {
        if (store == null) throw new PrevailException("Сервер ещё не готов.");
        return store.data();
    }

    public static DataStore store() {
        return store;
    }

    public static void markDirty() {
        if (store != null) store.markDirty();
    }
}

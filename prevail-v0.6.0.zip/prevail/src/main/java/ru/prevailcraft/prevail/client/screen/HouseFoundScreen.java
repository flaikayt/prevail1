package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.prevailcraft.prevail.client.PrevailClient;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.core.HouseColors;
import ru.prevailcraft.prevail.economy.Money;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Окно «Основать Дом»: название, цвет (10 штук), превью знамени, кнопка «Создать» с ценой. */
public class HouseFoundScreen extends Screen {
    private static final int W = 200, H = 156;

    private final int slot;
    private final long price;
    private final Set<Integer> taken = new HashSet<>();
    private int color;
    private EditBox name;
    private final List<Button> colorButtons = new ArrayList<>();
    private int left, top;

    public HouseFoundScreen(Map<String, String> d) {
        super(Component.literal("Основать Дом"));
        this.slot = Integer.parseInt(d.getOrDefault("slot", "0"));
        this.price = Long.parseLong(d.getOrDefault("price", "0"));
        for (String t : Ui.split(d.getOrDefault("taken", ""), ',')) {
            if (!t.isBlank()) taken.add(Integer.parseInt(t.trim()));
        }
        color = 0;
        while (color < HouseColors.IDS.length - 1 && taken.contains(color)) color++;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        String old = name == null ? "" : name.getValue();
        name = new EditBox(font, left + 10, top + 30, W - 20, 16, Component.literal("Название Дома"));
        name.setMaxLength(24);
        name.setValue(old);
        addRenderableWidget(name);
        setFocused(name);

        colorButtons.clear();
        for (int i = 0; i < HouseColors.IDS.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.empty(), btn -> color = idx)
                    .bounds(left + 10 + (i % 5) * 22, top + 58 + (i / 5) * 22, 20, 20).build();
            b.active = !taken.contains(i);
            colorButtons.add(b);
            addRenderableWidget(b);
        }
        addRenderableWidget(Button.builder(Component.literal("Создать"), b -> create())
                .bounds(left + W - 78, top + H - 40, 68, 20).build());
    }

    private void create() {
        String n = name.getValue().trim();
        if (n.length() < 3) return;
        PrevailClient.send("create_house", slot + "|" + color + "|" + n);
        onClose();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        Ui.panel(g, left, top, W, H, Ui.GREY);
        Ui.text(g, "Основать Дом", left + 10, top + 8, Ui.TEXT, false);
        Ui.text(g, "Название и цвет Дома:", left + 10, top + 19, Ui.GREY_DARK, false);
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        for (int i = 0; i < colorButtons.size(); i++) {
            Button b = colorButtons.get(i);
            int rgb = 0xFF000000 | HouseColors.RGB[i];
            Ui.fill(g, b.getX() + 3, b.getY() + 3, b.getX() + 17, b.getY() + 17, taken.contains(i) ? 0xFF444444 : rgb);
            if (i == color) Ui.outline(g, b.getX() - 1, b.getY() - 1, 22, 22, Ui.GOLD);
        }

        // Превью знамени Дома
        int px = left + 132, py = top + 56;
        Ui.fill(g, px + 22, py, px + 25, py + 50, 0xFF5A3D1E);
        Ui.fill(g, px + 6, py + 2, px + 41, py + 4, 0xFF5A3D1E);
        Ui.fill(g, px + 8, py + 4, px + 39, py + 38, 0xFF000000 | HouseColors.RGB[color]);
        String n = name == null ? "" : name.getValue().trim();
        if (!n.isEmpty()) Ui.centered(g, n.substring(0, 1).toUpperCase(), px + 24, py + 16, Ui.WHITE);
        Ui.centered(g, HouseColors.NAMES[color], px + 24, py + 52, Ui.TEXT);

        // Цена
        Ui.item(g, "prevail:copper_coin", left + 10, top + H - 38);
        Ui.text(g, Money.fmt(price), left + 30, top + H - 34, Ui.TEXT, false);
        if (n.length() < 3) Ui.text(g, "Название: от 3 символов", left + 10, top + H - 16, Ui.RED, false);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

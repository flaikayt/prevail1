package ru.prevailcraft.prevail.registry;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.prevailcraft.prevail.PrevailMod;

/** Все предметы мода. Логика предметов — в сервисах через события (без своих классов Item). */
public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(PrevailMod.MODID);

    // Деньги: 1 платиновая = 10 золотых = 100 серебряных = 1000 медных
    public static final DeferredItem<Item> COPPER_COIN = ITEMS.registerSimpleItem("copper_coin");
    public static final DeferredItem<Item> SILVER_COIN = ITEMS.registerSimpleItem("silver_coin");
    public static final DeferredItem<Item> GOLD_COIN = ITEMS.registerSimpleItem("gold_coin");
    public static final DeferredItem<Item> PLATINUM_COIN = ITEMS.registerSimpleItem("platinum_coin");
    public static final DeferredItem<Item> POWER_COIN = ITEMS.registerSimpleItem("power_coin");
    public static final DeferredItem<Item> WALLET = single("wallet");

    // Мир и Дом
    public static final DeferredItem<Item> ESSENCE = ITEMS.registerSimpleItem("essence");
    public static final DeferredItem<Item> HOUSE_CHARTER = single("house_charter");
    public static final DeferredItem<Item> HOUSE_HEART = single("house_heart");

    // Регалии двора
    public static final DeferredItem<Item> REGALIA_HAND = single("regalia_hand");
    public static final DeferredItem<Item> REGALIA_MARSHAL = single("regalia_marshal");
    public static final DeferredItem<Item> REGALIA_TREASURER = single("regalia_treasurer");
    public static final DeferredItem<Item> REGALIA_CHANCELLOR = single("regalia_chancellor");
    public static final DeferredItem<Item> REGALIA_ARCHITECT = single("regalia_architect");

    // Закон
    public static final DeferredItem<Item> SHACKLES = single("shackles");
    public static final DeferredItem<Item> LOCKPICK = ITEMS.registerSimpleItem("lockpick");
    /** Медный ключ: переименуйте на наковальне так, чтобы в имени был «#код». */
    public static final DeferredItem<Item> KEY = ITEMS.registerSimpleItem("key");
    /** Связка ключей: до 8 ключей, все они «при себе». */
    public static final DeferredItem<Item> KEYRING = single("keyring");


    private ModItems() {}

    /** Предмет, который не складывается в стопку. */
    private static DeferredItem<Item> single(String name) {
        return ITEMS.registerSimpleItem(name, p -> p.stacksTo(1));
    }

    public static void register(IEventBus modBus) {
        ITEMS.register(modBus);
        modBus.addListener(ModItems::addToTabs);
    }

    private static void addToTabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            for (var i : new DeferredItem<?>[]{COPPER_COIN, SILVER_COIN, GOLD_COIN, PLATINUM_COIN, POWER_COIN,
                    ESSENCE}) e.accept(i);
        }
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            for (var i : new DeferredItem<?>[]{WALLET, HOUSE_CHARTER, SHACKLES, LOCKPICK, KEY, KEYRING}) e.accept(i);
        }
        if (e.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            for (var b : ModBlocks.ALL) e.accept(b);
            e.accept(ModBlocks.SAFE);
        }
    }
}

package ru.prevailcraft.prevail.profession;

import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.world.Epoch;

/** Умения: до двух на игрока, 3 уровня, опыт от соответствующих действий. */
public final class AbilityService {
    private AbilityService() {}

    public static boolean has(PlayerProfile p, Ability a) {
        return p.abilities.containsKey(a.name());
    }

    /** 0 — умения нет, иначе 1..3. */
    public static int level(PlayerProfile p, Ability a) {
        Long xp = p.abilities.get(a.name());
        return xp == null ? 0 : Ability.levelFor(xp);
    }

    public static void addXp(PlayerProfile p, Ability a, long xp) {
        Long cur = p.abilities.get(a.name());
        if (cur == null || xp <= 0) return;
        int before = Ability.levelFor(cur);
        p.abilities.put(a.name(), cur + xp);
        int after = Ability.levelFor(cur + xp);
        if (after > before) Players.message(p.uuid, "§a⬆ Умение «" + a.title + "»: уровень " + ProfessionService.roman(after) + " — " + a.levels[after - 1]);
        Prevail.markDirty();
    }

    public static String take(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        Ability a = Ability.valueOf(name);
        if (has(p, a)) throw new PrevailException("Это умение уже у вас.");
        if (p.abilities.size() >= Ability.MAX_ABILITIES) throw new PrevailException("Можно иметь не больше двух умений — откажитесь от одного.");
        if (a == Ability.SORCERER) Epoch.require(7, "Умение «Чародей»");
        p.abilities.put(a.name(), 0L);
        apply(sp);
        return "§aНовое умение: " + a.title + " — " + a.levels[0];
    }

    public static String drop(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        Ability a = Ability.valueOf(name);
        if (p.abilities.remove(a.name()) == null) throw new PrevailException("У вас нет этого умения.");
        apply(sp);
        return "§7Вы отказались от умения «" + a.title + "». Его опыт сгорел.";
    }

    private static void modifier(ServerPlayer sp, Holder<Attribute> attr, String id, double value, boolean multiply) {
        if (value <= 0) VersionCompat.removeModifier(sp, attr, id);
        else VersionCompat.addTempModifier(sp, attr, id, value, multiply);
    }

    /** Постоянные бонусы умений (скорость, броня) — пересчитываются раз в 30 с и при изменении. */
    public static void apply(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        modifier(sp, Attributes.MOVEMENT_SPEED, "ability_runner", 0.05 * level(p, Ability.RUNNER), true);
        modifier(sp, Attributes.ARMOR, "ability_armored", level(p, Ability.ARMORED), false);
    }

    public static void tick() {
        for (ServerPlayer sp : Prevail.server().getPlayerList().getPlayers()) {
            PlayerProfile p = Players.profile(sp);
            apply(sp);
            if (sp.isSprinting()) addXp(p, Ability.RUNNER, 3);
            if (!sp.getItemBySlot(EquipmentSlot.CHEST).isEmpty()) addXp(p, Ability.ARMORED, 1);
        }
    }
}

package ru.prevailcraft.prevail.core;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import ru.prevailcraft.prevail.compat.VersionCompat;

/** Строковый ключ чанка: "измерение|x|z". */
public final class ChunkKey {
    private ChunkKey() {}

    public static String of(String dim, int cx, int cz) {
        return dim + "|" + cx + "|" + cz;
    }

    public static String of(Level level, BlockPos pos) {
        return of(VersionCompat.dimId(level), pos.getX() >> 4, pos.getZ() >> 4);
    }

    public static String of(ServerPlayer p) {
        return of(p.level(), p.blockPosition());
    }
}

package ru.prevailcraft.prevail.core;

/** 10 цветов Домов — порядок как в окне «Основать Дом». */
public final class HouseColors {
    public static final String[] IDS = {"yellow", "lime", "green", "cyan", "blue", "purple", "pink", "red", "orange", "black"};
    public static final String[] NAMES = {"Жёлтый", "Лаймовый", "Зелёный", "Бирюзовый", "Синий", "Фиолетовый", "Розовый", "Красный", "Оранжевый", "Чёрный"};
    public static final int[] RGB = {0xE8C41E, 0x7FCC19, 0x3D7A1E, 0x169C9C, 0x3C44AA, 0x8932B8, 0xF38BAA, 0xB02E26, 0xF9801D, 0x1D1D21};
    /** Код цвета для чата (§). */
    public static final String[] CHAT = {"§e", "§a", "§2", "§3", "§9", "§5", "§d", "§c", "§6", "§8"};

    private HouseColors() {}

    public static int clamp(int c) {
        return Math.max(0, Math.min(IDS.length - 1, c));
    }
}

package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.menu.FundMenu;

import java.util.HashMap;
import java.util.Map;

/** Фонд: эпоха, требования следующей эпохи с полосами, Исток, места для Домов, слот вклада. */
public class FundScreen extends AbstractContainerScreen<FundMenu> {
    public static Map<String, String> INFO = new HashMap<>();
    private static final int STONE = 0xFF3A3F4A, STONE_DARK = 0xFF262A32, GOLD = 0xFFE8C45A, AQUA = 0xFF7FD8F0;

    public FundScreen(FundMenu menu, Inventory inv, Component title) {
        super(menu, inv, title, 176, 222);
        this.inventoryLabelY = 129;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("Внести"), b -> {
            if (minecraft.gameMode != null) minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 0);
        }).bounds(leftPos + 100, topPos + FundMenu.SLOT_Y, 48, 18).build());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(g, mouseX, mouseY, partialTick);
        int x = leftPos, y = topPos;
        Ui.panel(g, x, y, imageWidth, imageHeight, STONE);
        Ui.fill(g, x + 6, y + 16, x + imageWidth - 6, y + 124, STONE_DARK);
        Ui.slot(g, x + FundMenu.SLOT_X - 1, y + FundMenu.SLOT_Y - 1);
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 139 + r * 18);
        for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 197);
    }

    @Override
    protected void extractLabels(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        Map<String, String> d = INFO;
        Ui.text(g, "Эпоха " + d.getOrDefault("epoch", "1") + "/10 · " + d.getOrDefault("title", ""), 8, 5, GOLD, true);
        String next = d.getOrDefault("next", "");
        int y = 20;
        if (next.isEmpty()) {
            Ui.text(g, "Мир достиг последней эпохи.", 10, y, Ui.WHITE, false);
        } else {
            Ui.text(g, "Далее: " + next, 10, y, Ui.WHITE, false);
            Ui.small(g, d.getOrDefault("nextUnlocks", ""), 88, y + 11, 0xFFB0B0B0, 0.7f);
            y += 24;
            for (String r : Ui.split(d.getOrDefault("req", ""), '/')) {
                String[] f = r.split(",");
                if (f.length != 3) continue;
                long have = Long.parseLong(f[1]), need = Long.parseLong(f[2]);
                Ui.item(g, new ItemStack(VersionCompat.item(f[0])), 10, y - 2);
                int bx = 30, bw = 100;
                Ui.fill(g, bx, y + 3, bx + bw, y + 9, 0xFF14161A);
                Ui.fill(g, bx + 1, y + 4, bx + 1 + (int) ((bw - 2) * Math.min(1.0, have / (double) need)), y + 8, have >= need ? 0xFF55CC55 : GOLD);
                Ui.text(g, have + "/" + need, bx + bw + 4, y + 2, Ui.WHITE, false);
                y += 18;
            }
        }
        // Исток и места
        int ess = Integer.parseInt(d.getOrDefault("essence", "0"));
        Ui.text(g, "Исток:", 10, 92, AQUA, false);
        for (int i = 0; i < 5; i++) {
            int bx = 46 + i * 9;
            Ui.fill(g, bx, 92, bx + 6, 100, i < ess ? AQUA : 0xFF14161A);
        }
        Ui.text(g, "Дома: " + d.getOrDefault("houses", "0") + "/" + d.getOrDefault("slots", "4"), 104, 92, Ui.WHITE, false);
        Ui.text(g, "Вклад:", 10, 110, 0xFFB0B0B0, false);
        Ui.small(g, "ПКМ бутылкой по Фонду — Исток", 60, 120, 0xFF8090A0, 0.6f);
        g.text(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, 0xFFE0E0E0, false);
    }
}

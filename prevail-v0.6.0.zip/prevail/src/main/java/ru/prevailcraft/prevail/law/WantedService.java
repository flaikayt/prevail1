package ru.prevailcraft.prevail.law;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.territory.SuspicionService;
import ru.prevailcraft.prevail.vassalage.HouseService;

/**
 * Королевский розыск: объявляют король, десница, маршал; действует везде,
 * ловить может любой охотник за головами.
 * Домовой розыск: объявляют лорд/рыцари, только если подозрительность цели
 * на их землях достигла порога; ловить могут только члены Дома.
 */
public final class WantedService {
    private WantedService() {}

    public static String declare(ServerPlayer sp, String targetName, String scopeStr, long bounty, String reason) {
        PlayerProfile p = Players.profile(sp);
        PlayerProfile t = Players.byName(targetName);
        if (t.uuid.equals(p.uuid)) throw new PrevailException("Нельзя объявить в розыск самого себя.");
        if (bounty < 0) throw new PrevailException("Награда не может быть отрицательной.");
        WantedEntry w = new WantedEntry();
        w.target = t.uuid;
        w.issuedBy = p.uuid;
        w.reason = reason;
        w.bounty = bounty;
        w.issuedAt = System.currentTimeMillis();

        if (scopeStr.equalsIgnoreCase("royal")) {
            if (!CourtService.has(p.uuid, CourtOffice.MARSHAL)) {
                throw new PrevailException("Королевский розыск объявляют король, десница и маршал (с регалией).");
            }
            if (CourtService.k().treasury < bounty) throw new PrevailException("В королевской казне не хватает на награду.");
            CourtService.k().treasury -= bounty;
            w.scope = WantedEntry.Scope.ROYAL;
            w.issuer = "crown";
        } else if (scopeStr.equalsIgnoreCase("house")) {
            House h = HouseService.requireOfficial(p);
            double s = SuspicionService.get(h.id, t.uuid);
            if (s < PrevailConfig.SUSPICION_THRESHOLD.get()) {
                throw new PrevailException("Недостаточно улик: подозрительность " + t.name + " — " + (int) s + "/" + (int) (double) PrevailConfig.SUSPICION_THRESHOLD.get() + ".");
            }
            if (h.treasury < bounty) throw new PrevailException("В казне Дома не хватает на награду.");
            h.treasury -= bounty;
            w.scope = WantedEntry.Scope.HOUSE;
            w.issuer = h.id;
        } else {
            throw new PrevailException("Тип розыска: royal или house.");
        }
        WantedEntry old = Prevail.data().wanted.put(w.key(), w);
        if (old != null) refund(old);
        String who = w.scope == WantedEntry.Scope.ROYAL ? "Корона" : "Дом " + Prevail.data().houses.get(w.issuer).name;
        Players.broadcast("§c📜 РОЗЫСК: " + who + " разыскивает " + t.name + " — «" + reason + "». Награда: " + Money.fmt(bounty));
        return null;
    }

    public static String revoke(ServerPlayer sp, String targetName, String scopeStr) {
        PlayerProfile p = Players.profile(sp);
        PlayerProfile t = Players.byName(targetName);
        String issuer;
        if (scopeStr.equalsIgnoreCase("royal")) {
            if (!CourtService.has(p.uuid, CourtOffice.MARSHAL)) throw new PrevailException("Нет полномочий.");
            issuer = "crown";
        } else {
            issuer = HouseService.requireOfficial(p).id;
        }
        WantedEntry w = Prevail.data().wanted.remove(WantedEntry.key(t.uuid, issuer));
        if (w == null) throw new PrevailException(t.name + " не в розыске.");
        refund(w);
        return "Розыск " + t.name + " снят, награда возвращена в казну.";
    }

    /** Автоматический королевский розыск (кража регалии, побег). */
    public static void autoRoyal(String target, String reason) {
        autoRoyal(target, reason, 0);
    }

    public static void autoRoyal(String target, String reason, long bounty) {
        WantedEntry w = new WantedEntry();
        w.target = target;
        w.scope = WantedEntry.Scope.ROYAL;
        w.issuer = "crown";
        w.issuedBy = "crown";
        w.reason = reason;
        long fromTreasury = Math.min(bounty, CourtService.k().treasury);
        CourtService.k().treasury -= fromTreasury;
        w.bounty = fromTreasury;
        w.issuedAt = System.currentTimeMillis();
        WantedEntry old = Prevail.data().wanted.put(w.key(), w);
        if (old != null) w.bounty += old.bounty;
        Players.broadcast("§c📜 КОРОЛЕВСКИЙ РОЗЫСК: " + Players.name(target) + " — «" + reason + "»" + (w.bounty > 0 ? ". Награда: " + Money.fmt(w.bounty) : "."));
        Prevail.markDirty();
    }

    public static void clearAll(String target) {
        Prevail.data().wanted.values().removeIf(w -> {
            if (w.target.equals(target)) {
                refund(w);
                return true;
            }
            return false;
        });
    }

    static void refund(WantedEntry w) {
        if (w.scope == WantedEntry.Scope.ROYAL) CourtService.k().treasury += w.bounty;
        else {
            House h = Prevail.data().houses.get(w.issuer);
            if (h != null) h.treasury += w.bounty;
        }
    }

    public static String list() {
        if (Prevail.data().wanted.isEmpty()) return "Розыскных листов нет.";
        StringBuilder sb = new StringBuilder("§c═══ Разыскиваются ═══");
        for (WantedEntry w : Prevail.data().wanted.values()) {
            String who = w.scope == WantedEntry.Scope.ROYAL ? "Корона" : Prevail.data().houses.containsKey(w.issuer) ? Prevail.data().houses.get(w.issuer).name : "?";
            sb.append("\n§f• ").append(Players.name(w.target)).append(" §7[").append(who).append("] «").append(w.reason)
                    .append("» — ").append(Money.fmt(w.bounty));
        }
        return sb.toString();
    }

    public static void onLogin(ServerPlayer sp) {
        String id = sp.getUUID().toString();
        for (WantedEntry w : Prevail.data().wanted.values()) {
            if (id.equals(w.target)) {
                sp.sendSystemMessage(Component.literal("§c⚠ Вы в розыске. Будьте осторожны."));
                return;
            }
        }
    }
}

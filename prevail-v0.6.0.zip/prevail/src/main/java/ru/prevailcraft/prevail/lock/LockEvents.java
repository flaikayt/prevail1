package ru.prevailcraft.prevail.lock;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.registry.ModBlocks;
import ru.prevailcraft.prevail.registry.ModItems;

/** Замки на сундуках/бочках/дверях/люках, сейфы, связка ключей. */
public final class LockEvents {

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onUse(PlayerInteractEvent.RightClickBlock e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        Level level = e.getLevel();
        BlockPos pos = e.getPos();
        BlockState st = level.getBlockState(pos);
        if (!LockService.lockable(st)) return;
        ItemStack hand = sp.getMainHandItem();
        try {
            String code = LockService.keyCode(hand);
            if (sp.isShiftKeyDown() && code != null) {
                e.setCanceled(true);
                if (e.getHand() == InteractionHand.MAIN_HAND) LockService.toggleLock(sp, level, st, pos, code);
                return;
            }
            LockInfo li = LockService.lockAt(level, st, pos);
            if (li == null) return;
            String key = LockService.lockKey(level, st, pos);
            if (LockService.hasKey(sp, li.code) || LockService.bypassed(sp, key)) return;
            e.setCanceled(true);
            if (e.getHand() != InteractionHand.MAIN_HAND) return;
            if (hand.is(ModItems.LOCKPICK.get())) {
                boolean door = st.getBlock() instanceof DoorBlock || st.getBlock() instanceof TrapDoorBlock;
                LockService.startPick(sp, key, door ? "door" : "chest", LockService.normalize(st, pos));
            } else {
                sp.sendSystemMessage(Component.literal("§cЗаперто. Нужен ключ или отмычка."), true);
            }
        } catch (PrevailException ex) {
            sp.sendSystemMessage(Component.literal("§c" + ex.getMessage()), true);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onBreak(BreakBlockEvent e) {
        if (!Prevail.running() || !(e.getPlayer() instanceof ServerPlayer sp)) return;
        Level level = sp.level();
        BlockPos pos = e.getPos();
        BlockState st = e.getState();
        if (st.is(ModBlocks.SAFE.get()) && level.getBlockEntity(pos) instanceof SafeBlockEntity be) {
            boolean admin = VersionCompat.isAdmin(sp) && sp.isCreative();
            boolean canOpen = (be.code.isEmpty() && be.isOwner(sp)) || LockService.hasKey(sp, be.code);
            if (!admin && (be.indestructible || !canOpen)) {
                e.setCanceled(true);
                sp.sendSystemMessage(Component.literal(be.indestructible ? "§cСейф нерушимый — его можно только взломать."
                        : "§cБез ключа сейф не сломать — только взломать."), true);
                return;
            }
            Containers.dropContents(level, pos, be);
            return;
        }
        if (!LockService.lockable(st)) return;
        LockInfo li = LockService.lockAt(level, st, pos);
        if (li == null) return;
        if (!LockService.hasKey(sp, li.code) && !(VersionCompat.isAdmin(sp) && sp.isCreative())) {
            e.setCanceled(true);
            sp.sendSystemMessage(Component.literal("§cНа этом стоит замок — сломать можно только с ключом."), true);
            return;
        }
        Prevail.data().locks.remove(LockService.lockKey(level, st, pos));
    }

    @SubscribeEvent
    public void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        if (e.getPlacedBlock().is(ModBlocks.SAFE.get()) && sp.level().getBlockEntity(e.getPos()) instanceof SafeBlockEntity be) {
            be.owner = sp.getUUID().toString();
            be.setChanged();
            sp.sendSystemMessage(Component.literal("§7Сейф ваш. Откройте его и задайте код ключа."), true);
        }
    }

    @SubscribeEvent
    public void onUseItem(PlayerInteractEvent.RightClickItem e) {
        if (!Prevail.running() || e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer sp)) return;
        if (e.getItemStack().is(ModItems.KEYRING.get())) {
            e.setCanceled(true);
            LockService.openKeyring(sp);
        }
    }
}

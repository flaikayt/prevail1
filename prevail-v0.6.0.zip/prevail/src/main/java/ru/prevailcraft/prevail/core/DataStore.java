package ru.prevailcraft.prevail.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import ru.prevailcraft.prevail.PrevailMod;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Хранение в JSON внутри папки мира. Выбрано вместо SavedData,
 * потому что не зависит от меняющегося между версиями API ванилы,
 * а файл удобно читать и править руками.
 */
public final class DataStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private final Path file;
    private final PrevailData data;
    private boolean dirty;

    private DataStore(Path file, PrevailData data) {
        this.file = file;
        this.data = data;
    }

    public static DataStore load(MinecraftServer server) {
        Path file = server.getWorldPath(LevelResource.ROOT).resolve("prevail").resolve("data.json");
        PrevailData data = null;
        if (Files.exists(file)) {
            try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                data = GSON.fromJson(r, PrevailData.class);
            } catch (Exception e) {
                PrevailMod.LOG.error("Prevail: не удалось прочитать {}, делаю резервную копию", file, e);
                try {
                    Files.copy(file, file.resolveSibling("data.broken-" + System.currentTimeMillis() + ".json"));
                } catch (Exception ignored) {
                }
            }
        }
        if (data == null) data = new PrevailData();
        data.ensureDefaults();
        return new DataStore(file, data);
    }

    public PrevailData data() {
        return data;
    }

    public void markDirty() {
        dirty = true;
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    public void save() {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling("data.json.tmp");
            try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                GSON.toJson(data, w);
            }
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            dirty = false;
        } catch (Exception e) {
            PrevailMod.LOG.error("Prevail: ошибка сохранения", e);
        }
    }
}

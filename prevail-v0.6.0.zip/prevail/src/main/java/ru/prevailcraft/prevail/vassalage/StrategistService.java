package ru.prevailcraft.prevail.vassalage;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Items;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Rank;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.court.Legitimacy;
import ru.prevailcraft.prevail.economy.PowerCoins;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.ui.ChestGui;
import ru.prevailcraft.prevail.ui.Icons;

/**
 * Стол стратега — политический центр игрока.
 * Раз в 20 часов: 1 монета власти за себя + по 1 за каждого прямого вассала,
 * заходившего в игру за последние 48 часов (крепостной → рыцарь → лорд,
 * а у лорда — ещё и лорды вассальных Домов).
 */
public final class StrategistService {
    private static final long COOLDOWN = 20 * 3_600_000L, ACTIVE = 48 * 3_600_000L;

    private StrategistService() {}

    public static int activeVassals(PlayerProfile p) {
        long now = System.currentTimeMillis();
        int n = 0;
        for (PlayerProfile o : Prevail.data().players.values()) {
            if (p.uuid.equals(o.liege) && now - o.lastSeen <= ACTIVE) n++;
        }
        House h = Players.house(p);
        if (h != null && p.uuid.equals(h.lord)) {
            for (House v : Prevail.data().houses.values()) {
                PlayerProfile vl = Players.profile(v.lord);
                if (h.id.equals(v.suzerain) && vl != null && now - vl.lastSeen <= ACTIVE) n++;
            }
        }
        return n;
    }

    public static void claim(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        long left = p.lastStrategistClaim + COOLDOWN - System.currentTimeMillis();
        if (left > 0) throw new PrevailException("Следующий сбор через " + (left / 3_600_000L + 1) + " ч.");
        int coins = 1 + activeVassals(p);
        p.lastStrategistClaim = System.currentTimeMillis();
        PowerCoins.give(sp, coins);
        sp.sendSystemMessage(net.minecraft.network.chat.Component.literal("§6Получено монет власти: " + coins));
    }

    public static void open(ServerPlayer sp) {
        new ChestGui(3, "Стол стратега", gui -> {
            PlayerProfile p = Players.profile(sp);
            House h = Players.house(p);
            long left = Math.max(0, p.lastStrategistClaim + COOLDOWN - System.currentTimeMillis());
            gui.set(4, Icons.of(Items.FILLED_MAP, "§6" + p.name + " — " + p.rank.title,
                    "§7Дом: §f" + (h == null ? "—" : h.name),
                    "§7Сеньор: §f" + (p.liege == null ? "—" : Players.name(p.liege)),
                    "§7Активных вассалов: §f" + activeVassals(p),
                    "§7Монет власти при себе: §f" + PowerCoins.count(sp)), null);
            gui.set(11, Icons.of(ModItems.POWER_COIN.get(), left == 0 ? "§aСобрать монеты власти" : "§7Сбор через " + (left / 3_600_000L + 1) + " ч.",
                    "§7+" + (1 + activeVassals(p)) + " (вы + активные вассалы)"), (pl, r, s) -> claim(pl));
            gui.set(13, Icons.of(Items.GOLDEN_HELMET, "§eКорона: " + (CourtService.k().king == null ? "трон пуст" : Players.name(CourtService.k().king)),
                    "§7Легитимность: " + Icons.bar(Legitimacy.value() / 100) + " §f" + Legitimacy.describe(),
                    "§7Клик — пожертвовать короне 5 монет власти (+2.5%)"),
                    CourtService.k().king == null ? null : (pl, r, s) -> pl.sendSystemMessage(net.minecraft.network.chat.Component.literal(CourtService.donate(pl, 5))));
            if (p.rank == Rank.LORD && CourtService.k().king != null && !CourtService.isKing(p.uuid)) {
                boolean sw = CourtService.k().supporters.contains(p.uuid);
                gui.set(15, Icons.of(Items.SHIELD, sw ? "§cОтозвать присягу короне" : "§aПрисягнуть короне",
                        "§7Присяга лордов — основа легитимности короля"), (pl, r, s) -> pl.sendSystemMessage(net.minecraft.network.chat.Component.literal(CourtService.swear(pl))));
            }
            Icons.frame(gui);
        }).open(sp);
    }
}

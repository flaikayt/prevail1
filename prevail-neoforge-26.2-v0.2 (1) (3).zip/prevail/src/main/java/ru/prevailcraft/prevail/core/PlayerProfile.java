package ru.prevailcraft.prevail.core;

import ru.prevailcraft.prevail.profession.Branch;
import ru.prevailcraft.prevail.profession.Profession;

/** Всё, что мод знает об игроке. */
public final class PlayerProfile {
    public String uuid;
    public String name;
    public Rank rank = Rank.FREEMAN;
    public String houseId;
    /** uuid непосредственного сеньора. */
    public String liege;

    /** Основное ремесло и его ветка (выбирается на ранге «Подмастерье»). */
    public Profession profession = Profession.NONE;
    public Branch branch;
    public long professionXp;
    public long professionChangedAt;
    /** Занял ли место гроссмейстера (их число ограничено). */
    public boolean grandmaster;

    /** Лицензионная профессия (выдаёт канцлер). */
    public Profession license;
    public long licenseXp;

    public long lastSeen;
    public long lastStrategistClaim;
    public long lastPrisonGiftDay;
    public boolean regaliaThief;

    public PlayerProfile() {}

    public PlayerProfile(String uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }
}

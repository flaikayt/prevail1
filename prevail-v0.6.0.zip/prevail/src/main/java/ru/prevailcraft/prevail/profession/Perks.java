package ru.prevailcraft.prevail.profession;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Древа навыков всех ремёсел. Ствол — 3 общих навыка, затем развилка на ранге II
 * и две ветки по 3 навыка + капстоун (ранг V, место гроссмейстера).
 *
 * Ключи эффектов:
 *  xp — % к опыту ремесла; haste — ускорение работы (эффект «Спешка»);
 *  dbl_ore, dbl_gem, dbl_stone, dbl_log, dbl_charcoal, dbl_grain, dbl_veg, dbl_animal,
 *  dbl_boat, dbl_banner — % шанс двойной добычи/изделия;
 *  q_tool, q_weapon, q_armor, q_leather — % шанс поднять качество изделия на ступень;
 *  q_master — % шанс шедевра.
 */
public final class Perks {
    public static final Map<String, Perk> ALL = new LinkedHashMap<>();
    private static final int[] TRUNK_REQ = {1, 3, 6};
    private static final int[] BRANCH_REQ = {10, 15, 25, 50};
    private static final int[] BRANCH_COST = {1, 2, 2, 3};

    private Perks() {}

    private static void t(Profession p, int i, String name, String desc, String key, double per, int max) {
        Perk k = new Perk(p.name().toLowerCase() + "_t" + i, p, null, i, name, desc, key, per, max, 1, TRUNK_REQ[i]);
        ALL.put(k.id(), k);
    }

    private static void b(Branch br, int i, String name, String desc, String key, double per, int max) {
        Perk k = new Perk(br.name().toLowerCase() + "_" + i, br.profession, br, i, name, desc, key, per,
                i == 3 ? 1 : max, BRANCH_COST[i], BRANCH_REQ[i]);
        ALL.put(k.id(), k);
    }

    static {
        // ---------- Рудокоп ----------
        t(Profession.MINER, 0, "Крепкая хватка", "+{v}% опыта ремесла", "xp", 5, 3);
        t(Profession.MINER, 1, "Зоркий глаз", "+{v}% шанс двойной руды", "dbl_ore", 2, 3);
        t(Profession.MINER, 2, "Выносливость", "Спешка с киркой в руке", "haste", 1, 1);
        b(Branch.VEIN, 0, "Чутьё жилы", "+{v}% двойной руды", "dbl_ore", 3, 3);
        b(Branch.VEIN, 1, "Двойная добыча", "+{v}% двойной руды", "dbl_ore", 4, 3);
        b(Branch.VEIN, 2, "Самоцветы", "+{v}% двойных алмазов и изумрудов", "dbl_gem", 8, 3);
        b(Branch.VEIN, 3, "Сердце горы", "+{v}% двойной руды", "dbl_ore", 15, 1);
        b(Branch.STONE, 0, "Каменщик", "+{v}% двойного камня", "dbl_stone", 6, 3);
        b(Branch.STONE, 1, "Глина и сланец", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.STONE, 2, "Тяжёлая порода", "+{v}% двойного камня", "dbl_stone", 8, 3);
        b(Branch.STONE, 3, "Мастер карьера", "+{v}% двойного камня", "dbl_stone", 25, 1);
        // ---------- Лесоруб ----------
        t(Profession.LUMBERJACK, 0, "Твёрдая рука", "+{v}% опыта ремесла", "xp", 5, 3);
        t(Profession.LUMBERJACK, 1, "Глаз лесника", "+{v}% двойных брёвен", "dbl_log", 2, 3);
        t(Profession.LUMBERJACK, 2, "Без устали", "Спешка с топором в руке", "haste", 1, 1);
        b(Branch.FORESTER, 0, "Лесная тропа", "+{v}% двойных брёвен", "dbl_log", 3, 3);
        b(Branch.FORESTER, 1, "Знаток пород", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.FORESTER, 2, "Вековой дуб", "+{v}% двойных брёвен", "dbl_log", 5, 3);
        b(Branch.FORESTER, 3, "Хозяин леса", "+{v}% двойных брёвен", "dbl_log", 20, 1);
        b(Branch.COLLIER, 0, "Угольная яма", "+{v}% двойного угля при пережоге", "dbl_charcoal", 8, 3);
        b(Branch.COLLIER, 1, "Смола и дёготь", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.COLLIER, 2, "Ровный жар", "+{v}% двойного угля", "dbl_charcoal", 10, 3);
        b(Branch.COLLIER, 3, "Мастер пережога", "+{v}% двойного угля", "dbl_charcoal", 30, 1);
        // ---------- Земледелец ----------
        t(Profession.FARMER, 0, "Крестьянская сметка", "+{v}% опыта ремесла", "xp", 5, 3);
        t(Profession.FARMER, 1, "Добрая земля", "+{v}% двойного урожая", "dbl_grain", 2, 3);
        t(Profession.FARMER, 2, "Ранний подъём", "Спешка с мотыгой в руке", "haste", 1, 1);
        b(Branch.GRAIN, 0, "Колос к колосу", "+{v}% двойной пшеницы", "dbl_grain", 4, 3);
        b(Branch.GRAIN, 1, "Мельник", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.GRAIN, 2, "Тучные нивы", "+{v}% двойной пшеницы", "dbl_grain", 5, 3);
        b(Branch.GRAIN, 3, "Житница королевства", "+{v}% двойной пшеницы", "dbl_grain", 20, 1);
        b(Branch.GARDENER, 0, "Огородник", "+{v}% двойных овощей", "dbl_veg", 4, 3);
        b(Branch.GARDENER, 1, "Пасечник", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.GARDENER, 2, "Сад и ягодник", "+{v}% двойных овощей", "dbl_veg", 5, 3);
        b(Branch.GARDENER, 3, "Королевский сад", "+{v}% двойных овощей", "dbl_veg", 20, 1);
        // ---------- Скотовод ----------
        t(Profession.HERDER, 0, "Рука пастыря", "+{v}% опыта ремесла", "xp", 5, 3);
        t(Profession.HERDER, 1, "Сытый скот", "+{v}% двойной добычи со скота", "dbl_animal", 2, 3);
        t(Profession.HERDER, 2, "Плодовитость", "+{v}% опыта за разведение", "xp", 10, 1);
        b(Branch.SHEPHERD, 0, "Густая шерсть", "+{v}% двойной добычи", "dbl_animal", 4, 3);
        b(Branch.SHEPHERD, 1, "Отара", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.SHEPHERD, 2, "Мясник", "+{v}% двойной добычи", "dbl_animal", 5, 3);
        b(Branch.SHEPHERD, 3, "Король пастбищ", "+{v}% двойной добычи", "dbl_animal", 20, 1);
        b(Branch.HORSEMASTER, 0, "Объездчик", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.HORSEMASTER, 1, "Добрая кровь", "+{v}% двойной кожи и мяса", "dbl_animal", 4, 3);
        b(Branch.HORSEMASTER, 2, "Табунщик", "+{v}% опыта ремесла", "xp", 15, 3);
        b(Branch.HORSEMASTER, 3, "Конюший короля", "+{v}% двойной добычи", "dbl_animal", 20, 1);
        // ---------- Кузнец ----------
        t(Profession.SMITH, 0, "Горн и мехи", "+{v}% опыта ремесла", "xp", 5, 3);
        t(Profession.SMITH, 1, "Верный глаз", "+{v}% шанс лучшего инструмента", "q_tool", 10, 3);
        t(Profession.SMITH, 2, "Закалка", "+{v}% шанс шедевра", "q_master", 2, 1);
        b(Branch.WEAPONSMITH, 0, "Острая кромка", "+{v}% шанс лучшего оружия", "q_weapon", 10, 3);
        b(Branch.WEAPONSMITH, 1, "Баланс клинка", "+{v}% шанс лучшего оружия", "q_weapon", 10, 3);
        b(Branch.WEAPONSMITH, 2, "Клеймо мастера", "+{v}% шанс шедевра", "q_master", 3, 3);
        b(Branch.WEAPONSMITH, 3, "Меч королей", "+{v}% шанс шедевра", "q_master", 15, 1);
        b(Branch.ARMORER, 0, "Плотная клёпка", "+{v}% шанс лучшей брони", "q_armor", 10, 3);
        b(Branch.ARMORER, 1, "Кольчужник", "+{v}% шанс лучшей брони", "q_armor", 10, 3);
        b(Branch.ARMORER, 2, "Латы", "+{v}% шанс шедевра", "q_master", 3, 3);
        b(Branch.ARMORER, 3, "Доспех героя", "+{v}% шанс шедевра", "q_master", 15, 1);
        // ---------- Плотник ----------
        t(Profession.CARPENTER, 0, "Рубанок", "+{v}% опыта ремесла", "xp", 5, 3);
        t(Profession.CARPENTER, 1, "Сухая доска", "+{v}% шанс второй лодки", "dbl_boat", 5, 3);
        t(Profession.CARPENTER, 2, "Без устали", "Спешка с топором в руке", "haste", 1, 1);
        b(Branch.SHIPWRIGHT, 0, "Киль и борт", "+{v}% шанс второй лодки", "dbl_boat", 8, 3);
        b(Branch.SHIPWRIGHT, 1, "Верфь", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.SHIPWRIGHT, 2, "Мачта", "+{v}% шанс второй лодки", "dbl_boat", 10, 3);
        b(Branch.SHIPWRIGHT, 3, "Флот короны", "+{v}% шанс второй лодки", "dbl_boat", 30, 1);
        b(Branch.SIEGE, 0, "Чертежи", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.SIEGE, 1, "Таран", "осадные машины — в разработке (+{v}% опыта)", "xp", 10, 3);
        b(Branch.SIEGE, 2, "Требушет", "осадные машины — в разработке (+{v}% опыта)", "xp", 10, 3);
        b(Branch.SIEGE, 3, "Осадный мастер", "осадные машины — в разработке", "xp", 20, 1);
        // ---------- Ткач ----------
        t(Profession.WEAVER, 0, "Ловкие пальцы", "+{v}% опыта ремесла", "xp", 5, 3);
        t(Profession.WEAVER, 1, "Ровный шов", "+{v}% шанс лучшей кожаной брони", "q_leather", 10, 3);
        t(Profession.WEAVER, 2, "Краски", "+{v}% шанс второго знамени", "dbl_banner", 10, 1);
        b(Branch.TAILOR, 0, "Кройка", "+{v}% шанс лучшей кожаной брони", "q_leather", 10, 3);
        b(Branch.TAILOR, 1, "Дублёная кожа", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.TAILOR, 2, "Портной двора", "+{v}% шанс шедевра", "q_master", 4, 3);
        b(Branch.TAILOR, 3, "Наряд короля", "+{v}% шанс шедевра", "q_master", 20, 1);
        b(Branch.BANNERMAKER, 0, "Герольд", "+{v}% шанс второго знамени", "dbl_banner", 10, 3);
        b(Branch.BANNERMAKER, 1, "Геральдика", "+{v}% опыта ремесла", "xp", 10, 3);
        b(Branch.BANNERMAKER, 2, "Стяг полка", "+{v}% шанс второго знамени", "dbl_banner", 15, 3);
        b(Branch.BANNERMAKER, 3, "Знамя королевства", "+{v}% шанс второго знамени", "dbl_banner", 40, 1);
    }

    public static List<Perk> trunk(Profession p) {
        List<Perk> l = new ArrayList<>();
        for (Perk k : ALL.values()) if (k.prof() == p && k.branch() == null) l.add(k);
        return l;
    }

    public static List<Perk> branch(Branch b) {
        List<Perk> l = new ArrayList<>();
        for (Perk k : ALL.values()) if (k.branch() == b) l.add(k);
        return l;
    }
}

package ru.prevailcraft.prevail.core;

import ru.prevailcraft.prevail.economy.MarketEntry;
import ru.prevailcraft.prevail.law.PrisonTerm;
import ru.prevailcraft.prevail.law.WantedEntry;
import ru.prevailcraft.prevail.profession.AnvilWork;
import ru.prevailcraft.prevail.war.War;

import java.util.HashMap;
import java.util.Map;

/** Корневой объект сохранения (world/prevail/data.json). */
public final class PrevailData {
    public int version = 2;

    public Map<String, PlayerProfile> players = new HashMap<>();
    public Map<String, House> houses = new HashMap<>();
    public Kingdom kingdom = new Kingdom();

    public Map<String, War> wars = new HashMap<>();
    public Map<String, String> occupiedChunks = new HashMap<>();

    public Map<String, Map<String, Double>> suspicion = new HashMap<>();
    public Map<String, WantedEntry> wanted = new HashMap<>();
    public Map<String, PrisonTerm> prisoners = new HashMap<>();

    public Map<String, MarketEntry> market = new HashMap<>();
    public long lastTaxMillis;
    public long lastMarketDriftMillis;

    /** Заготовки на кузнечных наковальнях: ключ блока → работа. */
    public Map<String, AnvilWork> anvils = new HashMap<>();

    public void ensureDefaults() {
        if (players == null) players = new HashMap<>();
        if (houses == null) houses = new HashMap<>();
        if (kingdom == null) kingdom = new Kingdom();
        if (wars == null) wars = new HashMap<>();
        if (occupiedChunks == null) occupiedChunks = new HashMap<>();
        if (suspicion == null) suspicion = new HashMap<>();
        if (wanted == null) wanted = new HashMap<>();
        if (prisoners == null) prisoners = new HashMap<>();
        if (market == null) market = new HashMap<>();
        if (anvils == null) anvils = new HashMap<>();
        if (market.isEmpty()) MarketEntry.fillDefaults(market);
    }
}

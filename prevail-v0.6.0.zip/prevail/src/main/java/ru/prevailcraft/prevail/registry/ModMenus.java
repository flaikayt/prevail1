package ru.prevailcraft.prevail.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.prevailcraft.prevail.PrevailMod;
import ru.prevailcraft.prevail.menu.BuyerMenu;
import ru.prevailcraft.prevail.menu.FundMenu;
import ru.prevailcraft.prevail.menu.KeyringMenu;
import ru.prevailcraft.prevail.menu.SafeMenu;

/** Меню (контейнеры) мода. Экраны к ним регистрирует client/PrevailClient. */
public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, PrevailMod.MODID);

    public static final DeferredHolder<MenuType<?>, MenuType<BuyerMenu>> BUYER =
            MENUS.register("buyer", () -> IMenuTypeExtension.create((id, inv, buf) -> new BuyerMenu(id, inv)));
    public static final DeferredHolder<MenuType<?>, MenuType<SafeMenu>> SAFE =
            MENUS.register("safe", () -> IMenuTypeExtension.create((id, inv, buf) -> new SafeMenu(id, inv)));
    public static final DeferredHolder<MenuType<?>, MenuType<KeyringMenu>> KEYRING =
            MENUS.register("keyring", () -> IMenuTypeExtension.create((id, inv, buf) -> new KeyringMenu(id, inv)));
    public static final DeferredHolder<MenuType<?>, MenuType<FundMenu>> FUND =
            MENUS.register("fund", () -> IMenuTypeExtension.create((id, inv, buf) -> new FundMenu(id, inv)));

    private ModMenus() {}

    public static void register(IEventBus modBus) {
        MENUS.register(modBus);
    }
}

package ru.prevailcraft.prevail.territory;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.war.WarService;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * «Здесь нет строгого привата»: на чужой земле можно всё,
 * но каждое действие копит подозрительность. Достиг порога —
 * лорд и рыцари Дома получают право объявить домовой розыск.
 */
public final class SuspicionService {
    /** Анти-спам уведомлений: "дом|игрок" → время последнего сообщения. */
    private static final Map<String, Long> LAST_NOTICE = new HashMap<>();

    private SuspicionService() {}

    public static void onAction(ServerPlayer p, BlockPos pos, double points, String what) {
        House owner = TerritoryService.houseAt(p.level(), pos.getX() >> 4, pos.getZ() >> 4);
        if (owner == null || owner.hungerStage() >= 2) return; // угасающий Дом не стережёт свои земли
        PlayerProfile prof = Players.profile(p);
        if (TerritoryService.friendly(prof.houseId, owner.id)) return;
        if (prof.houseId != null && WarService.inActiveWar(prof.houseId, owner.id)) return; // на войне грабёж — не преступление

        Map<String, Double> m = Prevail.data().suspicion.computeIfAbsent(owner.id, k -> new HashMap<>());
        double before = m.getOrDefault(prof.uuid, 0.0);
        double after = before + points;
        m.put(prof.uuid, after);
        Prevail.markDirty();

        double threshold = PrevailConfig.SUSPICION_THRESHOLD.get();
        String coords = " (" + pos.getX() + ", " + pos.getZ() + ")";
        if (before < threshold && after >= threshold) {
            Players.messageOfficials(owner, "§c⚠ " + prof.name + " " + what + " на землях Дома" + coords
                    + ". Подозрительность достигла порога — можно объявить розыск: /wanted declare "
                    + prof.name + " house <награда> <причина>");
            return;
        }
        String key = owner.id + "|" + prof.uuid;
        long now = System.currentTimeMillis();
        if (now - LAST_NOTICE.getOrDefault(key, 0L) > 60_000) {
            LAST_NOTICE.put(key, now);
            Players.messageOfficials(owner, "§e👁 Замечен чужак: " + prof.name + " " + what + coords
                    + " [" + (int) after + "/" + (int) (double) threshold + "]");
        }
    }

    public static double get(String houseId, String playerUuid) {
        Map<String, Double> m = Prevail.data().suspicion.get(houseId);
        return m == null ? 0 : m.getOrDefault(playerUuid, 0.0);
    }

    public static void clear(String houseId, String playerUuid) {
        Map<String, Double> m = Prevail.data().suspicion.get(houseId);
        if (m != null) m.remove(playerUuid);
    }

    public static void tickSecond() {
        double decay = PrevailConfig.SUSPICION_DECAY_PER_MINUTE.get() / 60.0;
        if (decay <= 0) return;
        for (Map<String, Double> m : Prevail.data().suspicion.values()) {
            Iterator<Map.Entry<String, Double>> it = m.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Double> e = it.next();
                double v = e.getValue() - decay;
                if (v <= 0) it.remove();
                else e.setValue(v);
            }
        }
    }
}

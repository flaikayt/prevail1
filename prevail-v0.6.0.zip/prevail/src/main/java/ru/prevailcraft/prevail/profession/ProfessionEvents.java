package ru.prevailcraft.prevail.profession;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.event.brewing.PlayerBrewedPotionEvent;
import net.neoforged.neoforge.event.entity.living.BabyEntitySpawnEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.entity.player.ItemFishedEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockDropsEvent;
import ru.prevailcraft.prevail.compat.IronsCompat;
import ru.prevailcraft.prevail.compat.ItemData;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Работа ремёсел и умений на сервере (через дропы и результаты крафта — синхронизация не нужна).
 *  - Чужое ремесло: руда с шансом 50% крошится в гравий, брёвна/урожай/скот — 50% потерь.
 *  - Своё: шанс двойной добычи = 0.3% × уровень + навыки древа.
 *  - Качество изделий: от ранга кузнеца/ткача + навыки «лучшее изделие» и «шедевр».
 */
public final class ProfessionEvents {

    private static boolean chance(double p) {
        return ThreadLocalRandom.current().nextDouble() < p;
    }

    private static void duplicate(Collection<ItemEntity> drops) {
        List<ItemEntity> extra = new ArrayList<>();
        for (ItemEntity ie : drops) extra.add(new ItemEntity(ie.level(), ie.getX(), ie.getY(), ie.getZ(), ie.getItem().copy()));
        drops.addAll(extra);
    }

    private static double dbl(PlayerProfile p, String key) {
        return ProfessionService.baseDouble(p) + ProfessionService.bonus(p, key) / 100.0;
    }

    @SubscribeEvent
    public void onDrops(BlockDropsEvent e) {
        if (!Prevail.running() || !(e.getBreaker() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        BlockState st = e.getState();

        if (st.is(Tags.Blocks.ORES)) {
            boolean ok = prof.profession == Profession.MINER && ProfessionService.branchOk(prof, Branch.VEIN);
            if (!ok) {
                if (prof.profession == Profession.MINER || chance(0.5)) {
                    e.getDrops().clear();
                    var pos = e.getPos();
                    e.getDrops().add(new ItemEntity(e.getLevel(), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.GRAVEL)));
                    p.sendSystemMessage(Component.literal("§7Руда раскрошилась в пустую породу — нужен рудокоп-жильщик."), true);
                }
                return;
            }
            ProfessionService.addXp(prof, Profession.MINER, 3);
            boolean gem = st.is(Blocks.DIAMOND_ORE) || st.is(Blocks.DEEPSLATE_DIAMOND_ORE) || st.is(Blocks.EMERALD_ORE) || st.is(Blocks.DEEPSLATE_EMERALD_ORE);
            double c = dbl(prof, "dbl_ore") + (gem ? ProfessionService.bonus(prof, "dbl_gem") / 100.0 : 0);
            if (chance(c)) duplicate(e.getDrops());
            return;
        }
        if (st.is(BlockTags.BASE_STONE_OVERWORLD) || st.is(Blocks.CLAY) || st.is(Blocks.COBBLED_DEEPSLATE)) {
            if (prof.profession == Profession.MINER) {
                if (chance(0.25)) ProfessionService.addXp(prof, Profession.MINER, 1);
                if (chance(ProfessionService.bonus(prof, "dbl_stone") / 100.0)) duplicate(e.getDrops());
            }
            return;
        }
        if (st.is(BlockTags.LOGS)) {
            if (prof.profession != Profession.LUMBERJACK) {
                if (chance(0.5)) e.getDrops().clear();
                return;
            }
            ProfessionService.addXp(prof, Profession.LUMBERJACK, 1);
            if (chance(dbl(prof, "dbl_log"))) duplicate(e.getDrops());
            return;
        }
        if (st.getBlock() instanceof CropBlock crop && crop.isMaxAge(st)) {
            if (prof.profession != Profession.FARMER) {
                if (chance(0.5)) e.getDrops().clear();
                return;
            }
            ProfessionService.addXp(prof, Profession.FARMER, 1);
            boolean grain = st.is(Blocks.WHEAT);
            if (chance(dbl(prof, grain ? "dbl_grain" : "dbl_veg") + (grain ? 0 : ProfessionService.bonus(prof, "dbl_grain") / 200.0))) {
                duplicate(e.getDrops());
            }
        }
    }

    @SubscribeEvent
    public void onMobDrops(LivingDropsEvent e) {
        if (!Prevail.running() || !(e.getSource().getEntity() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        if (e.getEntity() instanceof Animal) {
            if (prof.profession != Profession.HERDER) {
                if (chance(0.5)) e.getDrops().clear();
                return;
            }
            ProfessionService.addXp(prof, Profession.HERDER, 2);
            if (chance(dbl(prof, "dbl_animal"))) duplicate(e.getDrops());
        } else if (e.getEntity() instanceof Enemy) {
            int lv = AbilityService.level(prof, Ability.HUNTSMAN);
            if (lv == 0) return;
            AbilityService.addXp(prof, Ability.HUNTSMAN, 3);
            if (chance(0.05 + 0.10 * lv)) duplicate(e.getDrops());
        }
    }

    @SubscribeEvent
    public void onBreed(BabyEntitySpawnEvent e) {
        if (!Prevail.running() || !(e.getCausedByPlayer() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        ProfessionService.addXp(prof, Profession.HERDER, prof.branch == Branch.HORSEMASTER ? 8 : 4);
    }

    @SubscribeEvent
    public void onFish(ItemFishedEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        int lv = AbilityService.level(prof, Ability.FISHER);
        if (lv == 0) return;
        AbilityService.addXp(prof, Ability.FISHER, 4);
        if (chance(0.05 + 0.10 * lv)) {
            for (ItemStack s : e.getDrops()) {
                ItemStack c = s.copy();
                if (!p.getInventory().add(c)) p.drop(c, false);
            }
            p.sendSystemMessage(Component.literal("§bДвойной улов!"), true);
        }
    }

    @SubscribeEvent
    public void onBrew(PlayerBrewedPotionEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        int lv = AbilityService.level(prof, Ability.HEALER);
        AbilityService.addXp(prof, Ability.HEALER, 3);
        double c = lv >= 3 ? 0.35 : lv == 2 ? 0.20 : 0;
        if (chance(c)) {
            ItemStack copy = e.getStack().copy();
            if (!p.getInventory().add(copy)) p.drop(copy, false);
        }
    }

    @SubscribeEvent
    public void onEat(LivingEntityUseItemEvent.Finish e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (!e.getItem().has(DataComponents.FOOD)) return;
        PlayerProfile prof = Players.profile(p);
        int lv = AbilityService.level(prof, Ability.COOK);
        if (lv == 0) return;
        p.getFoodData().eat(lv, 0.3f * lv);
        AbilityService.addXp(prof, Ability.COOK, 2);
    }

    /** Варочная стойка — только Лекарь; блоки Iron's — только Чародей. */
    @SubscribeEvent
    public void onUseBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        BlockState st = e.getLevel().getBlockState(e.getPos());
        PlayerProfile prof = Players.profile(p);
        if (st.is(Blocks.BREWING_STAND) && !AbilityService.has(prof, Ability.HEALER)) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cВарить зелья может только Лекарь-алхимик (умение)."), true);
        } else if (IronsCompat.loaded() && IronsCompat.MODID.equals(VersionCompat.blockNamespace(st.getBlock()))
                && !AbilityService.has(prof, Ability.SORCERER)) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cМагией владеют только Чародеи (умение)."), true);
        }
    }

    @SubscribeEvent
    public void onUseItem(PlayerInteractEvent.RightClickItem e) {
        if (!Prevail.running() || e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (!IronsCompat.loaded() || !IronsCompat.MODID.equals(VersionCompat.itemNamespace(e.getItemStack().getItem()))) return;
        if (!AbilityService.has(Players.profile(p), Ability.SORCERER)) {
            e.setCanceled(true);
            p.sendSystemMessage(Component.literal("§cСвитки и книги заклинаний подчиняются только Чародеям."), true);
        }
    }

    @SubscribeEvent
    public void onCraft(PlayerEvent.ItemCraftedEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getCrafting();
        PlayerProfile prof = Players.profile(p);

        boolean weapon = s.is(ItemTags.SWORDS) || s.is(Items.BOW) || s.is(Items.CROSSBOW) || s.is(Items.MACE);
        boolean armor = s.is(ItemTags.HEAD_ARMOR) || s.is(ItemTags.CHEST_ARMOR) || s.is(ItemTags.LEG_ARMOR) || s.is(ItemTags.FOOT_ARMOR);
        boolean tool = s.is(ItemTags.PICKAXES) || s.is(ItemTags.AXES) || s.is(ItemTags.SHOVELS) || s.is(ItemTags.HOES);

        if ((weapon || armor || tool) && s.isDamageableItem()) {
            boolean leather = s.is(Items.LEATHER_HELMET) || s.is(Items.LEATHER_CHESTPLATE) || s.is(Items.LEATHER_LEGGINGS) || s.is(Items.LEATHER_BOOTS);
            Quality q = Quality.ROUGH;
            if (leather && prof.profession == Profession.WEAVER) {
                q = Quality.roll(ProfessionService.rank(prof));
                q = upgrade(q, prof, "q_leather");
                ProfessionService.addXp(prof, Profession.WEAVER, 4);
            } else if (prof.profession == Profession.SMITH) {
                boolean ok = tool || (weapon && ProfessionService.branchOk(prof, Branch.WEAPONSMITH))
                        || (armor && ProfessionService.branchOk(prof, Branch.ARMORER));
                if (ok) {
                    q = Quality.roll(ProfessionService.rank(prof));
                    q = upgrade(q, prof, tool ? "q_tool" : weapon ? "q_weapon" : "q_armor");
                }
                ProfessionService.addXp(prof, Profession.SMITH, ok ? 6 : 1);
            }
            stamp(s, q, prof);
            if (q == Quality.ROUGH) p.sendSystemMessage(Component.literal("§7Без мастера вещь вышла грубой (½ прочности)."), true);
            return;
        }
        if (s.is(ItemTags.BOATS)) {
            ProfessionService.addXp(prof, Profession.CARPENTER, prof.branch == Branch.SHIPWRIGHT ? 8 : 4);
            if (prof.profession == Profession.CARPENTER && chance(ProfessionService.bonus(prof, "dbl_boat") / 100.0)) give(p, s.copy());
        } else if (s.is(ItemTags.BANNERS)) {
            ProfessionService.addXp(prof, Profession.WEAVER, prof.branch == Branch.BANNERMAKER ? 6 : 3);
            if (prof.profession == Profession.WEAVER && chance(ProfessionService.bonus(prof, "dbl_banner") / 100.0)) give(p, s.copy());
        } else if (s.is(Items.BREAD) || s.is(Items.CAKE)) {
            ProfessionService.addXp(prof, Profession.FARMER, s.getCount());
        }
    }

    private static void give(ServerPlayer p, ItemStack s) {
        if (!p.getInventory().add(s)) p.drop(s, false);
    }

    /** Навыки: шанс поднять качество на ступень и отдельный шанс шедевра. */
    private static Quality upgrade(Quality q, PlayerProfile prof, String key) {
        if (chance(ProfessionService.bonus(prof, key) / 100.0)) q = Quality.byIndex(Math.min(3, q.ordinal() + 1));
        if (chance(ProfessionService.bonus(prof, "q_master") / 100.0)) q = Quality.MASTERWORK;
        return q;
    }

    public static void stamp(ItemStack s, Quality q, PlayerProfile maker) {
        ItemData.setMaxDamage(s, (int) Math.round(s.getMaxDamage() * q.durability));
        House h = Players.house(maker);
        ItemData.putString(s, "quality", q.name());
        ItemData.lore(s, q.color + "Качество: " + q.title, "§8Работа: " + maker.name + (h != null ? " (Дом " + h.name + ")" : ""));
    }

    @SubscribeEvent
    public void onSmelt(PlayerEvent.ItemSmeltedEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer p)) return;
        PlayerProfile prof = Players.profile(p);
        ItemStack s = e.getSmelting();
        if (s.is(Items.CHARCOAL)) {
            ProfessionService.addXp(prof, Profession.LUMBERJACK, s.getCount());
            if (prof.profession == Profession.LUMBERJACK && chance(ProfessionService.bonus(prof, "dbl_charcoal") / 100.0)) {
                give(p, new ItemStack(Items.CHARCOAL, s.getCount()));
            }
        }
    }

    /** Раз в 30 с: «Спешка» мастерам, у которых изучен такой навык и в руке инструмент ремесла. */
    public static void tickHaste() {
        for (ServerPlayer p : Prevail.server().getPlayerList().getPlayers()) {
            PlayerProfile prof = Players.profile(p);
            if (ProfessionService.bonus(prof, "haste") <= 0) continue;
            ItemStack hand = p.getMainHandItem();
            boolean tool = switch (prof.profession) {
                case MINER -> hand.is(ItemTags.PICKAXES);
                case LUMBERJACK, CARPENTER -> hand.is(ItemTags.AXES);
                case FARMER -> hand.is(ItemTags.HOES);
                default -> false;
            };
            if (tool) p.addEffect(new MobEffectInstance(MobEffects.HASTE, 20 * 35, 0, true, false));
        }
    }
}

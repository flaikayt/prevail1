package ru.prevailcraft.prevail.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.prevailcraft.prevail.PrevailMod;
import ru.prevailcraft.prevail.menu.BuyerMenu;

/** Меню (контейнеры) мода. Экраны к ним регистрирует client/PrevailClient. */
public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, PrevailMod.MODID);

    public static final DeferredHolder<MenuType<?>, MenuType<BuyerMenu>> BUYER =
            MENUS.register("buyer", () -> IMenuTypeExtension.create((id, inv, buf) -> new BuyerMenu(id, inv)));

    private ModMenus() {}

    public static void register(IEventBus modBus) {
        MENUS.register(modBus);
    }
}

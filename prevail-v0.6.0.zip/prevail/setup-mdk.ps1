﻿# Prevail: подготовка проекта из официального MDK NeoForge.
# Положи распакованный MDK в папку "mdk" рядом с этим файлом и запусти setup-mdk.bat.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$mdk = Join-Path $root 'mdk'
$utf8 = New-Object System.Text.UTF8Encoding $false

if (-not (Test-Path $mdk)) {
    Write-Host 'ОШИБКА: не найдена папка mdk рядом с этим файлом.' -ForegroundColor Red
    Write-Host 'Распакуй скачанный MDK так, чтобы получилась папка prevail\mdk'
    exit 1
}
$bg = Get-ChildItem -Path $mdk -Filter build.gradle -Recurse | Select-Object -First 1
if (-not $bg) { Write-Host 'ОШИБКА: в папке mdk нет build.gradle — это точно MDK?' -ForegroundColor Red; exit 1 }
$src = $bg.DirectoryName

Copy-Item (Join-Path $src 'gradlew') $root -Force
Copy-Item (Join-Path $src 'gradlew.bat') $root -Force
Copy-Item (Join-Path $src 'gradle') $root -Recurse -Force
Write-Host '[1/3] Скопированы gradlew, gradlew.bat и папка gradle' -ForegroundColor Green

$mdkBuild = [IO.File]::ReadAllText($bg.FullName, $utf8)
$m = [regex]::Match($mdkBuild, "net\.neoforged\.moddev['""]\s*\)?\s*version\s*\(?\s*['""]([^'""]+)['""]")
if ($m.Success) {
    $ver = $m.Groups[1].Value
    $ours = Join-Path $root 'build.gradle'
    $t = [IO.File]::ReadAllText($ours, $utf8)
    $t = [regex]::Replace($t, "(id 'net\.neoforged\.moddev' version ')[^']+(')", "`${1}$ver`${2}")
    [IO.File]::WriteAllText($ours, $t, $utf8)
    Write-Host "[2/3] Версия ModDevGradle: $ver" -ForegroundColor Green
} else {
    Write-Host '[2/3] Не нашёл версию ModDevGradle в MDK — перенеси её вручную (см. README)' -ForegroundColor Yellow
}

$mdkProps = [IO.File]::ReadAllText((Join-Path $src 'gradle.properties'), $utf8)
$n = [regex]::Match($mdkProps, '(?m)^\s*neo_version\s*=\s*(\S+)')
if ($n.Success) {
    $neo = $n.Groups[1].Value
    $op = Join-Path $root 'gradle.properties'
    $p = [IO.File]::ReadAllText($op, $utf8)
    $p = [regex]::Replace($p, '(?m)^neo_version=.*$', "neo_version=$neo")
    [IO.File]::WriteAllText($op, $p, $utf8)
    Write-Host "[3/3] Версия NeoForge: $neo" -ForegroundColor Green
} else {
    Write-Host '[3/3] Не нашёл neo_version в MDK — перенеси вручную (см. README)' -ForegroundColor Yellow
}
Write-Host ''
Write-Host 'Готово! Папку mdk можно удалить. Теперь открой папку prevail в IntelliJ IDEA.' -ForegroundColor Cyan

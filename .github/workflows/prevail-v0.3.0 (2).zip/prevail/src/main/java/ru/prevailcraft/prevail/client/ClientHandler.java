package ru.prevailcraft.prevail.client;

import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import ru.prevailcraft.prevail.client.screen.HouseFoundScreen;
import ru.prevailcraft.prevail.client.screen.MarketScreen;
import ru.prevailcraft.prevail.client.screen.ProfessionDetailScreen;
import ru.prevailcraft.prevail.client.screen.ProfessionScreen;
import ru.prevailcraft.prevail.network.OpenScreenPayload;

import java.util.HashMap;
import java.util.Map;

/** Приём пакета «открыть экран» от сервера. */
public final class ClientHandler {
    private ClientHandler() {}

    /** "a=1;b=2" → {a:1, b:2}. */
    public static Map<String, String> parse(String data) {
        Map<String, String> m = new HashMap<>();
        for (String part : data.split(";")) {
            int i = part.indexOf('=');
            if (i > 0) m.put(part.substring(0, i), part.substring(i + 1));
        }
        return m;
    }

    public static void onOpenScreen(OpenScreenPayload msg, IPayloadContext ctx) {
        Minecraft mc = Minecraft.getInstance();
        Map<String, String> d = parse(msg.data());
        switch (msg.screen()) {
            case "house_found" -> mc.setScreen(new HouseFoundScreen(d));
            case "professions" -> {
                if (mc.screen instanceof ProfessionDetailScreen det) det.update(d);
                else if (mc.screen instanceof ProfessionScreen ps) ps.update(d);
                else mc.setScreen(new ProfessionScreen(d));
            }
            case "market" -> mc.setScreen(new MarketScreen(d));
            case "market_update" -> {
                if (mc.screen instanceof MarketScreen ms) ms.update(d);
            }
            default -> { }
        }
    }
}

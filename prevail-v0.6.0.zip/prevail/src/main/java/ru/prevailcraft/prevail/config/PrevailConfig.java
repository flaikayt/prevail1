package ru.prevailcraft.prevail.config;

import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.List;

/** Серверный конфиг: world/serverconfig/prevail-server.toml */
public final class PrevailConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.ConfigValue<List<? extends String>> ADMINS;

    public static final ModConfigSpec.LongValue TAX_PER_CHUNK;
    public static final ModConfigSpec.IntValue TAX_INTERVAL_MINUTES;
    public static final ModConfigSpec.LongValue HOUSE_FEE;

    public static final ModConfigSpec.IntValue PC_WAR, PC_KNIGHT, PC_HUNT, PC_FEALTY;

    public static final ModConfigSpec.DoubleValue SUSPICION_THRESHOLD;
    public static final ModConfigSpec.DoubleValue SUSPICION_DECAY_PER_MINUTE;

    public static final ModConfigSpec.LongValue WAR_DECLARE_COST;
    public static final ModConfigSpec.IntValue WAR_PREP_MINUTES;
    public static final ModConfigSpec.IntValue SIEGE_START_HOUR;
    public static final ModConfigSpec.IntValue SIEGE_END_HOUR;
    public static final ModConfigSpec.ConfigValue<String> TIMEZONE;
    public static final ModConfigSpec.IntValue CAPTURE_SECONDS;

    public static final ModConfigSpec.IntValue PRISON_MINUTES;
    public static final ModConfigSpec.IntValue PRISON_RADIUS;
    public static final ModConfigSpec.DoubleValue ARREST_HEALTH_FRACTION;
    public static final ModConfigSpec.LongValue BAIL_PER_MINUTE;

    public static final ModConfigSpec.IntValue PROFESSION_COOLDOWN_HOURS;
    public static final ModConfigSpec.IntValue GRANDMASTER_SLOTS;

    public static final ModConfigSpec.IntValue ESSENCE_MINUTES;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.push("general");
        ADMINS = b.comment("Ники или UUID администраторов мода (/prevailadmin)")
                .defineListAllowEmpty("admins", List.of(), () -> "", o -> o instanceof String);
        b.pop();

        b.push("economy");
        TAX_PER_CHUNK = b.comment("Королевский налог за чанк, в медяках").defineInRange("taxPerChunk", 2L, 0L, 1_000_000L);
        TAX_INTERVAL_MINUTES = b.comment("Период сбора налога (реальные минуты)").defineInRange("taxIntervalMinutes", 60, 1, 10080);
        HOUSE_FEE = b.comment("Первый взнос при основании Дома у Фонда, в медяках").defineInRange("houseFee", 500L, 0L, 100_000_000L);
        b.pop();

        b.push("powerCoins");
        PC_WAR = b.comment("Монет власти за объявление войны").defineInRange("war", 10, 0, 1000);
        PC_KNIGHT = b.comment("Монет власти за посвящение в рыцари").defineInRange("knight", 3, 0, 1000);
        PC_HUNT = b.comment("Монет власти за королевскую охоту").defineInRange("hunt", 5, 0, 1000);
        PC_FEALTY = b.comment("Монет власти за принятие вассального Дома").defineInRange("fealty", 5, 0, 1000);
        b.pop();

        b.push("territory");
        SUSPICION_THRESHOLD = b.defineInRange("suspicionThreshold", 20.0, 1.0, 10_000.0);
        SUSPICION_DECAY_PER_MINUTE = b.defineInRange("suspicionDecayPerMinute", 0.5, 0.0, 1000.0);
        b.pop();

        b.push("war");
        WAR_DECLARE_COST = b.defineInRange("declareCost", 500L, 0L, 100_000_000L);
        WAR_PREP_MINUTES = b.defineInRange("prepMinutes", 60 * 24, 0, 60 * 24 * 14);
        SIEGE_START_HOUR = b.defineInRange("siegeStartHour", 18, 0, 23);
        SIEGE_END_HOUR = b.defineInRange("siegeEndHour", 22, 0, 24);
        TIMEZONE = b.define("timezone", "Europe/Moscow");
        CAPTURE_SECONDS = b.defineInRange("captureSeconds", 120, 5, 3600);
        b.pop();

        b.push("law");
        PRISON_MINUTES = b.defineInRange("prisonMinutes", 30, 1, 60 * 24);
        PRISON_RADIUS = b.defineInRange("prisonRadius", 8, 1, 64);
        ARREST_HEALTH_FRACTION = b.defineInRange("arrestHealthFraction", 0.4, 0.05, 1.0);
        BAIL_PER_MINUTE = b.comment("Выкуп за минуту оставшегося срока, в медяках").defineInRange("bailPerMinute", 10L, 0L, 1_000_000L);
        b.pop();

        b.push("profession");
        PROFESSION_COOLDOWN_HOURS = b.defineInRange("changeCooldownHours", 72, 0, 24 * 60);
        GRANDMASTER_SLOTS = b.comment("Сколько гроссмейстеров каждой профессии может быть на сервере")
                .defineInRange("grandmasterSlots", 3, 1, 100);
        b.pop();

        b.push("world");
        ESSENCE_MINUTES = b.comment("Раз в сколько минут в Фонде появляется Исток (максимум 5)")
                .defineInRange("essenceMinutes", 30, 1, 1440);
        b.pop();

        SPEC = b.build();
    }

    private PrevailConfig() {}
}

package ru.prevailcraft.prevail.court;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Items;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.Kingdom;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Pos;
import ru.prevailcraft.prevail.core.Rank;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.economy.EconomyService;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.economy.PowerCoins;
import ru.prevailcraft.prevail.law.WantedService;
import ru.prevailcraft.prevail.profession.Profession;
import ru.prevailcraft.prevail.profession.ProfessionService;
import ru.prevailcraft.prevail.ui.ChestGui;
import ru.prevailcraft.prevail.ui.Icons;
import ru.prevailcraft.prevail.world.Epoch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Корона и двор.
 * Монарх избирается лордами (вес = 1 + рыцари + 2 × вассальные Дома + подкуп).
 * Больше половины — коронация у Короны; низложить действующего короля — 2/3.
 */
public final class CourtService {
    private CourtService() {}

    public static Kingdom k() {
        return Prevail.data().kingdom;
    }

    public static boolean isKing(String uuid) {
        return uuid != null && uuid.equals(k().king);
    }

    /**
     * Король — всегда; десница — за любую должность; остальные — за свою.
     * Для всех, кроме короля, регалия должна быть в инвентаре.
     */
    public static boolean has(String uuid, CourtOffice... offices) {
        if (uuid == null) return false;
        if (isKing(uuid)) return true;
        ServerPlayer p = Players.online(uuid);
        if (p == null) return false;
        if (uuid.equals(k().offices.get(CourtOffice.HAND.name())) && RegaliaService.carries(p, CourtOffice.HAND)) return true;
        for (CourtOffice o : offices) {
            if (uuid.equals(k().offices.get(o.name())) && RegaliaService.carries(p, o)) return true;
        }
        return false;
    }

    public static CourtOffice parseOffice(String s) {
        for (CourtOffice o : CourtOffice.values()) {
            if (o.name().equalsIgnoreCase(s) || o.title.equalsIgnoreCase(s)) return o;
        }
        throw new PrevailException("Нет такой должности. Есть: hand, marshal, treasurer, chancellor, architect.");
    }

    // ---------- борьба за корону ----------

    public static int voteWeight(PlayerProfile lord) {
        House h = Players.house(lord);
        if (h == null || !lord.uuid.equals(h.lord)) return 0;
        int knights = 0;
        for (String m : h.members) {
            PlayerProfile o = Players.profile(m);
            if (o != null && o.rank == Rank.KNIGHT) knights++;
        }
        int vassals = 0;
        for (House o : Prevail.data().houses.values()) if (h.id.equals(o.suzerain)) vassals++;
        return 1 + knights + 2 * vassals;
    }

    public static int totalWeight() {
        int t = 0;
        for (House h : Prevail.data().houses.values()) t += voteWeight(Players.profile(h.lord));
        return t;
    }

    public static int support(String candidate) {
        int s = k().bribes.getOrDefault(candidate, 0);
        for (Map.Entry<String, String> v : k().votes.entrySet()) {
            if (candidate.equals(v.getValue())) s += voteWeight(Players.profile(v.getKey()));
        }
        return s;
    }

    public static String claim(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        if (p.rank != Rank.LORD) throw new PrevailException("Претендовать на корону могут только лорды.");
        if (isKing(p.uuid)) throw new PrevailException("Вы уже король.");
        k().claimants.add(p.uuid);
        Players.broadcast("§6👑 Лорд " + p.name + " заявил притязания на корону! Лорды, голосуйте у Короны или: /court vote " + p.name);
        return null;
    }

    public static String vote(ServerPlayer sp, String candidate) {
        PlayerProfile p = Players.profile(sp);
        if (voteWeight(p) == 0) throw new PrevailException("Голосуют только лорды Домов.");
        PlayerProfile c = Players.byName(candidate);
        if (!k().claimants.contains(c.uuid)) throw new PrevailException(c.name + " не претендует на корону.");
        k().votes.put(p.uuid, c.uuid);
        return "Ваш голос (" + voteWeight(p) + ") отдан лорду " + c.name + ". За него: " + support(c.uuid) + " из " + totalWeight();
    }

    /** Подкуп: 2 монеты власти = +1 к весу претендента до коронации. */
    public static String bribe(ServerPlayer sp, String candidate, int coins) {
        PlayerProfile c = Players.byName(candidate);
        if (!k().claimants.contains(c.uuid)) throw new PrevailException(c.name + " не претендует на корону.");
        if (coins < 2) throw new PrevailException("Минимум 2 монеты власти.");
        PowerCoins.spend(sp, coins, "Подкуп голосов");
        k().bribes.merge(c.uuid, coins / 2, Integer::sum);
        return "Знать стала благосклоннее к " + c.name + " (+" + coins / 2 + " к поддержке).";
    }

    public static String crown(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        if (!k().claimants.contains(p.uuid)) throw new PrevailException("Сначала заявите притязания.");
        int sup = support(p.uuid), total = totalWeight();
        boolean usurp = k().king != null;
        boolean enough = usurp ? sup * 3 >= total * 2 : sup * 2 > total;
        if (!enough) throw new PrevailException("Недостаточно поддержки: " + sup + " из " + total + (usurp ? " (для низложения — 2/3)" : " (нужно больше половины)") + ".");
        if (k().throne != null && !k().throne.near(sp, 6)) throw new PrevailException("Коронация проходит у Короны королевства: " + k().throne.pretty());
        setKing(p.uuid, usurp ? "низложил прежнего короля и" : "");
        return null;
    }

    public static void setKing(String uuid, String how) {
        String old = k().king;
        k().king = uuid;
        k().claimants.clear();
        k().votes.clear();
        k().bribes.clear();
        k().supporters.clear();
        k().legitimacyEvents = 0;
        if (old != null && !old.equals(uuid)) {
            for (CourtOffice o : CourtOffice.values()) RegaliaService.revoke(o);
            k().offices.clear();
        }
        k().offices.values().removeIf(uuid::equals);
        Players.broadcast("§6§l👑 " + Players.name(uuid) + " " + how + " коронован! Да здравствует король!");
        Prevail.markDirty();
    }

    public static String abdicate(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        if (!isKing(p.uuid)) throw new PrevailException("Вы не король.");
        k().king = null;
        for (CourtOffice o : CourtOffice.values()) RegaliaService.revoke(o);
        k().offices.clear();
        k().supporters.clear();
        Players.broadcast("§7Король " + p.name + " отрёкся от престола. Трон пуст!");
        return null;
    }

    /** Лорд присягает короне (или отзывает присягу) — это главный источник легитимности. */
    public static String swear(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        if (p.rank != Rank.LORD) throw new PrevailException("Присягают короне лорды.");
        if (k().king == null) throw new PrevailException("Трон пуст.");
        if (isKing(p.uuid)) throw new PrevailException("Король не присягает сам себе.");
        if (k().supporters.remove(p.uuid)) {
            Players.broadcast("§c⚡ Лорд " + p.name + " отозвал присягу короне!");
        } else {
            k().supporters.add(p.uuid);
            Players.broadcast("§a🛡 Лорд " + p.name + " присягнул короне.");
        }
        return "Легитимность короля: " + Legitimacy.describe();
    }

    public static String donate(ServerPlayer sp, int coins) {
        if (k().king == null) throw new PrevailException("Трон пуст.");
        PowerCoins.spend(sp, coins, "Пожертвование короне");
        Legitimacy.event(coins * 0.5);
        return "Корона благодарит вас. Легитимность: " + Legitimacy.describe();
    }

    // ---------- двор ----------

    public static String appoint(ServerPlayer sp, CourtOffice o, PlayerProfile t) {
        PlayerProfile p = Players.profile(sp);
        if (!isKing(p.uuid)) throw new PrevailException("Должности раздаёт лично король.");
        Legitimacy.require(Legitimacy.COURT, "Назначение на должность");
        if (!o.rankOk(t.rank)) throw new PrevailException(o.title + " требует титул: " + (o.minRank == Rank.LORD ? "лорд" : "рыцарь или лорд") + ".");
        if (isKing(t.uuid)) throw new PrevailException("Король не занимает должности.");
        if (k().offices.containsKey(o.name())) RegaliaService.revoke(o);
        k().offices.values().removeIf(t.uuid::equals); // одна должность на человека
        k().offices.put(o.name(), t.uuid);
        RegaliaService.issue(o, t.uuid);
        Players.broadcast("§6Король вручил " + t.name + " регалию: " + o.regaliaName + " (" + o.title + ").");
        return null;
    }

    public static String dismiss(ServerPlayer sp, CourtOffice o) {
        PlayerProfile p = Players.profile(sp);
        if (!isKing(p.uuid)) throw new PrevailException("Снимает с должности только король.");
        Legitimacy.require(Legitimacy.COURT, "Снятие с должности");
        String was = k().offices.remove(o.name());
        if (was == null) throw new PrevailException("Должность и так свободна.");
        RegaliaService.revoke(o);
        Players.broadcast("§cКороль разбил регалию «" + o.regaliaName + "». " + Players.name(was) + " больше не " + o.title.toLowerCase() + ".");
        return null;
    }

    public static String setTax(ServerPlayer sp, long perChunk) {
        PlayerProfile p = Players.profile(sp);
        if (!has(p.uuid, CourtOffice.TREASURER)) throw new PrevailException("Налоги устанавливают король, десница и казначей.");
        Legitimacy.require(Legitimacy.TAXES, "Установка налогов");
        if (perChunk < 0) throw new PrevailException("Налог не может быть отрицательным.");
        k().taxPerChunk = perChunk;
        Players.broadcast("§e📜 Королевский указ: налог — " + Money.fmt(perChunk) + " за чанк земли.");
        return null;
    }

    public static String treasuryWithdraw(ServerPlayer sp, long amount) {
        PlayerProfile p = Players.profile(sp);
        if (!has(p.uuid, CourtOffice.TREASURER)) throw new PrevailException("Нет доступа к королевской казне.");
        if (amount <= 0 || k().treasury < amount) throw new PrevailException("В казне " + Money.fmt(k().treasury) + ".");
        k().treasury -= amount;
        Money.give(sp, amount);
        return "Из королевской казны выдано " + Money.fmt(amount) + ".";
    }

    public static String setRoyalPrison(ServerPlayer sp) {
        if (!has(Players.profile(sp).uuid, CourtOffice.MARSHAL)) throw new PrevailException("Тюрьмами ведает маршал.");
        k().prison = Pos.of(sp);
        return "Королевская тюрьма: " + k().prison.pretty();
    }

    /** Королевская охота: «враг короны», награда за голову из казны. */
    public static String hunt(ServerPlayer sp, String name, long bounty) {
        PlayerProfile p = Players.profile(sp);
        if (!has(p.uuid, CourtOffice.MARSHAL)) throw new PrevailException("Охоту объявляют король, десница и маршал.");
        Legitimacy.require(Legitimacy.HUNT, "Королевская охота");
        PlayerProfile t = Players.byName(name);
        if (k().treasury < bounty) throw new PrevailException("В казне не хватает на награду.");
        PowerCoins.spend(sp, PrevailConfig.PC_HUNT.get(), "Королевская охота");
        k().treasury -= bounty;
        k().hunts.merge(t.uuid, bounty, Long::sum);
        Players.broadcast("§4🏹 КОРОЛЕВСКАЯ ОХОТА: " + t.name + " объявлен врагом короны! Награда за голову: " + Money.fmt(k().hunts.get(t.uuid)));
        return null;
    }

    public static String edictPeace(ServerPlayer sp) {
        if (!isKing(Players.profile(sp).uuid)) throw new PrevailException("Указы издаёт король.");
        Legitimacy.require(Legitimacy.EDICTS, "Указ о мире");
        k().peaceEdictUntil = System.currentTimeMillis() + 24 * 3_600_000L;
        Players.broadcast("§e📜 Указ о королевском мире: сутки никто не может объявлять войну.");
        return null;
    }

    // ---------- Трон (GUI) ----------

    public static void openThrone(ServerPlayer sp) {
        new ChestGui(4, "Корона королевства", gui -> {
            PlayerProfile me = Players.profile(sp);
            boolean king = isKing(me.uuid);
            double leg = Legitimacy.value();
            gui.set(4, Icons.of(Items.GOLDEN_HELMET, "§6§l" + (k().king == null ? "Трон пуст" : "Король " + Players.name(k().king)),
                    "§7Легитимность: " + Icons.bar(leg / 100) + " §f" + Legitimacy.describe(),
                    "§825% налоги · 50% двор · 75% охота · 90% указы",
                    "§7Казна: §f" + Money.fmt(k().treasury) + " §7· Налог: §f" + Money.fmt(EconomyService.taxPerChunk()) + "/чанк"), null);

            int slot = 11;
            for (CourtOffice o : CourtOffice.values()) {
                String h = k().offices.get(o.name());
                gui.set(slot++, Icons.of(o.regalia(), "§e" + o.title + ": §f" + (h == null ? "свободно" : Players.name(h)),
                        "§7" + o.duty,
                        king ? (h == null ? "§aКлик — назначить" : "§cКлик — разбить регалию (снять)") : ""),
                        king ? (pl, r, s) -> {
                            if (k().offices.containsKey(o.name())) dismiss(pl, o);
                            else openPicker(pl, o);
                        } : null);
            }

            if (me.rank == Rank.LORD && !king) {
                gui.set(27, Icons.of(Items.NAME_TAG, "§eЗаявить притязания на корону"), (pl, r, s) -> claim(pl));
                gui.set(28, Icons.of(Items.SHIELD, k().supporters.contains(me.uuid) ? "§cОтозвать присягу короне" : "§aПрисягнуть короне"),
                        (pl, r, s) -> swear(pl));
                gui.set(29, Icons.of(Items.GOLDEN_HELMET, "§6Короноваться", "§7Нужна поддержка лордов"), (pl, r, s) -> crown(pl));
            }
            List<String> cl = new ArrayList<>(k().claimants);
            int cs = 31;
            for (String c : cl) {
                if (cs > 35) break;
                gui.set(cs++, Icons.of(Items.PAPER, "§fПретендент: " + Players.name(c),
                        "§7Поддержка: " + support(c) + " из " + totalWeight(), me.rank == Rank.LORD ? "§aКлик — отдать голос" : ""),
                        me.rank == Rank.LORD ? (pl, r, s) -> pl.sendSystemMessage(net.minecraft.network.chat.Component.literal(vote(pl, Players.name(c)))) : null);
            }
            Icons.frame(gui);
        }).open(sp);
    }

    private static void openPicker(ServerPlayer sp, CourtOffice o) {
        new ChestGui(6, "Назначить: " + o.title, gui -> {
            int slot = 0;
            for (ServerPlayer cand : Prevail.server().getPlayerList().getPlayers()) {
                if (slot >= 54) break;
                PlayerProfile t = Players.profile(cand);
                if (isKing(t.uuid)) continue;
                boolean ok = o.rankOk(t.rank);
                gui.set(slot++, Icons.of(ok ? Items.PLAYER_HEAD : Items.SKELETON_SKULL, (ok ? "§a" : "§8") + t.name,
                        "§7" + t.rank.title, ok ? "§aКлик — вручить регалию" : "§cНе подходит по титулу"),
                        ok ? (pl, r, s) -> {
                            appoint(pl, o, t);
                            pl.closeContainer();
                        } : null);
            }
        }).open(sp);
    }

    public static String info() {
        StringBuilder sb = new StringBuilder("§6═══ Королевский двор ═══\n");
        sb.append("§eКороль: §f").append(k().king == null ? "трон пуст" : Players.name(k().king)).append('\n');
        sb.append("§eЛегитимность: §f").append(Legitimacy.describe()).append('\n');
        for (CourtOffice o : CourtOffice.values()) {
            String h = k().offices.get(o.name());
            sb.append("§e").append(o.title).append(": §f").append(h == null ? "—" : Players.name(h)).append('\n');
        }
        sb.append("§eКазна: §f").append(Money.fmt(k().treasury)).append(" §7· чеканка ").append(k().mintingOpen ? "открыта" : "закрыта");
        if (!k().hunts.isEmpty()) {
            sb.append("\n§4Враги короны:");
            for (Map.Entry<String, Long> h : k().hunts.entrySet()) sb.append("\n §f• ").append(Players.name(h.getKey())).append(" — ").append(Money.fmt(h.getValue()));
        }
        return sb.toString();
    }

    /** Вызывается при убийстве игрока: выплата за врага короны. */
    public static void onKill(ServerPlayer killer, ServerPlayer victim) {
        Long bounty = k().hunts.remove(victim.getUUID().toString());
        if (bounty == null) return;
        Money.give(killer, bounty);
        Players.broadcast("§4🏹 " + killer.getName().getString() + " сразил врага короны " + victim.getName().getString() + " и получил " + Money.fmt(bounty) + ".");
        WantedService.clearAll(victim.getUUID().toString());
    }
}

package ru.prevailcraft.prevail.network;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import ru.prevailcraft.prevail.PrevailMod;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.economy.EconomyService;
import ru.prevailcraft.prevail.profession.AbilityService;
import ru.prevailcraft.prevail.profession.ProfessionService;
import ru.prevailcraft.prevail.vassalage.HouseService;

/**
 * Сеть мода: два пакета.
 *  OpenScreenPayload (сервер → клиент) — открыть или обновить экран.
 *  ActionPayload (клиент → сервер) — нажата кнопка в экране.
 * Клиентский обработчик регистрируется в client/PrevailClient — сервер его не загружает.
 */
public final class Network {
    private Network() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar r = event.registrar("1");
        r.playToClient(OpenScreenPayload.TYPE, OpenScreenPayload.CODEC);
        r.playToServer(ActionPayload.TYPE, ActionPayload.CODEC, Network::onAction);
    }

    public static void openScreen(ServerPlayer p, String screen, String data) {
        PacketDistributor.sendToPlayer(p, new OpenScreenPayload(screen, data));
    }

    private static void onAction(ActionPayload msg, IPayloadContext ctx) {
        if (!(ctx.player() instanceof ServerPlayer sp) || !Prevail.running()) return;
        String[] a = msg.data().split("\\|", -1);
        try {
            switch (msg.action()) {
                case "create_house" -> HouseService.createAtSlot(sp, Integer.parseInt(a[0]), Integer.parseInt(a[1]), a.length > 2 ? a[2] : "");
                case "prof_request" -> ProfessionService.sendScreen(sp);
                case "prof_choose" -> {
                    sp.sendSystemMessage(Component.literal(ProfessionService.choose(sp, a[0])));
                    ProfessionService.sendScreen(sp);
                }
                case "perk_learn" -> {
                    sp.sendSystemMessage(Component.literal(ProfessionService.learn(sp, a[0])));
                    ProfessionService.sendScreen(sp);
                }
                case "ability_take" -> {
                    sp.sendSystemMessage(Component.literal(AbilityService.take(sp, a[0])));
                    ProfessionService.sendScreen(sp);
                }
                case "ability_drop" -> {
                    sp.sendSystemMessage(Component.literal(AbilityService.drop(sp, a[0])));
                    ProfessionService.sendScreen(sp);
                }
                case "safe_code" -> ru.prevailcraft.prevail.lock.LockService.setSafeCode(sp, a[0]);
                case "pick_success" -> ru.prevailcraft.prevail.lock.LockService.pickSuccess(sp);
                case "pick_break" -> ru.prevailcraft.prevail.lock.LockService.pickBreak(sp);
                case "market_buy" -> {
                    EconomyService.buy(sp, a[0], Math.max(1, Math.min(64, Integer.parseInt(a[1]))));
                    EconomyService.sendMarket(sp, false);
                }
                default -> PrevailMod.LOG.warn("Prevail: неизвестное действие {}", msg.action());
            }
            Prevail.markDirty();
        } catch (PrevailException e) {
            sp.sendSystemMessage(Component.literal("§c" + e.getMessage()));
        } catch (RuntimeException e) {
            PrevailMod.LOG.warn("Prevail: ошибка в действии {} {}", msg.action(), msg.data(), e);
        }
    }
}

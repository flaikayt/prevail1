package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.profession.Profession;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Окно ремёсел (клавиша P): игрок в центре, 7 основных ремёсел слева, 6 лицензий справа,
 * сверху — прогресс основного ремесла и лицензии.
 */
public class ProfessionScreen extends Screen {
    public static final Profession[] MAIN = {Profession.MINER, Profession.LUMBERJACK, Profession.FARMER, Profession.HERDER,
            Profession.SMITH, Profession.CARPENTER, Profession.WEAVER};
    public static final Profession[] LICENSED = {Profession.HEALER, Profession.MERCENARY, Profession.HUNTSMAN,
            Profession.FISHER, Profession.MERCHANT, Profession.SORCERER};
    public static final String[] RANKS = {"Ученик", "Подмастерье", "Мастер", "Старший мастер", "Гроссмейстер"};

    private Map<String, String> d;
    private final Map<Profession, Button> buttons = new LinkedHashMap<>();

    public ProfessionScreen(Map<String, String> d) {
        super(Component.literal("Ремёсла"));
        this.d = d;
    }

    public void update(Map<String, String> d) {
        this.d = d;
        rebuildWidgets();
    }

    public Map<String, String> data() {
        return d;
    }

    static Profession prof(String name) {
        if (name == null || name.isEmpty()) return null;
        try {
            return Profession.valueOf(name);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    static int num(Map<String, String> d, String k) {
        try {
            return Integer.parseInt(d.getOrDefault(k, "0"));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private int cx() {
        return width / 2;
    }

    private int cy() {
        return height / 2 + 14;
    }

    @Override
    protected void init() {
        buttons.clear();
        int rx = Math.min(150, width / 2 - 30), ry = Math.min(85, height / 2 - 45);
        place(MAIN, 125, 235, rx, ry);
        place(LICENSED, 55, -55, rx, ry);
    }

    private void place(Profession[] list, double fromDeg, double toDeg, int rx, int ry) {
        for (int i = 0; i < list.length; i++) {
            double a = Math.toRadians(fromDeg + (toDeg - fromDeg) * i / (list.length - 1));
            int x = (int) (cx() + Math.cos(a) * rx) - 11;
            int y = (int) (cy() - Math.sin(a) * ry) - 11;
            Profession p = list[i];
            Button b = Button.builder(Component.empty(), btn -> minecraft.setScreen(new ProfessionDetailScreen(this, p, d)))
                    .bounds(x, y, 22, 22).build();
            buttons.put(p, b);
            addRenderableWidget(b);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        Profession main = prof(d.get("prof"));
        Profession lic = prof(d.get("lic"));

        // Прогресс сверху
        int bx = cx() - 70;
        drawBar(g, bx, 8, main, num(d, "rank"), "Ремесло не выбрано");
        drawBar(g, bx, 26, lic, num(d, "lrank"), "Лицензии нет");

        Ui.player(g, cx() - 32, cy() - 52, cx() + 32, cy() + 52, 42, mouseX, mouseY);
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        Profession hovered = null;
        for (Map.Entry<Profession, Button> en : buttons.entrySet()) {
            Profession p = en.getKey();
            Button b = en.getValue();
            Ui.item(g, p.icon, b.getX() + 3, b.getY() + 3);
            if (p == main) Ui.outline(g, b.getX() - 1, b.getY() - 1, 24, 24, Ui.GREEN);
            else if (p == lic) Ui.outline(g, b.getX() - 1, b.getY() - 1, 24, 24, Ui.GOLD);
            else if (p.licensed) Ui.fill(g, b.getX() + 2, b.getY() + 2, b.getX() + 20, b.getY() + 20, 0x88000000);
            if (b.isHovered()) hovered = p;
        }

        Ui.centered(g, "Основные ремёсла", cx() - Math.min(150, width / 2 - 30), cy() + Math.min(85, height / 2 - 45) + 18, Ui.WHITE);
        Ui.centered(g, "По лицензии", cx() + Math.min(150, width / 2 - 30), cy() + Math.min(85, height / 2 - 45) + 18, Ui.WHITE);
        if (hovered != null) {
            Ui.centered(g, hovered.title + (hovered.licensed ? " (лицензия)" : ""), cx(), height - 30, Ui.GOLD);
            Ui.centered(g, hovered.perk, cx(), height - 18, Ui.WHITE);
        } else {
            Ui.centered(g, "Нажмите на ремесло, чтобы узнать больше", cx(), height - 18, 0xFFAAAAAA);
        }
    }

    private void drawBar(GuiGraphicsExtractor g, int x, int y, Profession p, int rank, String empty) {
        if (p == null || p == Profession.NONE) {
            Ui.text(g, empty, x + 22, y + 4, 0xFFAAAAAA, true);
            return;
        }
        Ui.item(g, p.icon, x, y);
        Ui.rankNodes(g, x + 22, y + 5, rank, 22);
        Ui.text(g, p.title + (rank > 0 ? " · " + RANKS[rank - 1] : ""), x + 22 + 5 * 22 + 4, y + 4, Ui.WHITE, true);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

package ru.prevailcraft.prevail.profession;

/**
 * Навык в древе ремесла.
 * key — тип эффекта (см. ProfessionService.bonus), perLevel — сила за уровень навыка.
 * tier: в стволе 0..2, в ветке 0..3 (3 — капстоун гроссмейстера).
 */
public record Perk(String id, Profession prof, Branch branch, int tier, String name, String desc,
                   String key, double perLevel, int maxLevel, int cost, int reqLevel) {

    public boolean capstone() {
        return branch != null && tier == 3;
    }

    /** Описание с подставленным значением: «{v}» → perLevel × уровень. */
    public String describe(int level) {
        int l = Math.max(1, level);
        double v = perLevel * l;
        String s = v == Math.floor(v) ? String.valueOf((long) v) : String.format("%.1f", v);
        return desc.replace("{v}", s);
    }
}

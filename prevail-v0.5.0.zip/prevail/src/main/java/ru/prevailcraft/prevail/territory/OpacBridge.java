package ru.prevailcraft.prevail.territory;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import ru.prevailcraft.prevail.PrevailMod;
import xaero.pac.common.server.api.OpenPACServerAPI;

import java.util.UUID;

/**
 * Единственное место, которое обращается к API Open Parties and Claims.
 * OPAC хранит клеймы чанков и сам рисует их на миникарте и карте мира Xaero,
 * поэтому земли Домов видны на карте без собственного рендера.
 *
 * Владелец земли Дома = любой член Дома, заклеймивший чанк через OPAC.
 * Защиту в конфиге OPAC стоит ослабить: в Prevail вместо жёсткого привата
 * работает система подозрительности (см. README).
 *
 * Любая ошибка API (смена сигнатур в новой версии OPAC) ловится и логируется
 * один раз, чтобы сервер не падал.
 */
public final class OpacBridge {
    private static boolean warned;

    private OpacBridge() {}

    public static UUID claimOwner(MinecraftServer server, Level level, int cx, int cz) {
        try {
            var claim = OpenPACServerAPI.get(server).getServerClaimsManager()
                    .get(level.dimension().identifier(), cx, cz);
            return claim == null ? null : claim.getPlayerId();
        } catch (LinkageError | RuntimeException e) {
            warn(e);
            return null;
        }
    }

    public static int claimCount(MinecraftServer server, UUID player) {
        try {
            var info = OpenPACServerAPI.get(server).getServerClaimsManager().getPlayerInfo(player);
            return info == null ? 0 : info.getClaimCount();
        } catch (LinkageError | RuntimeException e) {
            warn(e);
            return 0;
        }
    }

    /**
     * Заклеймить квадрат (2·radius+1)² чанков вокруг центра на имя owner.
     * Чужие клеймы не перезаписываются. Возвращает число заклеймлённых чанков.
     * Лимит клеймов игрока задаётся в конфиге OPAC — для столицы его стоит поднять.
     */
    public static int claimArea(MinecraftServer server, Level level, int cx, int cz, int radius, UUID owner) {
        int ok = 0;
        try {
            var claims = OpenPACServerAPI.get(server).getServerClaimsManager();
            var dim = level.dimension().identifier();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    var res = claims.tryToClaim(dim, owner, 0, cx, cz, cx + dx, cz + dz, false);
                    if (res != null && res.getResultType() != null && res.getResultType().success) ok++;
                }
            }
        } catch (LinkageError | RuntimeException e) {
            warn(e);
        }
        return ok;
    }

    /** UUID «серверных» клеймов OPAC (земля короны), если доступен; иначе null. */
    public static UUID serverClaimId() {
        try {
            Class<?> c = Class.forName("xaero.pac.common.server.player.config.PlayerConfig");
            return (UUID) c.getField("SERVER_CLAIM_UUID").get(null);
        } catch (ReflectiveOperationException | ClassCastException | LinkageError e) {
            return null;
        }
    }

    private static void warn(Throwable t) {
        if (warned) return;
        warned = true;
        PrevailMod.LOG.error("Prevail: ошибка API Open Parties and Claims — проверь версию OPAC", t);
    }
}

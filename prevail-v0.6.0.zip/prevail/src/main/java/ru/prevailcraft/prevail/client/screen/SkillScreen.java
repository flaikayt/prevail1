package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.prevailcraft.prevail.client.PrevailClient;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.profession.Ability;
import ru.prevailcraft.prevail.profession.Branch;
import ru.prevailcraft.prevail.profession.Perk;
import ru.prevailcraft.prevail.profession.Perks;
import ru.prevailcraft.prevail.profession.Profession;
import ru.prevailcraft.prevail.profession.ProfessionService;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Окно ремёсел «Свиток + Древо» (клавиша P).
 * Слева — ремёсла и умения, справа — древо навыков выбранного ремесла или карточка умения.
 */
public class SkillScreen extends Screen {
    private static final int PARCH = 0xFFE4CEA0, PARCH_DARK = 0xFFCDB485, ROLL = 0xFF785028, ROLL_DARK = 0xFF46280F;
    private static final int INK = 0xFF3C2614, INK2 = 0xFF6E5032, RED = 0xFF8C231C;
    private static final int HAVE = 0xFF377D2D, CAN = 0xFFB97814, LOCK = 0xFFA58C69, OFF = 0xFFC8B68F;

    private Map<String, String> d;
    private Profession viewProf;
    private Ability viewAbility;
    private int left, top, w, h, split;

    private final Map<Profession, Button> profButtons = new LinkedHashMap<>();
    private final Map<Ability, Button> abilityButtons = new LinkedHashMap<>();
    private final Map<Perk, Button> perkButtons = new LinkedHashMap<>();
    private final Map<String, Integer> learned = new HashMap<>();
    private final Map<Ability, int[]> owned = new LinkedHashMap<>(); // ability → {level, xp}

    public SkillScreen(Map<String, String> d) {
        super(Component.literal("Ремёсла"));
        read(d);
        Ui.sound(net.minecraft.sounds.SoundEvents.BOOK_PAGE_TURN, 1.0f);
        Profession mine = myProf();
        viewProf = mine == null || mine == Profession.NONE ? Profession.MINER : mine;
    }

    public void update(Map<String, String> d) {
        int before = num("points");
        read(d);
        Ui.sound(num("points") < before ? net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP : net.minecraft.sounds.SoundEvents.BOOK_PAGE_TURN,
                num("points") < before ? 1.6f : 1.0f);
        rebuildWidgets();
    }

    /** Без размытия: мир вокруг виден, лишь слегка затемнён. */
    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        Ui.fill(g, 0, 0, width, height, 0x38000000);
    }

    private void read(Map<String, String> d) {
        this.d = d;
        learned.clear();
        for (String s : Ui.split(d.getOrDefault("perks", ""), ',')) {
            String[] f = s.split(":");
            if (f.length == 2) learned.put(f[0], Integer.parseInt(f[1]));
        }
        owned.clear();
        for (String s : Ui.split(d.getOrDefault("abil", ""), ',')) {
            String[] f = s.split(":");
            if (f.length == 3) owned.put(Ability.valueOf(f[0]), new int[]{Integer.parseInt(f[1]), Integer.parseInt(f[2])});
        }
    }

    private int num(String k) {
        try {
            return Integer.parseInt(d.getOrDefault(k, "0"));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private Profession myProf() {
        try {
            return Profession.valueOf(d.getOrDefault("prof", "NONE"));
        } catch (IllegalArgumentException e) {
            return Profession.NONE;
        }
    }

    private Branch myBranch() {
        String b = d.getOrDefault("branch", "");
        return b.isEmpty() ? null : Branch.valueOf(b);
    }

    // ---------- раскладка ----------

    @Override
    protected void init() {
        // окно поменьше, чтобы было видно мир вокруг
        w = Math.min(width - 60, 580);
        h = Math.min(height - 50, 292);
        left = (width - w) / 2;
        top = (height - h) / 2 + 4;
        split = left + 168;
        profButtons.clear();
        abilityButtons.clear();
        perkButtons.clear();

        int y = top + 26;
        for (Profession p : Profession.MAIN) {
            Button b = Button.builder(Component.empty(), btn -> {
                viewProf = p;
                viewAbility = null;
                rebuildWidgets();
            }).bounds(left + 8, y, 154, 15).build();
            profButtons.put(p, addRenderableWidget(b));
            y += 16;
        }
        y += 12;
        for (Ability a : Ability.values()) {
            Button b = Button.builder(Component.empty(), btn -> {
                viewAbility = a;
                rebuildWidgets();
            }).bounds(left + 8, y, 154, 12).build();
            abilityButtons.put(a, addRenderableWidget(b));
            y += 13;
        }

        int rx = split + 10, by = top + h - 26;
        if (viewAbility != null) {
            boolean has = owned.containsKey(viewAbility);
            if (has) {
                addRenderableWidget(Button.builder(Component.literal("Отказаться"), b -> PrevailClient.send("ability_drop", viewAbility.name()))
                        .bounds(rx, by, 100, 18).build());
            } else {
                Button take = Button.builder(Component.literal("Взять умение"), b -> PrevailClient.send("ability_take", viewAbility.name()))
                        .bounds(rx, by, 100, 18).build();
                take.active = owned.size() < Ability.MAX_ABILITIES;
                addRenderableWidget(take);
            }
            return;
        }
        if (viewProf != myProf()) {
            Button choose = Button.builder(Component.literal("Выбрать ремесло"), b -> PrevailClient.send("prof_choose", viewProf.name()))
                    .bounds(rx, by, 110, 18).build();
            choose.active = num("cd") == 0;
            addRenderableWidget(choose);
            return;
        }
        // узлы древа
        List<Perk> trunk = Perks.trunk(viewProf);
        for (int i = 0; i < trunk.size(); i++) addPerk(trunk.get(i), tx(), trunkY(i));
        List<Branch> brs = Branch.of(viewProf);
        for (int bi = 0; bi < brs.size(); bi++) {
            List<Perk> list = Perks.branch(brs.get(bi));
            for (int j = 0; j < list.size(); j++) addPerk(list.get(j), colX(j), rowY(bi));
        }
    }

    private void addPerk(Perk k, int cx, int cy) {
        Button b = Button.builder(Component.empty(), btn -> PrevailClient.send("perk_learn", k.id()))
                .bounds(cx - 11, cy - 11, 22, 22).build();
        perkButtons.put(k, addRenderableWidget(b));
    }

    private int tx() {
        return split + 30;
    }

    private int trunkY(int i) {
        return top + 100 + i * 44;
    }

    private int forkX() {
        return split + 72;
    }

    private int colX(int j) {
        int step = Math.max(64, (left + w - split - 140) / 3);
        return split + 112 + j * step;
    }

    private int rowY(int bi) {
        return bi == 0 ? top + 106 : top + 196;
    }

    // ---------- состояние навыка ----------

    private int lvl(Perk k) {
        return learned.getOrDefault(k.id(), 0);
    }

    private boolean prereq(Perk k) {
        if (k.branch() == null) return k.tier() == 0 || lvl(Perks.trunk(k.prof()).get(k.tier() - 1)) > 0;
        Branch mb = myBranch();
        if (mb != null && mb != k.branch()) return false;
        List<Perk> trunk = Perks.trunk(k.prof());
        if (lvl(trunk.get(trunk.size() - 1)) == 0) return false;
        return k.tier() == 0 || lvl(Perks.branch(k.branch()).get(k.tier() - 1)) > 0;
    }

    /** 0 — закрыт, 1 — можно изучить, 2 — изучен (частично или полностью), 3 — ветка закрыта. */
    private int state(Perk k) {
        Branch mb = myBranch();
        if (k.branch() != null && mb != null && mb != k.branch()) return 3;
        if (lvl(k) >= k.maxLevel()) return 2;
        boolean can = prereq(k) && num("level") >= k.reqLevel() && num("points") >= k.cost();
        if (can) return 1;
        return lvl(k) > 0 ? 2 : 0;
    }

    // ---------- отрисовка ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        // свиток
        Ui.fill(g, left - 6, top - 10, left + w + 6, top - 2, ROLL);
        Ui.fill(g, left - 6, top - 8, left + w + 6, top - 6, 0xFFA07040);
        Ui.fill(g, left - 6, top + h + 2, left + w + 6, top + h + 10, ROLL);
        Ui.fill(g, left - 6, top + h + 4, left + w + 6, top + h + 6, 0xFFA07040);
        Ui.fill(g, left, top - 2, left + w, top + h + 2, PARCH_DARK);
        Ui.fill(g, left + 2, top, left + w - 2, top + h, PARCH);
        for (int y = top + 8; y < top + h - 8; y += 6) Ui.fill(g, split, y, split + 1, y + 3, INK2);

        Ui.text(g, "РЕМЁСЛА", left + 10, top + 8, INK, false);
        Ui.text(g, "Умения (" + owned.size() + "/" + Ability.MAX_ABILITIES + ")", left + 10, top + 26 + 7 * 16 + 2, RED, false);

        super.extractRenderState(g, mouseX, mouseY, partialTick);

        // строки ремёсел
        Profession mine = myProf();
        for (Map.Entry<Profession, Button> en : profButtons.entrySet()) {
            Profession p = en.getKey();
            Button b = en.getValue();
            boolean sel = p == viewProf && viewAbility == null;
            Ui.fill(g, b.getX(), b.getY(), b.getX() + b.getWidth(), b.getY() + b.getHeight(), sel ? 0xFFFFECB9 : PARCH);
            if (sel) Ui.outline(g, b.getX(), b.getY(), b.getWidth(), b.getHeight(), 0xFFBE8C28);
            else if (b.isHovered()) Ui.outline(g, b.getX(), b.getY(), b.getWidth(), b.getHeight(), INK2);
            g.pose().pushMatrix();
            g.pose().translate(b.getX() + 2, b.getY() + 1);
            g.pose().scale(0.8f, 0.8f);
            Ui.item(g, p.icon, 0, 0);
            g.pose().popMatrix();
            Ui.text(g, p.title, b.getX() + 20, b.getY() + 4, INK, false);
            if (p == mine) Ui.text(g, "ур." + num("level"), b.getX() + b.getWidth() - 34, b.getY() + 4, HAVE, false);
        }
        // строки умений
        for (Map.Entry<Ability, Button> en : abilityButtons.entrySet()) {
            Ability a = en.getKey();
            Button b = en.getValue();
            boolean sel = a == viewAbility;
            boolean has = owned.containsKey(a);
            Ui.fill(g, b.getX(), b.getY(), b.getX() + b.getWidth(), b.getY() + b.getHeight(), sel ? 0xFFFFECB9 : PARCH);
            if (sel) Ui.outline(g, b.getX(), b.getY(), b.getWidth(), b.getHeight(), 0xFFBE8C28);
            else if (b.isHovered()) Ui.outline(g, b.getX(), b.getY(), b.getWidth(), b.getHeight(), INK2);
            g.pose().pushMatrix();
            g.pose().translate(b.getX() + 2, b.getY() + 1);
            g.pose().scale(0.75f, 0.75f);
            Ui.item(g, a.icon, 0, 0);
            g.pose().popMatrix();
            Ui.text(g, a.title, b.getX() + 18, b.getY() + 2, has ? INK : LOCK, false);
            if (has) Ui.text(g, ProfessionService.roman(owned.get(a)[0]), b.getX() + b.getWidth() - 18, b.getY() + 2, HAVE, false);
        }

        if (viewAbility != null) drawAbility(g);
        else drawTree(g, mouseX, mouseY);
    }

    private void drawHeader(GuiGraphicsExtractor g, String icon, String title, String sub) {
        int rx = split + 12, ry = top + 8;
        Ui.fill(g, rx, ry, rx + 34, ry + 34, 0xFF46321E);
        Ui.outline(g, rx, ry, 34, 34, 0xFFBE8C28);
        Ui.bigItem(g, icon, rx + 1, ry + 1, 2f);
        Ui.text(g, title, rx + 42, ry + 3, INK, false);
        Ui.text(g, sub, rx + 42, ry + 15, INK2, false);
    }

    private void drawTree(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        boolean mine = viewProf == myProf();
        int level = mine ? num("level") : 0;
        drawHeader(g, viewProf.icon, viewProf.title.toUpperCase(),
                mine ? ProfessionService.RANKS[Math.max(0, num("rank") - 1)] + (myBranch() != null ? " · " + myBranch().title : "") + " · ур. " + level + " из 50"
                        : viewProf.perk);
        int rx = split + 54, ry = top + 34;
        if (mine) {
            int need = num("need"), xp = num("xp");
            int bw = left + w - rx - 96;
            Ui.fill(g, rx, ry, rx + bw, ry + 6, 0xFFB49B6E);
            Ui.fill(g, rx + 1, ry + 1, rx + 1 + (need == 0 ? bw - 2 : (int) ((bw - 2) * Math.min(1.0, xp / (double) need))), ry + 5, 0xFF50A03C);
            // очки мастерства
            int px = left + w - 88;
            Ui.fill(g, px, top + 8, px + 80, top + 32, 0xFFF5E4BE);
            Ui.outline(g, px, top + 8, 80, 24, CAN);
            Ui.text(g, "Очки:", px + 6, top + 16, INK, false);
            Ui.text(g, String.valueOf(num("points")), px + 52, top + 16, CAN, false);
        }
        // шкала рангов
        int sy = top + 54;
        int step = (left + w - split - 50) / 4;
        for (int i = 0; i < 5; i++) {
            int x = split + 26 + i * step;
            boolean on = level >= ProfessionService.RANK_LEVEL[i];
            if (i < 4) Ui.fill(g, x + 6, sy + 3, x + step - 6, sy + 4, level >= ProfessionService.RANK_LEVEL[i + 1] ? HAVE : LOCK);
            Ui.fill(g, x - 6, sy - 3, x + 7, sy + 10, on ? HAVE : LOCK);
            Ui.fill(g, x - 5, sy - 2, x + 6, sy + 9, PARCH);
            Ui.centeredFlat(g, new String[]{"I", "II", "III", "IV", "V"}[i], x + 1, sy, on ? HAVE : LOCK);
            Ui.small(g, ProfessionService.RANKS[i] + " · " + ProfessionService.RANK_LEVEL[i], x, sy + 13, on ? INK : INK2, 0.6f);
        }

        if (!mine) {
            int y = top + 90;
            Ui.text(g, "Это ремесло не ваше.", split + 12, y, INK, false);
            Ui.text(g, "Ветки: " + Branch.of(viewProf).get(0).title + " / " + Branch.of(viewProf).get(1).title, split + 12, y + 14, INK2, false);
            Ui.text(g, "«" + viewProf.quote + "»", split + 12, y + 32, INK2, false);
            Ui.text(g, num("cd") > 0 ? "Сменить ремесло можно через " + num("cd") + " ч." : "При смене опыт и навыки сгорят.",
                    split + 12, top + h - 44, RED, false);
            return;
        }

        // линии
        List<Perk> trunk = Perks.trunk(viewProf);
        List<Branch> brs = Branch.of(viewProf);
        for (int i = 0; i + 1 < trunk.size(); i++) vline(g, tx(), trunkY(i) + 11, trunkY(i + 1) - 11, lvl(trunk.get(i + 1)) > 0);
        boolean forkOn = myBranch() != null;
        hline(g, tx() + 11, forkX(), trunkY(2), forkOn);
        vline(g, forkX(), rowY(0), rowY(1), false);
        for (int bi = 0; bi < brs.size(); bi++) {
            boolean on = brs.get(bi) == myBranch();
            hline(g, forkX(), colX(0) - 11, rowY(bi), on);
            List<Perk> list = Perks.branch(brs.get(bi));
            for (int j = 0; j + 1 < list.size(); j++) hline(g, colX(j) + 11, colX(j + 1) - 11, rowY(bi), lvl(list.get(j + 1)) > 0);
            int title = state(list.get(0)) == 3 ? OFF : RED;
            Ui.text(g, brs.get(bi).title.toUpperCase(), colX(0) - 11, rowY(bi) - 34, title, false);
            Ui.small(g, brs.get(bi).perk, colX(0) - 11 + (int) (Ui.font().width(brs.get(bi).perk) * 0.3f), rowY(bi) - 24, state(list.get(0)) == 3 ? OFF : INK2, 0.6f);
        }
        Ui.fill(g, forkX() - 3, trunkY(2) - 3, forkX() + 4, trunkY(2) + 4, forkOn ? HAVE : CAN);

        // узлы
        Perk hovered = null;
        for (Map.Entry<Perk, Button> en : perkButtons.entrySet()) {
            Perk k = en.getKey();
            Button b = en.getValue();
            int st = state(k);
            int col = st == 2 ? HAVE : st == 1 ? CAN : st == 3 ? OFF : LOCK;
            int x = b.getX(), y = b.getY();
            Ui.fill(g, x - 1, y - 1, x + 23, y + 23, PARCH);
            Ui.fill(g, x, y, x + 22, y + 22, col);
            Ui.fill(g, x + 2, y + 2, x + 20, y + 20, 0xFFF0E2BE);
            if (k.capstone()) Ui.centeredFlat(g, "★", x + 11, y + 7, col);
            else Ui.item(g, viewProf.icon, x + 3, y + 3);
            if (st == 0 || st == 3) Ui.fill(g, x + 2, y + 2, x + 20, y + 20, 0x88F0E2BE);
            // ступени
            for (int i = 0; i < k.maxLevel(); i++) {
                int dx = x + 11 - k.maxLevel() * 3 + i * 6;
                Ui.fill(g, dx, y + 24, dx + 4, y + 28, i < lvl(k) ? HAVE : LOCK);
            }
            if (lvl(k) < k.maxLevel() && st != 3) {
                Ui.fill(g, x + 16, y - 5, x + 26, y + 5, st == 1 ? CAN : LOCK);
                Ui.centeredFlat(g, String.valueOf(k.cost()), x + 21, y - 4, 0xFFFFF5DC);
            }
            Ui.small(g, k.name(), x + 11, y + 31, st == 3 ? OFF : col == LOCK ? INK2 : col, 0.6f);
            if (b.isHovered()) hovered = k;
        }

        // подсказка внизу
        int iy = top + h - 30;
        Ui.fill(g, split + 6, iy - 4, left + w - 6, iy - 3, INK2);
        if (hovered != null) {
            int lv = lvl(hovered);
            Ui.text(g, hovered.name() + (hovered.maxLevel() > 1 ? " " + ProfessionService.roman(Math.max(1, lv)) + "/" + ProfessionService.roman(hovered.maxLevel()) : ""),
                    split + 12, iy, INK, false);
            String now = lv > 0 ? "Сейчас: " + hovered.describe(lv) : "";
            String next = lv < hovered.maxLevel() ? "Дальше: " + hovered.describe(lv + 1) + " · цена " + hovered.cost() + " · ур. " + hovered.reqLevel() : "Изучено полностью";
            Ui.text(g, (now.isEmpty() ? "" : now + "   ") + next, split + 12, iy + 12, INK2, false);
        } else {
            Ui.text(g, "+1 очко мастерства за 2 уровня. Ветку выбирают один раз на ранге II.", split + 12, iy + 6, INK2, false);
        }
    }

    private void hline(GuiGraphicsExtractor g, int x1, int x2, int y, boolean on) {
        Ui.fill(g, Math.min(x1, x2), y - 1, Math.max(x1, x2), y + 1, on ? HAVE : LOCK);
    }

    private void vline(GuiGraphicsExtractor g, int x, int y1, int y2, boolean on) {
        Ui.fill(g, x - 1, Math.min(y1, y2), x + 1, Math.max(y1, y2), on ? HAVE : LOCK);
    }

    private void drawAbility(GuiGraphicsExtractor g) {
        Ability a = viewAbility;
        int[] o = owned.get(a);
        drawHeader(g, a.icon, a.title.toUpperCase(), o == null ? "Умение · " + a.perk : "Ваше умение · уровень " + ProfessionService.roman(o[0]));
        int x = split + 14, y = top + 62;
        for (int i = 0; i < 3; i++) {
            boolean on = o != null && o[0] > i;
            Ui.fill(g, x, y, x + 14, y + 14, on ? HAVE : LOCK);
            Ui.fill(g, x + 1, y + 1, x + 13, y + 13, PARCH);
            Ui.centeredFlat(g, ProfessionService.roman(i + 1), x + 7, y + 3, on ? HAVE : LOCK);
            Ui.text(g, a.levels[i], x + 22, y + 3, on ? INK : INK2, false);
            if (i < 2) Ui.small(g, "с " + Ability.XP[i + 1] + " опыта", x + 210, y + 4, INK2, 0.7f);
            y += 24;
        }
        if (o != null && o[0] < 3) {
            long from = Ability.XP[o[0] - 1], to = Ability.XP[o[0]];
            int bw = 200;
            Ui.text(g, "Опыт умения: " + o[1] + " / " + to, x, y + 6, INK, false);
            Ui.fill(g, x, y + 18, x + bw, y + 24, 0xFFB49B6E);
            Ui.fill(g, x + 1, y + 19, x + 1 + (int) ((bw - 2) * Math.min(1.0, (o[1] - from) / (double) (to - from))), y + 23, 0xFF50A03C);
        }
        Ui.text(g, "Опыт идёт от действий умения. Отказ — опыт сгорает.", x, top + h - 46, INK2, false);
        if (o == null && owned.size() >= Ability.MAX_ABILITIES) Ui.text(g, "У вас уже 2 умения.", x + 110, top + h - 21, RED, false);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

package ru.prevailcraft.prevail.ui;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;

/** Серверное меню-«сундук»: верхние слоты — кнопки, нижние — инвентарь игрока. */
public final class GuiMenu extends ChestMenu {
    private final ChestGui gui;
    private final SimpleContainer box;

    GuiMenu(int id, Inventory inv, ChestGui gui) {
        this(id, inv, gui, new SimpleContainer(gui.rows * 9));
    }

    private GuiMenu(int id, Inventory inv, ChestGui gui, SimpleContainer box) {
        super(type(gui.rows), id, inv, box, gui.rows);
        this.gui = gui;
        this.box = box;
        sync();
    }

    private static MenuType<ChestMenu> type(int rows) {
        if (rows == 1) return MenuType.GENERIC_9x1;
        if (rows == 2) return MenuType.GENERIC_9x2;
        if (rows == 3) return MenuType.GENERIC_9x3;
        if (rows == 4) return MenuType.GENERIC_9x4;
        if (rows == 5) return MenuType.GENERIC_9x5;
        return MenuType.GENERIC_9x6;
    }

    private void sync() {
        for (int i = 0; i < gui.size(); i++) box.setItem(i, gui.icon(i).copy());
    }

    @Override
    public void clicked(int slotId, int button, ClickType type, Player player) {
        if (!(player instanceof ServerPlayer sp)) return;
        int top = gui.size();
        // Перетаскивание и «собрать всё» могут затянуть предметы в верхние слоты — запрещаем.
        if (type == ClickType.QUICK_CRAFT || type == ClickType.PICKUP_ALL) {
            sendAllDataToRemote();
            return;
        }
        try {
            if (slotId >= 0 && slotId < top) {
                gui.click(sp, slotId, button == 1, type == ClickType.QUICK_MOVE);
            } else if (slotId >= top && slotId < slots.size() && type == ClickType.QUICK_MOVE) {
                Slot s = slots.get(slotId);
                ItemStack st = s.getItem();
                if (!st.isEmpty() && gui.deposit != null && gui.deposit.on(sp, st)) s.setChanged();
            } else {
                super.clicked(slotId, button, type, player);
                return;
            }
        } catch (PrevailException e) {
            sp.sendSystemMessage(Component.literal("§c" + e.getMessage()));
        }
        gui.rebuild();
        sync();
        Prevail.markDirty();
        sendAllDataToRemote();
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }
}

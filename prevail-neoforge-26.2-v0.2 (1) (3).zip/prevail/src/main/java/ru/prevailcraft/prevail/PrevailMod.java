package ru.prevailcraft.prevail;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import ru.prevailcraft.prevail.command.PrevailCommands;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.ServerEvents;
import ru.prevailcraft.prevail.law.LawEvents;
import ru.prevailcraft.prevail.profession.ProfessionEvents;
import ru.prevailcraft.prevail.registry.ModBlocks;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.TerritoryEvents;
import ru.prevailcraft.prevail.vassalage.VassalEvents;
import ru.prevailcraft.prevail.world.BlockEvents;

/** Точка входа мода Prevail. */
@Mod(PrevailMod.MODID)
public final class PrevailMod {
    public static final String MODID = "prevail";
    public static final Logger LOG = LogUtils.getLogger();

    public PrevailMod(IEventBus modBus, ModContainer container) {
        ModBlocks.register(modBus); // сначала блоки: они добавляют свои BlockItem в ModItems.ITEMS
        ModItems.register(modBus);
        container.registerConfig(ModConfig.Type.SERVER, PrevailConfig.SPEC);

        NeoForge.EVENT_BUS.register(new ServerEvents());
        NeoForge.EVENT_BUS.register(new PrevailCommands());
        NeoForge.EVENT_BUS.register(new BlockEvents());
        NeoForge.EVENT_BUS.register(new TerritoryEvents());
        NeoForge.EVENT_BUS.register(new VassalEvents());
        NeoForge.EVENT_BUS.register(new LawEvents());
        NeoForge.EVENT_BUS.register(new ProfessionEvents());
    }
}

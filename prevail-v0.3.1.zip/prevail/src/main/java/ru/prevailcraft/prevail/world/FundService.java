package ru.prevailcraft.prevail.world;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import ru.prevailcraft.prevail.compat.IronsCompat;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.HouseColors;
import ru.prevailcraft.prevail.core.Kingdom;
import ru.prevailcraft.prevail.network.Network;
import ru.prevailcraft.prevail.registry.ModBlocks;
import ru.prevailcraft.prevail.vassalage.HouseService;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Pos;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.economy.PowerCoins;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.ui.ChestGui;
import ru.prevailcraft.prevail.ui.Icons;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Фонд — центр мира: здесь основывают Дома, двигают эпохи и черпают Исток.
 * Исток копится сам (до 5 бутылочек), над Фондом тогда поднимаются частицы.
 */
public final class FundService {
    public static final int MAX_ESSENCE = 5;
    /** uuid → время окончания баффа Истока. */
    private static final Map<String, Long> BUFFS = new HashMap<>();
    private static long particleTick;

    private FundService() {}

    private static Kingdom k() {
        return Prevail.data().kingdom;
    }

    /** Мест под Дома: 4 в начале, +1 за эпоху, максимум 8. */
    public static int houseSlots() {
        return Math.min(8, 3 + Epoch.current());
    }

    /** Смещения 8 постаментов вокруг Фонда (по кругу, по часовой стрелке от севера). */
    public static final int[][] SLOT_OFFSETS = {{0, -3}, {2, -2}, {3, 0}, {2, 2}, {0, 3}, {-2, 2}, {-3, 0}, {-2, -2}};

    private static BlockPos fundBlockPos() {
        String[] p = k().fund.split("\\|");
        return new BlockPos(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
    }

    private static ServerLevel fundLevel() {
        return k().fund == null ? null : VersionCompat.level(Prevail.server(), k().fund.split("\\|")[0]);
    }

    /** Фонд поставлен: бедрок под ним и постаменты вокруг. */
    public static void onFundPlaced(ServerLevel level, BlockPos pos) {
        level.setBlock(pos.below(), Blocks.BEDROCK.defaultBlockState(), 3);
        refreshSlots();
    }

    /** Фонд убран (админом): постаменты исчезают. */
    public static void onFundRemoved() {
        ServerLevel level = fundLevel();
        if (level == null) return;
        BlockPos c = fundBlockPos();
        for (int[] o : SLOT_OFFSETS) {
            BlockPos sp = c.offset(o[0], 0, o[1]);
            if (level.getBlockState(sp).is(ModBlocks.HOUSE_SLOT.get())) level.setBlock(sp, Blocks.AIR.defaultBlockState(), 3);
        }
    }

    /** Перерисовать все постаменты: закрыт / свободен / знамя Дома нужного цвета. */
    public static void refreshSlots() {
        if (!Prevail.running() || k().fund == null) return;
        ServerLevel level = fundLevel();
        if (level == null) return;
        BlockPos c = fundBlockPos();
        int open = houseSlots();
        for (int i = 0; i < SLOT_OFFSETS.length; i++) {
            String hid = k().slotHouses.get(String.valueOf(i));
            House h = hid == null ? null : Prevail.data().houses.get(hid);
            int mode = h != null ? 2 + HouseColors.clamp(h.color) : (i < open ? 1 : 0);
            BlockPos sp = c.offset(SLOT_OFFSETS[i][0], 0, SLOT_OFFSETS[i][1]);
            level.setBlock(sp, ModBlocks.HOUSE_SLOT.get().defaultBlockState().setValue(HouseSlotBlock.MODE, mode), 3);
        }
    }

    public static int slotIndex(Level level, BlockPos pos) {
        if (k().fund == null || !k().fund.startsWith(VersionCompat.dimId(level) + "|")) return -1;
        BlockPos c = fundBlockPos();
        for (int i = 0; i < SLOT_OFFSETS.length; i++) {
            if (c.offset(SLOT_OFFSETS[i][0], 0, SLOT_OFFSETS[i][1]).equals(pos)) return i;
        }
        return -1;
    }

    /** ПКМ по постаменту. */
    public static void useSlot(ServerPlayer sp, Level level, BlockPos pos) {
        int i = slotIndex(level, pos);
        if (i < 0) throw new PrevailException("Этот постамент не связан с Фондом.");
        String hid = k().slotHouses.get(String.valueOf(i));
        House h = hid == null ? null : Prevail.data().houses.get(hid);
        if (h != null) {
            sp.sendSystemMessage(Component.literal(HouseService.info(h)));
            return;
        }
        if (i >= houseSlots()) {
            throw new PrevailException("Место откроется в эпоху «" + Epoch.of(i - 2).title + "».");
        }
        StringBuilder taken = new StringBuilder();
        for (House o : Prevail.data().houses.values()) taken.append(o.color).append(',');
        Network.openScreen(sp, "house_found", "slot=" + i + ";price=" + PrevailConfig.HOUSE_FEE.get() + ";taken=" + taken);
    }

    public static Pos fundPos() {
        return k().fund == null ? null : Pos.fromBlockKey(k().fund);
    }

    /** ПКМ по Фонду: бутылочкой — набрать Исток, иначе открыть окно. */
    public static void use(ServerPlayer sp) {
        ItemStack hand = sp.getMainHandItem();
        if (hand.is(Items.GLASS_BOTTLE)) {
            if (k().essence <= 0) throw new PrevailException("Исток ещё не собрался — следите за частицами над Фондом.");
            k().essence--;
            hand.shrink(1);
            Players.profile(sp);
            ItemStack e = new ItemStack(ModItems.ESSENCE.get());
            if (!sp.getInventory().add(e)) sp.drop(e, false);
            sp.sendSystemMessage(Component.literal("§bВы зачерпнули Исток. Осталось в Фонде: " + k().essence));
            return;
        }
        open(sp);
    }

    public static void open(ServerPlayer sp) {
        new ChestGui(3, "Фонд — эпоха " + Epoch.current() + "/10", gui -> {
            Epoch cur = Epoch.of(Epoch.current());
            gui.set(4, Icons.of(Items.BEACON, "§6§lЭпоха " + cur.number + ": " + cur.title, "§7Открыто: " + cur.unlocks), null);
            if (cur.number < 10) {
                Epoch next = Epoch.of(cur.number + 1);
                gui.set(9, Icons.of(Items.BOOK, "§eСледующая: " + next.title, "§7Откроет: " + next.unlocks,
                        "§7Shift+клик по предметам в инвентаре — внести вклад"), null);
                int slot = 11;
                for (Map.Entry<String, Long> r : next.requirements().entrySet()) {
                    long have = k().epochProgress.getOrDefault(r.getKey(), 0L);
                    Item it = VersionCompat.item(r.getKey());
                    gui.set(slot++, Icons.of(it, "§f" + Icons.name(it),
                            Icons.bar((double) have / r.getValue()) + " §f" + have + "/" + r.getValue()), null);
                }
            }
            gui.set(22, Icons.of(ModItems.ESSENCE.get(), Math.max(1, k().essence), "§bИсток: " + k().essence + "/" + MAX_ESSENCE,
                    "§7ПКМ по Фонду пустой бутылочкой — зачерпнуть",
                    "§7Выпить: 1–3 монеты власти, очищение от ядов",
                    IronsCompat.loaded() ? "§d+ сила заклинаний и мана на 10 минут" : "§8(усиление магии — с Iron's Spells)"), null);
            gui.set(26, Icons.of(Items.PAPER, "§eМеста для Домов: " + Prevail.data().houses.size() + "/" + houseSlots(),
                    "§7Основать Дом: ПКМ по жёлтому «+»", "§7на постаменте вокруг Фонда"), null);
            Icons.frame(gui);
            gui.onDeposit(FundService::contribute);
        }).open(sp);
    }

    private static boolean contribute(ServerPlayer sp, ItemStack stack) {
        int cur = Epoch.current();
        if (cur >= 10) throw new PrevailException("Мир уже достиг последней эпохи.");
        Epoch next = Epoch.of(cur + 1);
        String id = VersionCompat.itemId(stack.getItem());
        Long need = next.requirements().get(id);
        if (need == null) throw new PrevailException("Этот предмет не нужен для эпохи «" + next.title + "».");
        long have = k().epochProgress.getOrDefault(id, 0L);
        long take = Math.min(need - have, stack.getCount());
        if (take <= 0) throw new PrevailException("Этого уже внесено достаточно.");
        stack.shrink((int) take);
        k().epochProgress.put(id, have + take);
        sp.sendSystemMessage(Component.literal("§aВклад принят: " + take + " шт."));
        boolean done = true;
        for (Map.Entry<String, Long> r : next.requirements().entrySet()) {
            if (k().epochProgress.getOrDefault(r.getKey(), 0L) < r.getValue()) done = false;
        }
        if (done) {
            k().epoch = next.number;
            k().epochProgress.clear();
            Players.broadcast("§6§l✦ Наступила эпоха «" + next.title + "»! Открыто: " + next.unlocks + ".");
            refreshSlots();
        }
        return true;
    }

    /** Выпить Исток (ПКМ с ним в руке). */
    public static void drink(ServerPlayer sp, ItemStack stack) {
        stack.shrink(1);
        ItemStack bottle = new ItemStack(Items.GLASS_BOTTLE);
        if (!sp.getInventory().add(bottle)) sp.drop(bottle, false);
        int coins = 1 + ThreadLocalRandom.current().nextInt(3);
        PowerCoins.give(sp, coins);
        sp.removeEffect(MobEffects.POISON);
        sp.removeEffect(MobEffects.WITHER);
        sp.removeEffect(MobEffects.NAUSEA);
        if (IronsCompat.loaded()) {
            IronsCompat.essenceBuff(sp, true);
            BUFFS.put(sp.getUUID().toString(), System.currentTimeMillis() + 600_000L);
        }
        sp.sendSystemMessage(Component.literal("§bИсток наполняет вас силой: +" + coins + " монет власти."));
    }

    public static void tickSecond() {
        Kingdom k = k();
        long now = System.currentTimeMillis();
        long period = PrevailConfig.ESSENCE_MINUTES.get() * 60_000L;
        if (k.lastEssenceMillis == 0) k.lastEssenceMillis = now;
        if (k.fund != null && k.essence < MAX_ESSENCE && now - k.lastEssenceMillis >= period) {
            k.essence++;
            k.lastEssenceMillis = now;
        }
        if (k.fund != null && k.essence > 0 && ++particleTick % 2 == 0) {
            Pos p = fundPos();
            ServerLevel lvl = VersionCompat.level(Prevail.server(), p.dim);
            if (lvl != null) lvl.sendParticles(ParticleTypes.END_ROD, p.x, p.y + 0.3, p.z, 3 + k.essence, 0.3, 0.6, 0.3, 0.02);
        }
        Iterator<Map.Entry<String, Long>> it = BUFFS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Long> e = it.next();
            if (e.getValue() > now) continue;
            ServerPlayer p = Players.online(e.getKey());
            if (p != null) IronsCompat.essenceBuff(p, false);
            it.remove();
        }
    }
}

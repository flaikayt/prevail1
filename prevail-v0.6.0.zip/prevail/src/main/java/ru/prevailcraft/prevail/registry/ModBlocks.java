package ru.prevailcraft.prevail.registry;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.prevailcraft.prevail.PrevailMod;
import ru.prevailcraft.prevail.world.HouseSlotBlock;

import java.util.List;
import java.util.function.UnaryOperator;

/**
 * Блоки мода. Состояние хранится в data.json по координатам,
 * окна открываются через событие ПКМ (world/BlockEvents).
 */
public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(PrevailMod.MODID);

    /** Фонд — чаша с Истоком, своя 3D-модель. Под ним сам ставится бедрок. */
    public static final DeferredBlock<Block> FUND = block("fund", p -> p.strength(-1f, 3_600_000f).sound(SoundType.STONE).noOcclusion().lightLevel(s -> 7));
    public static final DeferredBlock<Block> MARKET = block("market", p -> p.strength(-1f, 3_600_000f).sound(SoundType.WOOD).noOcclusion());
    public static final DeferredBlock<Block> BUYER = block("buyer", p -> p.strength(-1f, 3_600_000f).sound(SoundType.WOOD).noOcclusion());
    /** Корона королевства на бархатной подушке: коронация и королевский двор. */
    public static final DeferredBlock<ru.prevailcraft.prevail.world.FacingBlock> CROWN = BLOCKS.registerBlock("crown",
            ru.prevailcraft.prevail.world.FacingBlock::new, p -> p.strength(-1f, 3_600_000f).sound(SoundType.METAL).noOcclusion().lightLevel(s -> 5));

    public static final DeferredBlock<ru.prevailcraft.prevail.world.FacingBlock> HEARTH = BLOCKS.registerBlock("hearth",
            ru.prevailcraft.prevail.world.FacingBlock::new, p -> p.strength(6f, 1200f).sound(SoundType.STONE).lightLevel(s -> 12));
    public static final DeferredBlock<Block> STRATEGIST = block("strategist", p -> p.strength(2.5f).sound(SoundType.WOOD));

    /** Постамент под Дом: появляется сам вокруг Фонда, предмета нет. */
    public static final DeferredBlock<HouseSlotBlock> HOUSE_SLOT = BLOCKS.registerBlock("house_slot", HouseSlotBlock::new,
            p -> p.strength(-1f, 3_600_000f).sound(SoundType.WOOD).noOcclusion());

    /** Сейф: 3×3, открывается ключом «#код», можно взломать отмычкой. */
    public static final DeferredBlock<ru.prevailcraft.prevail.lock.SafeBlock> SAFE = BLOCKS.registerBlock("safe",
            ru.prevailcraft.prevail.lock.SafeBlock::new, p -> p.strength(8f, 1200f).sound(SoundType.METAL).noOcclusion());

    static {
        ModItems.ITEMS.registerSimpleBlockItem(SAFE);
        ModItems.ITEMS.registerSimpleBlockItem(CROWN);
        ModItems.ITEMS.registerSimpleBlockItem(HEARTH);
    }

    /** Блоки, которые видны во вкладке творческого режима. */
    public static final List<DeferredBlock<? extends Block>> ALL = List.of(FUND, MARKET, BUYER, CROWN, HEARTH, STRATEGIST);

    private ModBlocks() {}

    private static UnaryOperator<BlockBehaviour.Properties> unbreakable() {
        return p -> p.strength(-1f, 3_600_000f).sound(SoundType.STONE);
    }

    private static DeferredBlock<Block> block(String name, UnaryOperator<BlockBehaviour.Properties> props) {
        DeferredBlock<Block> b = BLOCKS.registerSimpleBlock(name, props);
        ModItems.ITEMS.registerSimpleBlockItem(b);
        return b;
    }

    public static boolean is(BlockState state, DeferredBlock<? extends Block> b) {
        return state.is(b.get());
    }

    public static boolean isOurs(BlockState state) {
        if (state.is(HOUSE_SLOT.get()) || state.is(SAFE.get())) return true;
        for (var b : ALL) if (state.is(b.get())) return true;
        return false;
    }

    public static void register(IEventBus modBus) {
        BLOCKS.register(modBus);
    }
}

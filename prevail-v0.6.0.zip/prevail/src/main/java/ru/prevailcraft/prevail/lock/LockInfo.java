package ru.prevailcraft.prevail.lock;

/** Замок на сундуке/двери: код ключа и тот, кто запер. */
public final class LockInfo {
    public String code;
    public String owner;

    public LockInfo() {}

    public LockInfo(String code, String owner) {
        this.code = code;
        this.owner = owner;
    }
}

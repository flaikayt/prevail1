package ru.prevailcraft.prevail.court;

import ru.prevailcraft.prevail.core.House;
import ru.prevailcraft.prevail.core.Kingdom;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;

/**
 * Легитимность короля, 0–100%:
 *   до 60 — поддержка лордов (доля их веса, присягнувших короне);
 *   до 20 — Дома без недоимок по налогам;
 *   до 10 — укомплектованный двор;
 *   10    — непустая казна;
 *   ±20   — события (победы/поражения, пожертвования), со временем стремятся к нулю.
 * Пороги открывают королю инструменты, а ниже 20% лорды получают право на мятеж.
 */
public final class Legitimacy {
    public static final int TAXES = 25, COURT = 50, HUNT = 75, EDICTS = 90, REBELLION = 20;

    private Legitimacy() {}

    public static double value() {
        Kingdom k = Prevail.data().kingdom;
        if (k.king == null) return 0;
        int total = CourtService.totalWeight();
        int sup = 0;
        PlayerProfile king = Players.profile(k.king);
        for (House h : Prevail.data().houses.values()) {
            boolean kingsHouse = king != null && h.id.equals(king.houseId);
            if (kingsHouse || k.supporters.contains(h.lord)) sup += CourtService.voteWeight(Players.profile(h.lord));
        }
        double support = total == 0 ? 0 : 60.0 * sup / total;

        int n = 0, ok = 0;
        for (House h : Prevail.data().houses.values()) {
            if (king != null && h.id.equals(king.houseId)) continue;
            n++;
            if (h.debt == 0) ok++;
        }
        double taxes = n == 0 ? 20 : 20.0 * ok / n;
        double court = 10.0 * k.offices.size() / CourtOffice.values().length;
        double treasury = k.treasury > 0 ? 10 : 0;
        double events = Math.max(-20, Math.min(20, k.legitimacyEvents));
        return Math.max(0, Math.min(100, support + taxes + court + treasury + events));
    }

    public static void require(int threshold, String what) {
        double v = value();
        if (v < threshold) throw new PrevailException(what + " доступно при легитимности от " + threshold + "% (сейчас " + (int) v + "%).");
    }

    public static void event(double delta) {
        Kingdom k = Prevail.data().kingdom;
        k.legitimacyEvents = Math.max(-20, Math.min(20, k.legitimacyEvents + delta));
        Prevail.markDirty();
    }

    /** Вызывается раз в 5 секунд: события «забываются» примерно за сутки. */
    public static void decay() {
        Kingdom k = Prevail.data().kingdom;
        double step = 20.0 / (24 * 720);
        if (k.legitimacyEvents > 0) k.legitimacyEvents = Math.max(0, k.legitimacyEvents - step);
        else if (k.legitimacyEvents < 0) k.legitimacyEvents = Math.min(0, k.legitimacyEvents + step);
    }

    public static String describe() {
        double v = value();
        return (int) v + "% — " + (v >= EDICTS ? "абсолютная власть" : v >= HUNT ? "твёрдая власть" : v >= COURT ? "признанная власть"
                : v >= TAXES ? "шаткая власть" : v >= REBELLION ? "слабая власть" : "лорды вправе восстать");
    }
}

package ru.prevailcraft.prevail.world;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Постамент вокруг Фонда — место под Дом.
 * MODE: 0 — закрыто (откроется с эпохой), 1 — свободно (жёлтый «+»),
 *       2..11 — занято Домом, цвет = MODE − 2 (знамя цвета Дома).
 */
public class HouseSlotBlock extends Block {
    public static final IntegerProperty MODE = IntegerProperty.create("mode", 0, 11);

    public HouseSlotBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(MODE, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(MODE);
    }
}

package ru.prevailcraft.prevail.core;

import ru.prevailcraft.prevail.territory.Plot;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Корона: король, двор, столица, фонд, эпохи. */
public final class Kingdom {
    public String name = "Королевство";
    public String king;
    public long treasury;
    public long taxPerChunk = -1;
    public boolean mintingOpen = true;

    // ---- двор ----
    public Map<String, String> offices = new HashMap<>();
    /** Поколение регалии для каждой должности: при снятии растёт, старые регалии рассыпаются. */
    public Map<String, Integer> officeGen = new HashMap<>();
    /** Регалии, которые надо выдать при входе (uuid → должность). */
    public Map<String, String> pendingRegalia = new HashMap<>();

    // ---- корона и легитимность ----
    public Set<String> claimants = new HashSet<>();
    public Map<String, String> votes = new HashMap<>();
    /** Подкуп: претендент → доп. вес голосов. */
    public Map<String, Integer> bribes = new HashMap<>();
    /** Лорды, присягнувшие короне. */
    public Set<String> supporters = new HashSet<>();
    /** Бонус/штраф легитимности от событий (войны, пожертвования), −20…+20. */
    public double legitimacyEvents;
    public long peaceEdictUntil;
    /** Враги короны (королевская охота): uuid → награда. */
    public Map<String, Long> hunts = new HashMap<>();

    public Pos throne;
    public Pos prison;

    // ---- столица ----
    public String capitalDim;
    public int capitalX, capitalZ;
    public int capitalRadius = -1;
    public Map<String, Plot> plots = new HashMap<>();
    public Set<String> brigade = new HashSet<>();

    // ---- фонд и эпохи ----
    public String fund;
    public int epoch = 1;
    public Map<String, Long> epochProgress = new HashMap<>();
    public int essence;
    public long lastEssenceMillis;
}

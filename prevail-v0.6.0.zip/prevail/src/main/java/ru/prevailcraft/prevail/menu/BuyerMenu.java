package ru.prevailcraft.prevail.menu;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.economy.EconomyService;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.registry.ModMenus;

/**
 * Скупщик: один слот для товара. Сервер считает цену и спрос и
 * синхронизирует их через ContainerData (по 15 бит на ячейку — пакеты данных меню 16-битные).
 * Кнопка «Продать» — clickMenuButton(id = 0).
 */
public class BuyerMenu extends AbstractContainerMenu {
    public static final int SLOT_X = 80, SLOT_Y = 35;

    private final SimpleContainer input = new SimpleContainer(1) {
        @Override
        public void setChanged() {
            super.setChanged();
            BuyerMenu.this.slotsChanged(this);
        }
    };
    private final ContainerData data;
    private final Player player;

    public BuyerMenu(int id, Inventory inv) {
        this(id, inv, new SimpleContainerData(6));
    }

    private BuyerMenu(int id, Inventory inv, ContainerData data) {
        super(ModMenus.BUYER.get(), id);
        this.player = inv.player;
        this.data = data;
        addSlot(new Slot(input, 0, SLOT_X, SLOT_Y));
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 84 + r * 18));
        }
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, 8 + c * 18, 142));
        addDataSlots(data);
        refresh();
    }

    private void put(int i, long v) {
        data.set(i, (int) (v & 0x7FFF));
        data.set(i + 1, (int) ((v >> 15) & 0x7FFF));
    }

    private long get(int i) {
        return (data.get(i) & 0x7FFFL) | ((data.get(i + 1) & 0x7FFFL) << 15);
    }

    /** Цена за весь стак в слоте, в медяках. */
    public long offer() {
        return get(0);
    }

    /** Спрос 0..4, −1 — товар не покупается, −2 — слот пуст. */
    public int demand() {
        return data.get(2) - 2;
    }

    /** Деньги игрока, в медяках. */
    public long money() {
        return get(3);
    }

    public boolean mintingOpen() {
        return data.get(5) == 1;
    }

    private void refresh() {
        if (data == null || !(player instanceof ServerPlayer sp) || !Prevail.running()) return;
        ItemStack st = input.getItem(0);
        put(0, EconomyService.quote(sp, st));
        data.set(2, (st.isEmpty() ? -2 : EconomyService.demand(st)) + 2);
        put(3, Money.count(sp));
        data.set(5, Prevail.data().kingdom.mintingOpen ? 1 : 0);
    }

    @Override
    public void slotsChanged(Container container) {
        super.slotsChanged(container);
        refresh();
    }

    @Override
    public boolean clickMenuButton(Player p, int id) {
        if (id != 0 || !(p instanceof ServerPlayer sp)) return false;
        ItemStack st = input.getItem(0);
        if (st.isEmpty()) return false;
        try {
            long got = EconomyService.sellStack(sp, st);
            input.setItem(0, ItemStack.EMPTY);
            sp.sendSystemMessage(Component.literal("§aПродано за " + Money.fmt(got)), true);
        } catch (PrevailException e) {
            sp.sendSystemMessage(Component.literal("§c" + e.getMessage()), true);
        }
        refresh();
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot.hasItem()) {
            ItemStack st = slot.getItem();
            result = st.copy();
            if (index == 0) {
                if (!moveItemStackTo(st, 1, 37, true)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(st, 0, 1, false)) {
                return ItemStack.EMPTY;
            }
            if (st.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player p) {
        return true;
    }

    @Override
    public void removed(Player p) {
        super.removed(p);
        clearContainer(p, input);
    }
}

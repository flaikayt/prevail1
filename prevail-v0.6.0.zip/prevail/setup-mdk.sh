#!/bin/sh
# Prevail: подготовка проекта из MDK NeoForge (Mac/Linux).
# Положи распакованный MDK в папку "mdk" рядом с этим файлом и запусти: sh setup-mdk.sh
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
BG="$(find "$ROOT/mdk" -name build.gradle | head -n 1)"
[ -z "$BG" ] && { echo "ОШИБКА: нет папки mdk с build.gradle"; exit 1; }
SRC="$(dirname "$BG")"
cp "$SRC/gradlew" "$SRC/gradlew.bat" "$ROOT/" && cp -R "$SRC/gradle" "$ROOT/" && chmod +x "$ROOT/gradlew"
echo "[1/3] Скопированы gradlew и папка gradle"
VER="$(grep -o "net.neoforged.moddev['\"]* *)* *version *(* *['\"][^'\"]*" "$BG" | sed "s/.*['\"]//" | head -n 1)"
if [ -n "$VER" ]; then
  sed -i.bak "s/\(id 'net.neoforged.moddev' version '\)[^']*'/\1$VER'/" "$ROOT/build.gradle" && rm -f "$ROOT/build.gradle.bak"
  echo "[2/3] Версия ModDevGradle: $VER"
else echo "[2/3] Не нашёл версию ModDevGradle — перенеси вручную"; fi
NEO="$(grep -E '^\s*neo_version' "$SRC/gradle.properties" | head -n 1 | sed 's/.*=\s*//')"
if [ -n "$NEO" ]; then
  sed -i.bak "s/^neo_version=.*/neo_version=$NEO/" "$ROOT/gradle.properties" && rm -f "$ROOT/gradle.properties.bak"
  echo "[3/3] Версия NeoForge: $NEO"
else echo "[3/3] Не нашёл neo_version — перенеси вручную"; fi
echo "Готово! Папку mdk можно удалить."

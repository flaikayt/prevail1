package ru.prevailcraft.prevail.core;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Летопись сервера: все общие объявления (коронации, основание и гибель Домов, войны, казни, эпохи)
 * автоматически записываются с датой. Читать: /chronicle [страница].
 */
public final class Chronicle {
    public static final int MAX = 500;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd.MM HH:mm").withZone(ZoneId.of("Europe/Moscow"));

    private Chronicle() {}

    public static void add(String text) {
        if (!Prevail.running()) return;
        List<String> l = Prevail.data().chronicle;
        l.add(FMT.format(Instant.now()) + " — " + text.replaceAll("§.", ""));
        while (l.size() > MAX) l.remove(0);
        Prevail.markDirty();
    }

    public static String page(int page) {
        List<String> l = Prevail.data().chronicle;
        if (l.isEmpty()) return "Летопись пока пуста.";
        int per = 10, pages = (l.size() + per - 1) / per;
        int p = Math.max(1, Math.min(pages, page));
        StringBuilder sb = new StringBuilder("§6📜 Летопись королевства · стр. " + p + "/" + pages);
        int end = l.size() - (p - 1) * per;
        for (int i = Math.max(0, end - per); i < end; i++) sb.append("\n§7").append(l.get(i));
        return sb.toString();
    }
}

package ru.prevailcraft.prevail.profession;

import net.minecraft.server.level.ServerPlayer;
import ru.prevailcraft.prevail.config.PrevailConfig;
import ru.prevailcraft.prevail.core.PlayerProfile;
import ru.prevailcraft.prevail.core.Players;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.network.Network;
import ru.prevailcraft.prevail.world.Epoch;

import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Ремесло: 50 уровней, ранги I–V (ур. 1/10/20/35/50), очки мастерства = ⌈уровень/2⌉,
 * навыки древа до 3 уровней. Ветка выбирается изучением её первого навыка (с ранга II).
 * Капстоун ветки — только гроссмейстер (места ограничены конфигом).
 */
public final class ProfessionService {
    public static final int MAX_LEVEL = 50;
    public static final int[] RANK_LEVEL = {1, 10, 20, 35, 50};
    public static final String[] RANKS = {"Ученик", "Подмастерье", "Мастер", "Старший мастер", "Гроссмейстер"};

    private ProfessionService() {}

    // ---------- уровни ----------

    /** Опыт, нужный чтобы перейти с уровня L на L+1. */
    public static long need(int level) {
        return 30 + 6L * level;
    }

    /** Суммарный опыт для достижения уровня L. */
    public static long totalFor(int level) {
        long t = 0;
        for (int i = 1; i < level; i++) t += need(i);
        return t;
    }

    public static int level(PlayerProfile p) {
        if (p.profession == Profession.NONE) return 0;
        int l = 1;
        while (l < MAX_LEVEL && p.professionXp >= totalFor(l + 1)) l++;
        return l;
    }

    public static int rank(PlayerProfile p) {
        int lvl = level(p);
        if (lvl == 0) return 0;
        int r = 1;
        for (int i = 0; i < RANK_LEVEL.length; i++) if (lvl >= RANK_LEVEL[i]) r = i + 1;
        if (r == 5 && !p.grandmaster) r = 4;
        return r;
    }

    public static int spent(PlayerProfile p) {
        int s = 0;
        for (Map.Entry<String, Integer> e : p.perks.entrySet()) {
            Perk k = Perks.ALL.get(e.getKey());
            if (k != null) s += k.cost() * e.getValue();
        }
        return s;
    }

    public static int points(PlayerProfile p) {
        return Math.max(0, (level(p) + 1) / 2 - spent(p));
    }

    public static int perkLevel(PlayerProfile p, Perk k) {
        return p.perks.getOrDefault(k.id(), 0);
    }

    /** Сумма эффекта по ключу у изученных навыков текущего ремесла. */
    public static double bonus(PlayerProfile p, String key) {
        double v = 0;
        for (Map.Entry<String, Integer> e : p.perks.entrySet()) {
            Perk k = Perks.ALL.get(e.getKey());
            if (k != null && k.prof() == p.profession && k.key().equals(key)) v += k.perLevel() * e.getValue();
        }
        return v;
    }

    /** Базовый шанс двойной добычи от уровня: 0.3% за уровень. */
    public static double baseDouble(PlayerProfile p) {
        return level(p) * 0.003;
    }

    public static boolean branchOk(PlayerProfile p, Branch b) {
        return p.profession == b.profession && (p.branch == null || p.branch == b);
    }

    public static void addXp(PlayerProfile p, Profession prof, long xp) {
        if (xp <= 0 || p.profession != prof) return;
        int before = level(p);
        long add = Math.round(xp * (1 + bonus(p, "xp") / 100.0));
        p.professionXp = Math.min(totalFor(MAX_LEVEL), p.professionXp + Math.max(1, add));
        int after = level(p);
        if (after > before) {
            Players.message(p.uuid, "§a⬆ " + prof.title + ": уровень " + after + "! Очков мастерства: " + points(p) + " (клавиша P)");
            for (int i = 1; i < RANK_LEVEL.length; i++) {
                if (before < RANK_LEVEL[i] && after >= RANK_LEVEL[i] && i < 4) {
                    Players.message(p.uuid, "§6✦ Новый ранг: " + RANKS[i] + "!");
                }
            }
        }
        Prevail.markDirty();
    }

    // ---------- навыки ----------

    public static String learn(ServerPlayer sp, String perkId) {
        PlayerProfile p = Players.profile(sp);
        Perk k = Perks.ALL.get(perkId);
        if (k == null) throw new PrevailException("Нет такого навыка.");
        if (k.prof() != p.profession) throw new PrevailException("Это навык другого ремесла.");
        int cur = perkLevel(p, k);
        if (cur >= k.maxLevel()) throw new PrevailException("Навык уже изучен полностью.");
        if (level(p) < k.reqLevel()) throw new PrevailException("Нужен уровень ремесла " + k.reqLevel() + ".");
        if (points(p) < k.cost()) throw new PrevailException("Нужно очков мастерства: " + k.cost() + ".");
        // цепочка
        if (k.branch() == null) {
            if (k.tier() > 0 && perkLevel(p, Perks.trunk(k.prof()).get(k.tier() - 1)) == 0) {
                throw new PrevailException("Сначала изучите предыдущий навык.");
            }
        } else {
            if (p.branch != null && p.branch != k.branch()) throw new PrevailException("Вы уже выбрали ветку «" + p.branch.title + "».");
            List<Perk> trunk = Perks.trunk(k.prof());
            if (perkLevel(p, trunk.get(trunk.size() - 1)) == 0) throw new PrevailException("Сначала изучите все навыки ствола.");
            if (k.tier() > 0 && perkLevel(p, Perks.branch(k.branch()).get(k.tier() - 1)) == 0) {
                throw new PrevailException("Сначала изучите предыдущий навык ветки.");
            }
            if (k.capstone() && !p.grandmaster) {
                int taken = 0;
                for (PlayerProfile o : Prevail.data().players.values()) if (o.grandmaster && o.profession == p.profession) taken++;
                if (taken >= PrevailConfig.GRANDMASTER_SLOTS.get()) throw new PrevailException("Все места гроссмейстеров заняты.");
                Epoch.require(4, "Ранг гроссмейстера");
                p.grandmaster = true;
                Players.broadcast("§6✦ " + p.name + " стал гроссмейстером ремесла «" + p.profession.title + "»!");
            }
            if (p.branch == null) {
                p.branch = k.branch();
                Players.message(p.uuid, "§eВы выбрали ветку «" + k.branch().title + "». Вторая ветка закрыта.");
            }
        }
        p.perks.put(k.id(), cur + 1);
        Prevail.markDirty();
        return "§aИзучено: " + k.name() + " " + roman(cur + 1) + " — " + k.describe(cur + 1);
    }

    public static String roman(int n) {
        return n <= 1 ? "I" : n == 2 ? "II" : "III";
    }

    // ---------- выбор ремесла ----------

    public static Profession parse(String s) {
        for (Profession pr : Profession.values()) {
            if (pr == Profession.NONE) continue;
            if (pr.name().equalsIgnoreCase(s) || pr.title.toLowerCase(Locale.ROOT).equals(s.toLowerCase(Locale.ROOT))) return pr;
        }
        throw new PrevailException("Нет такого ремесла. /prof list");
    }

    public static long cooldownHours(PlayerProfile p) {
        if (p.profession == Profession.NONE) return 0;
        long left = p.professionChangedAt + PrevailConfig.PROFESSION_COOLDOWN_HOURS.get() * 3_600_000L - System.currentTimeMillis();
        return left <= 0 ? 0 : left / 3_600_000L + 1;
    }

    public static String choose(ServerPlayer sp, String name) {
        PlayerProfile p = Players.profile(sp);
        Profession pr = parse(name);
        if (pr == p.profession) throw new PrevailException("Это уже ваше ремесло.");
        long cd = cooldownHours(p);
        if (cd > 0) throw new PrevailException("Сменить ремесло можно через " + cd + " ч.");
        p.profession = pr;
        p.branch = null;
        p.professionXp = 0;
        p.perks.clear();
        p.grandmaster = false;
        p.professionChangedAt = System.currentTimeMillis();
        return "§aВаше ремесло: " + pr.title + ". Опыт и навыки прежнего ремесла сброшены.";
    }

    // ---------- окно (клавиша P) ----------

    public static void sendScreen(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        int lvl = level(p);
        StringBuilder perks = new StringBuilder();
        for (Map.Entry<String, Integer> e : p.perks.entrySet()) perks.append(e.getKey()).append(':').append(e.getValue()).append(',');
        StringBuilder ab = new StringBuilder();
        for (Map.Entry<String, Long> e : p.abilities.entrySet()) {
            ab.append(e.getKey()).append(':').append(Ability.levelFor(e.getValue())).append(':').append(e.getValue()).append(',');
        }
        String data = "prof=" + p.profession.name()
                + ";branch=" + (p.branch == null ? "" : p.branch.name())
                + ";level=" + lvl
                + ";xp=" + (p.professionXp - totalFor(Math.max(1, lvl)))
                + ";need=" + (lvl >= MAX_LEVEL ? 0 : need(lvl))
                + ";points=" + points(p)
                + ";rank=" + rank(p)
                + ";gm=" + (p.grandmaster ? 1 : 0)
                + ";cd=" + cooldownHours(p)
                + ";epoch=" + Epoch.current()
                + ";perks=" + perks
                + ";abil=" + ab;
        Network.openScreen(sp, "professions", data);
    }

    public static String info(ServerPlayer sp) {
        PlayerProfile p = Players.profile(sp);
        if (p.profession == Profession.NONE) return "Ремесла нет. Откройте окно ремёсел клавишей P.";
        StringBuilder sb = new StringBuilder("§e" + p.profession.title);
        if (p.branch != null) sb.append(" — ").append(p.branch.title);
        sb.append("§f: уровень ").append(level(p)).append(" (").append(RANKS[Math.max(0, rank(p) - 1)]).append("), очков мастерства: ").append(points(p));
        for (Map.Entry<String, Long> e : p.abilities.entrySet()) {
            Ability a = Ability.valueOf(e.getKey());
            sb.append("\n§eУмение: ").append(a.title).append(" ").append(roman(Ability.levelFor(e.getValue())));
        }
        return sb.toString();
    }

    public static String list() {
        StringBuilder sb = new StringBuilder("§6Ремёсла (клавиша P — окно ремёсел):");
        for (Profession pr : Profession.MAIN) sb.append("\n§e").append(pr.title).append(" §7— ").append(pr.perk);
        sb.append("\n§6Умения (до двух):");
        for (Ability a : Ability.values()) sb.append("\n§e").append(a.title).append(" §7— ").append(a.perk);
        return sb.toString();
    }
}

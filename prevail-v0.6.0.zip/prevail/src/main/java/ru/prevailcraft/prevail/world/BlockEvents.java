package ru.prevailcraft.prevail.world;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityTravelToDimensionEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;
import ru.prevailcraft.prevail.compat.VersionCompat;
import ru.prevailcraft.prevail.core.Pos;
import ru.prevailcraft.prevail.core.Prevail;
import ru.prevailcraft.prevail.core.PrevailException;
import ru.prevailcraft.prevail.court.CourtOffice;
import ru.prevailcraft.prevail.court.CourtService;
import ru.prevailcraft.prevail.economy.EconomyService;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.house.HearthService;
import ru.prevailcraft.prevail.registry.ModBlocks;
import ru.prevailcraft.prevail.registry.ModItems;
import ru.prevailcraft.prevail.territory.CapitalService;
import ru.prevailcraft.prevail.vassalage.StrategistService;

/**
 * Все блоки мода: открытие окон по ПКМ, правила установки, разрушение.
 * Плюс предметы с действием по ПКМ (Исток, кошелёк) и закрытые эпохами измерения.
 */
public final class BlockEvents {

    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onUse(PlayerInteractEvent.RightClickBlock e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        Level level = e.getLevel();
        BlockPos pos = e.getPos();
        BlockState st = level.getBlockState(pos);
        if (!isOurs(st)) return;
        e.setCanceled(true);
        if (e.getHand() != InteractionHand.MAIN_HAND) return;
        String key = Pos.blockKey(level, pos);
        try {
            if (ModBlocks.is(st, ModBlocks.FUND)) FundService.use(sp);
            else if (ModBlocks.is(st, ModBlocks.HOUSE_SLOT)) FundService.useSlot(sp, level, pos);
            else if (ModBlocks.is(st, ModBlocks.SAFE)) ru.prevailcraft.prevail.lock.LockService.useSafe(sp, level, pos);
            else if (ModBlocks.is(st, ModBlocks.MARKET)) {
                requireCapital(level, pos);
                EconomyService.sendMarket(sp, true);
            } else if (ModBlocks.is(st, ModBlocks.BUYER)) {
                requireCapital(level, pos);
                EconomyService.openBuyer(sp);
            } else if (ModBlocks.is(st, ModBlocks.CROWN)) CourtService.openThrone(sp);
            else if (ModBlocks.is(st, ModBlocks.HEARTH)) HearthService.use(sp, key);
            else if (ModBlocks.is(st, ModBlocks.STRATEGIST)) StrategistService.open(sp);
            Prevail.markDirty();
        } catch (PrevailException ex) {
            sp.sendSystemMessage(Component.literal("§c" + ex.getMessage()));
        }
    }

    private static boolean isOurs(BlockState st) {
        return ModBlocks.isOurs(st);
    }

    private static void requireCapital(Level level, BlockPos pos) {
        if (!CapitalService.inCapital(level, pos)) throw new PrevailException("Рынок и скупщик работают только в столице.");
    }

    @SubscribeEvent
    public void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!Prevail.running() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        BlockState st = e.getPlacedBlock();
        Level level = sp.level();
        BlockPos pos = e.getPos();
        boolean admin = VersionCompat.isAdmin(sp);
        String id = sp.getUUID().toString();
        String deny = null;

        if (ModBlocks.is(st, ModBlocks.FUND)) {
            if (!admin && !CourtService.isKing(id)) deny = "Фонд ставит только король или администрация.";
            else if (Prevail.data().kingdom.fund != null) deny = "Фонд в мире может быть только один.";
        } else if (ModBlocks.is(st, ModBlocks.CROWN)) {
            if (!admin && !CourtService.isKing(id)) deny = "Корону ставит только король или администрация.";
            else if (!CapitalService.inCapital(level, pos)) deny = "Корона хранится только в столице.";
        } else if (ModBlocks.is(st, ModBlocks.MARKET) || ModBlocks.is(st, ModBlocks.BUYER)) {
            if (!admin && !CourtService.has(id, CourtOffice.ARCHITECT)) deny = "Рынок и скупщика ставят король, десница или архитектор.";
            else if (!CapitalService.inCapital(level, pos)) deny = "Рынок и скупщик могут стоять только в столице.";
        }
        if (deny != null) {
            e.setCanceled(true);
            sp.sendSystemMessage(Component.literal("§c" + deny));
            return;
        }
        if (ModBlocks.is(st, ModBlocks.FUND)) {
            Prevail.data().kingdom.fund = Pos.blockKey(level, pos);
            // Фонд основывает столицу: 9×9 чанков вокруг него
            sp.sendSystemMessage(Component.literal("§6" + CapitalService.setCapitalAt(sp, level, pos)));
            FundService.onFundPlaced((net.minecraft.server.level.ServerLevel) level, pos);
        }
        if (ModBlocks.is(st, ModBlocks.CROWN)) Prevail.data().kingdom.throne = Pos.of(level, pos);
        Prevail.markDirty();
    }

    @SubscribeEvent
    public void onBreak(BreakBlockEvent e) {
        if (!Prevail.running() || e.isCanceled() || !(e.getPlayer() instanceof ServerPlayer sp)) return;
        BlockState st = e.getState();
        String key = Pos.blockKey(sp.level(), e.getPos());
        if (ModBlocks.is(st, ModBlocks.FUND) && key.equals(Prevail.data().kingdom.fund)) {
            FundService.onFundRemoved();
            Prevail.data().kingdom.fund = null;
        }
        if (ModBlocks.is(st, ModBlocks.HEARTH)) HearthService.onHearthBroken(key, sp);
        Prevail.markDirty();
    }

    @SubscribeEvent
    public void onUseItem(PlayerInteractEvent.RightClickItem e) {
        if (!Prevail.running() || e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer sp)) return;
        ItemStack s = e.getItemStack();
        try {
            if (s.is(ModItems.ESSENCE.get())) {
                e.setCanceled(true);
                FundService.drink(sp, s);
            } else if (Money.isWallet(s)) {
                e.setCanceled(true);
                EconomyService.walletUse(sp, s);
            }
            Prevail.markDirty();
        } catch (PrevailException ex) {
            sp.sendSystemMessage(Component.literal("§c" + ex.getMessage()));
        }
    }

    /** Незер и Энд закрыты до своих эпох. */
    @SubscribeEvent
    public void onTravel(EntityTravelToDimensionEvent e) {
        if (!Prevail.running()) return;
        int need = 0;
        if (e.getDimension() == Level.NETHER) need = 5;
        else if (e.getDimension() == Level.END) need = 9;
        if (need > Epoch.current()) {
            e.setCanceled(true);
            if (e.getEntity() instanceof ServerPlayer sp) {
                sp.sendSystemMessage(Component.literal("§cПуть закрыт до эпохи «" + Epoch.of(need).title + "»."), true);
            }
        }
    }
}

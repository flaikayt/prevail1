package ru.prevailcraft.prevail.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import ru.prevailcraft.prevail.client.Ui;
import ru.prevailcraft.prevail.economy.Money;
import ru.prevailcraft.prevail.menu.BuyerMenu;

/** Скупщик: деревянная рамка, «окно с решёткой», один слот, цена и спрос на труд. */
public class BuyerScreen extends AbstractContainerScreen<BuyerMenu> {
    private static final String[] DEMAND = {"очень низкий", "низкий", "средний", "высокий", "очень высокий"};
    private static final int[] DEMAND_COLOR = {0xFFFF5555, 0xFFFFAA55, 0xFFFFFF55, 0xFFAAFF55, 0xFF55FF55};

    public BuyerScreen(BuyerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title, 176, 166);
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("Продать"), b -> {
            if (minecraft.gameMode != null) minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 0);
        }).bounds(leftPos + 108, topPos + 52, 56, 18).build());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(g, mouseX, mouseY, partialTick);
        int x = leftPos, y = topPos;
        Ui.panel(g, x, y, imageWidth, imageHeight, Ui.WOOD);
        // «окно» с решёткой
        Ui.fill(g, x + 8, y + 14, x + 168, y + 76, Ui.WOOD_DARK);
        Ui.fill(g, x + 10, y + 16, x + 166, y + 74, 0xFF101010);
        for (int i = 0; i < 11; i++) Ui.fill(g, x + 14 + i * 15, y + 16, x + 16 + i * 15, y + 74, 0xFF7E8798);
        Ui.slot(g, x + BuyerMenu.SLOT_X - 1, y + BuyerMenu.SLOT_Y - 1);
        // ячейки инвентаря
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 83 + r * 18);
        for (int c = 0; c < 9; c++) Ui.slot(g, x + 7 + c * 18, y + 141);
    }

    @Override
    protected void extractLabels(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        super.extractLabels(g, mouseX, mouseY);
        int dem = menu.demand();
        if (dem == -2) {
            Ui.text(g, "Положите товар", 14, 20, Ui.WHITE, true);
        } else if (dem == -1) {
            Ui.text(g, "Не покупаем", 14, 20, Ui.RED, true);
        } else {
            Ui.item(g, "prevail:copper_coin", 12, 56);
            Ui.text(g, Money.fmt(menu.offer()), 30, 60, Ui.GOLD, true);
            Ui.text(g, "Спрос: ", 14, 20, Ui.WHITE, true);
            Ui.text(g, DEMAND[dem], 14 + Ui.font().width("Спрос: "), 20, DEMAND_COLOR[dem], true);
        }
        if (!menu.mintingOpen()) Ui.text(g, "Чеканка закрыта", 96, 20, 0xFFFFAA55, true);
        Ui.text(g, "У вас: " + Money.fmt(menu.money()), 96, inventoryLabelY, 0xFF2A1A08, false);
    }
}

package ru.prevailcraft.prevail.law;

/** Объявление о розыске. Награда заранее списана с казны (эскроу). */
public final class WantedEntry {
    public enum Scope { ROYAL, HOUSE }

    public String target;
    public Scope scope;
    /** id Дома для HOUSE, "crown" для ROYAL. */
    public String issuer;
    public String issuedBy;
    public String reason;
    public long bounty;
    public long issuedAt;

    public WantedEntry() {}

    public String key() {
        return key(target, issuer);
    }

    public static String key(String target, String issuer) {
        return target + "|" + issuer;
    }
}
